import React from "react";

import SigninIntro from "./SigninIntro";
import SigninBox from "./SigninBox";

export default function Signin(props) {
  return (
    <div className="content intro-signin-container">
      <SigninIntro />
      <SigninBox
        signIn={props.signIn}
        username={props.username}
        setUsername={props.setUsername}
        password={props.password}
        setPassword={props.setPassword}
        signinPress={props.signinPress}
      />
    </div>
  );
}
