import React from "react";

export default function RiskAnalyticsAggrRadio(props) {
  return (
    <div style={{ width: "288px" }} className="m-1">
      <label className="input-label pt-2 pl-1">Aggregation Option:</label>
      <div
        style={{
          paddingTop: "7px",
        }}
      >
        <div className="d-inline pl-2 p-2">
          <label className="radio-label">
            <input
              type="radio"
              className="radio-input d-block mx-auto w-100 "
              value="individual"
              checked={props.aggrType === "individual"}
              onChange={(e) => props.onRadioChange(e.target.value)}
            />
            Individual
          </label>
        </div>
        <div className="d-inline p-2">
          <label className="radio-label">
            <input
              type="radio"
              className="radio-input d-block mx-auto w-100 "
              value="sum"
              checked={props.aggrType === "sum"}
              onChange={(e) => props.onRadioChange(e.target.value)}
            />
            Sum
          </label>
        </div>
      </div>
    </div>
  );
}
