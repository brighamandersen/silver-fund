import React, { useState } from "react";

import { getDateStr } from "../common/helpers";
import GraphViewType from "../common/GraphViewType";
import DateRanger from "../common/DateRanger";
import RiskAnalyticsVTRadio from "./RiskAnalyticsVTRadio";
import RiskAnalyticsUnitRadio from "./RiskAnalyticsUnitRadio";
import RiskAnalyticsAggrRadio from "./RiskAnalyticsAggrRadio";
import RiskAnalyticsThroughTimeSelector from "./RiskAnalyticsThroughTimeSelector";

export default function RiskAnalyticsSnapshot() {
  const [graphVT, setGraphVT] = useState(0);
  const [riskVT, setRiskVT] = useState("total");
  const [unitType, setUnitType] = useState("");
  const [aggrType, setAggrType] = useState("");
  const [start, setStart] = useState(getDateStr(-1));
  const [end, setEnd] = useState(getDateStr(-1));

  const throughtimeGVTOptions = [
    { value: 0, label: "Ex-Ante Risk" },
    { value: 1, label: "Realized Risk" },
    { value: 2, label: "Ex-Ante vs. Realized Risk" },
    { value: 3, label: "Ex-Ante Beta to Benchmark" },
    { value: 4, label: "Realized Beta to Benchmark" },
    { value: 5, label: "Ex-Ante vs. Realized Beta to Benchmark" },
    {
      value: 6,
      label: "Portfolio Diversification Coefficient",
      disabled: true,
    },
    {
      value: 7,
      label: "Exposures to Style Factors 1 through K",
      disabled: true,
    },
    { value: 8, label: "Ex-Ante Partial Contribution to Risk", disabled: true },
    {
      value: 9,
      label: "Realized Partial Contribution to Risk",
      disabled: true,
    },
    { value: 10, label: "Ex-Ante Contribution to Risk", disabled: true },
    { value: 11, label: "Realized Contribution to Risk", disabled: true },
  ];

  return (
    <div className="content">
      <div className="pane-menu">
        <div className="menu-option">
          <DateRanger
            start={start}
            end={end}
            onStartChange={(value) => setStart(value)}
            onEndChange={(value) => setEnd(value)}
          />
        </div>
        <div className="menu-option pr-2">
          <RiskAnalyticsVTRadio
            riskVT={riskVT}
            onRadioChange={(value) => {
              setRiskVT(value);
            }}
          />
          <RiskAnalyticsUnitRadio
            unitType={unitType}
            onRadioChange={(value) => {
              setUnitType(value);
            }}
          />
        </div>
        <div className="menu-option pl-5">
          <RiskAnalyticsAggrRadio
            aggrType={aggrType}
            onRadioChange={(value) => {
              setAggrType(value);
            }}
          />
          <RiskAnalyticsThroughTimeSelector />
        </div>
        <div className="menu-option">
          <GraphViewType
            dropdownOptions={throughtimeGVTOptions}
            onSelection={(index) => setGraphVT(index.value)}
          />
        </div>
      </div>
      <hr />
      <div className="fixme-container"></div>
    </div>
  );
}
