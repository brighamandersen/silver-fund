import React from "react";
import Spinner from "react-bootstrap/Spinner";

export default function RiskAnalyticsBarChart(props) {
  return (
    <>
      {props.valuesData && props.valuesData.date ? (
        <div className="fixme-container" />
      ) : (
        <div>
          <Spinner
            animation="border"
            variant="dark"
            className="loading-spinner"
          />
        </div>
      )}
    </>
  );
}
