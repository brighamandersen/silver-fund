import "./RiskAnalytics.css";

import React, { useState, useEffect } from "react";
import axios from "axios";

import { rASnapshotGVTOptions } from "../common/constants";
import { getDateStr } from "../common/helpers";
import MsgBanner from "../common/MsgBanner";
import GraphViewType from "../common/GraphViewType";
import DateSingler from "../common/DateSingler";
import RiskAnalyticsVTRadio from "./RiskAnalyticsVTRadio";
import RiskAnalyticsSnapshotTable from "./RiskAnalyticsSnapshotTable";
import RiskAnalyticsBarChart from "./RiskAnalyticsBarChart";

export default function RiskAnalyticsSnapshot() {
  const [errorMsg, setErrorMsg] = useState(null);
  const [apiSnapshot, setApiSnapshot] = useState({});
  const [graphVT, setGraphVT] = useState(0);
  const [riskVT, setRiskVT] = useState("total");
  const [date, setDate] = useState(getDateStr(-1));
  const [showGraphics, setShowGraphics] = useState(false);

  /* Get api data for risk */
  useEffect(() => {
    setErrorMsg(null);
    setApiSnapshot({});
    setShowGraphics(true);

    axios
      .get("api/performance/filter/date/", {
        params: {
          start: date,
        },
      })
      .then((response) => {
        let resData = response.data[0];
        console.log("Risk Snapshot on " + date, resData);
        if (resData === undefined) {
          setShowGraphics(false);
          setErrorMsg("Invalid date selected.  Try a different selection.");
        } else {
          // Round down values to 3 decimal places
          for (let key in resData) {
            if (typeof resData[key] === "number") {
              resData[key] = Math.round(resData[key] * 1000) / 1000;
            }
          }
        }
        setApiSnapshot(resData);
      })
      .catch((error) => {
        console.log(error);
        setShowGraphics(false);
        setErrorMsg(
          "Uh oh! Something went wrong on our end (failed to load risk snapshot data).  If this error persists, contact support."
        );
      });
  }, [date]); // Calls the API to fetch data at first, whenever date changes

  return (
    <>
      <MsgBanner
        type="error"
        msg={errorMsg}
        setMsg={(value) => setErrorMsg(value)}
      />
      <div className="content">
        <div className="pane-menu">
          <div className="menu-option l-menu-option">
            <DateSingler
              date={date}
              onDateChange={(value) => {
                setDate(value);
              }}
            />
          </div>
          <div className="menu-option m-menu-option">
            <RiskAnalyticsVTRadio
              riskVT={riskVT}
              onRadioChange={(value) => {
                setRiskVT(value);
              }}
            />
          </div>
          <div className="menu-option">
            <GraphViewType
              dropdownOptions={rASnapshotGVTOptions}
              onSelection={(index) => setGraphVT(index.value)}
            />
          </div>
        </div>
        <hr />
        {showGraphics && (
          <div className="pane-split-container">
            <div className="left-col">
              <RiskAnalyticsSnapshotTable tableData={apiSnapshot} />
            </div>
            <div className="right-col">
              <RiskAnalyticsBarChart valuesData={apiSnapshot} />
            </div>
          </div>
        )}
      </div>
    </>
  );
}
