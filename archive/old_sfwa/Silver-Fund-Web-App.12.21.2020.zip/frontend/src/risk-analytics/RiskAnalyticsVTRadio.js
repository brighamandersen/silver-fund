import React from "react";

export default function RiskAnalyticsVTRadio(props) {
  return (
    <div style={{ width: "233px" }} className="m-1">
      <label className="input-label pt-2 pl-1">Risk View Type:</label>
      <div
        style={{
          paddingTop: "7px",
        }}
      >
        <div className="d-inline pl-3 p-2">
          <label className="radio-label">
            <input
              type="radio"
              className="radio-input d-block mx-auto w-100 "
              value="total"
              checked={props.riskVT === "total"}
              onChange={(e) => props.onRadioChange(e.target.value)}
            />
            Total
          </label>
        </div>
        <div className="d-inline p-2">
          <label className="radio-label">
            <input
              type="radio"
              className="radio-input d-block mx-auto w-100 "
              value="active"
              checked={props.riskVT === "active"}
              onChange={(e) => props.onRadioChange(e.target.value)}
            />
            Active
          </label>
        </div>
      </div>
    </div>
  );
}
