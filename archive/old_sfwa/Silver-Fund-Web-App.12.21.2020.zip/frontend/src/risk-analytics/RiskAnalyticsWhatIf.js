import React, { useState } from "react";

import MsgBanner from "../common/MsgBanner";
import RiskAnalyticsVTRadio from "./RiskAnalyticsVTRadio";
import RiskAnalyticsWhatIfStocksTable from "./RiskAnalyticsWhatIfStocksTable";
import RiskAnalyticsWhatIfStatsTable from "./RiskAnalyticsWhatIfStatsTable";

export default function RiskAnalyticsWhatIfAnalysis() {
  const [errorMsg, setErrorMsg] = useState(null);
  const [riskVT, setRiskVT] = useState("total");

  return (
    <>
      <MsgBanner
        type="error"
        msg={errorMsg}
        setMsg={(value) => setErrorMsg(value)}
      />
      <div className="content">
        <div className="pane-split-container">
          <div className="left-col">
            <RiskAnalyticsVTRadio
              riskVT={riskVT}
              onRadioChange={(value) => {
                setRiskVT(value);
              }}
            />
            <br />
            <br />
            <RiskAnalyticsWhatIfStocksTable
              setErrorMsg={(value) => setErrorMsg(value)}
            />
            <br />
            <br />
          </div>
          <div className="right-col">
            <RiskAnalyticsWhatIfStatsTable />
          </div>
        </div>
      </div>
    </>
  );
}
