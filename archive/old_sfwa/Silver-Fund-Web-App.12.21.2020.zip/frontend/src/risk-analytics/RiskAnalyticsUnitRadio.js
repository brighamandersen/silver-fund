import React from "react";

export default function RiskAnalyticsUnitRadio(props) {
  return (
    <div style={{ width: "420px" }} className="m-1">
      <label className="input-label pt-2 pl-2">Analytical Unit Type:</label>
      <div
        style={{
          paddingTop: "7px",
        }}
      >
        <div className="d-inline p-2">
          <label className="radio-label">
            <input
              type="radio"
              className="radio-input d-block mx-auto w-100 "
              value="portfolio"
              checked={props.unitType === "portfolio"}
              onChange={(e) => props.onRadioChange(e.target.value)}
            />
            Portfolio
          </label>
        </div>
        <div className="d-inline p-2">
          <label className="radio-label">
            <input
              type="radio"
              className="radio-input d-block mx-auto w-100 "
              value="industry"
              checked={props.unitType === "industry"}
              onChange={(e) => props.onRadioChange(e.target.value)}
            />
            Industry
          </label>
        </div>
        <div className="d-inline p-2">
          <label className="radio-label">
            <input
              type="radio"
              className="radio-input d-block mx-auto w-100 "
              value="factor"
              checked={props.unitType === "factor"}
              onChange={(e) => props.onRadioChange(e.target.value)}
            />
            Factor
          </label>
        </div>
        <div className="d-inline p-2">
          <label className="radio-label">
            <input
              type="radio"
              className="radio-input d-block mx-auto w-100 "
              value="stock"
              checked={props.unitType === "stock"}
              onChange={(e) => props.onRadioChange(e.target.value)}
            />
            Stock
          </label>
        </div>
      </div>
    </div>
  );
}
