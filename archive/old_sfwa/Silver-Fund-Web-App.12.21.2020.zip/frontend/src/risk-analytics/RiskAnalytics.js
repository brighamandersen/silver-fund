import React from "react";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";

import RiskAnalyticsSnapshot from "./RiskAnalyticsSnapshot";
import RiskAnalyticsThroughTime from "./RiskAnalyticsThroughTime";
import RiskAnalyticsWhatIf from "./RiskAnalyticsWhatIf";

export default function RiskAnalytics() {
  return (
    <>
      <Tabs className="sub-pane" defaultActiveKey="snapshot" transition={false}>
        <Tab eventKey="snapshot" title="Portfolio Snapshot">
          <RiskAnalyticsSnapshot />
        </Tab>
        <Tab eventKey="throughtime" title="Portfolio Risk Through Time">
          <RiskAnalyticsThroughTime />
        </Tab>
        <Tab eventKey="whatif" title="What-If Analysis">
          <RiskAnalyticsWhatIf />
        </Tab>
      </Tabs>
    </>
  );
}
