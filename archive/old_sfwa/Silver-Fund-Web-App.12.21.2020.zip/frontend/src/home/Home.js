import React, { useState } from "react";

import sfLogo from "../images/sf-logo-white.png";
import MsgBanner from "../common/MsgBanner";
import HomeChangePassword from "./HomeChangePassword";

export default function Home(props) {
  const [msgType, setMsgType] = useState("error");
  const [msg, setMsg] = useState(null);

  return (
    <>
      <MsgBanner type={msgType} msg={msg} setMsg={(value) => setMsg(value)} />
      <div className="content">
        <div className="left-col">
          <h3>{props.username}, Welcome to the Silver Fund Web App!</h3>
          <a
            className="btn m-4"
            href="https://byu.sharepoint.com/sites/silverfund-wiki"
            target="_blank"
            rel="noopener noreferrer"
          >
            Documentation
          </a>
          <a
            className="btn black-btn m-4"
            href="mailto:silverfund@byu.edu?subject=Question about Web App" // FIXME - Add valid email address
          >
            Contact Us
          </a>
          <HomeChangePassword
            username={props.username}
            password={props.password}
            changeMsg={(t, m) => {
              setMsgType(t);
              setMsg(m);
            }}
            clearMsg={() => setMsg(null)}
          />
        </div>
        <img
          src={sfLogo}
          className="home-logo"
          style={{ height: "500px", marginLeft: "80px", marginTop: "40px" }}
          alt=""
        />
      </div>
    </>
  );
}
