import React from "react";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";

import PositionsSnapshot from "./PositionsSnapshot";
import PositionsHistory from "./PositionsHistory";

export default function Positions() {
  return (
    <>
      <Tabs className="sub-pane" defaultActiveKey="snapshot" transition={false}>
        <Tab eventKey="snapshot" title="Snapshot (Bar Chart View)">
          <PositionsSnapshot />
        </Tab>
        <Tab
          eventKey="historybystock"
          title="History by Stock (Time Series View)"
        >
          <PositionsHistory />
        </Tab>
        <Tab eventKey="attribution" title="Position Attribution" disabled>
          ** Add PositionsAttribution Component here **
        </Tab>
      </Tabs>
    </>
  );
}
