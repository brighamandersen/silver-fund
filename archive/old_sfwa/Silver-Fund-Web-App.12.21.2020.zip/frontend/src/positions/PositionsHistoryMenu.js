import React from "react";

import DateRanger from "../common/DateRanger";
import GraphViewType from "../common/GraphViewType";
import TickerSelector from "../common/TickerSelector";
import { positionsGVTOptions } from "../common/constants";

export default function PositionsHistoryMenu(props) {
  return (
    <>
      <div className="d-inline-block">
        <DateRanger
          start={props.start}
          end={props.end}
          onStartChange={(value) => props.setStart(value)}
          onEndChange={(value) => props.setEnd(value)}
        />
      </div>
      <div className="ticker-selector d-inline-block ml-4">
        <TickerSelector
          optionsData={props.apiPositions}
          onSubmit={(newValue) => props.setSelectedPositions(newValue)}
        />
      </div>
      <GraphViewType
        dropdownOptions={positionsGVTOptions}
        onSelection={(index) => props.setGraphVT(index.value)}
      />
      <hr />
    </>
  );
}
