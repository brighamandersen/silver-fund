import React from "react";
import { HorizontalBar } from "react-chartjs-2";
import Spinner from "react-bootstrap/Spinner";

import { formatAsCurrency, formatAsPercentage } from "../common/helpers";

export default function PositionsBarChart(props) {
  return (
    <>
      {props.tickerData && props.tickerData.length > 0 ? (
        <div
          style={{
            backgroundColor: "#f7f7f7",
            paddingRight: "35px",
            paddingBottom: "10px",
            border: "5px solid #cfcfcf",
            borderRadius: "15px",
          }}
          className="mt-0 mb-4"
        >
          <HorizontalBar
            data={{
              labels: props.tickerData,
              datasets: [
                {
                  label: props.tool_tip_label,
                  data: props.valuesData,
                  backgroundColor: "#3f5f80",
                  barPercentage: 0.5,
                  hoverBackgroundColor: "#002e5d",
                },
              ],
            }}
            width={50}
            height={50}
            options={{
              title: {
                display: true,
                fontsize: 40,
                fontColor: "#000000",
              },
              tooltips: {
                multiKeyBackground: "#000",
                mode: "index",
                intersect: false,
                callbacks: {
                  label: function (tooltipItems) {
                    if (props.isCurrency) {
                      return formatAsCurrency(tooltipItems.xLabel);
                    } else {
                      return formatAsPercentage(tooltipItems.xLabel);
                    }
                  },
                },
              },
              legend: {
                display: false,
                position: "right",
                labels: {
                  fontColor: "#000000",
                },
              },
              layout: {
                padding: {
                  left: 50,
                  right: 0,
                  bottom: 0,
                  top: 0,
                },
              },
              scales: {
                xAxes: [
                  {
                    ticks: {
                      callback: function (value) {
                        if (props.isCurrency) {
                          // Remove currency but no decimals.
                          return formatAsCurrency(value).slice(0, -3);
                        } else {
                          return value + "%";
                        }
                      },
                    },
                    stacked: true,
                    scaleLabel: {
                      display: true,
                      labelString: props.x_label,
                      fontSize: 20,
                      fontColor: "#000000",
                    },
                  },
                ],
                yAxes: [
                  {
                    ticks: {
                      fontColor: "#000000",
                      fontSize: 14,
                    },
                  },
                ],
              },
            }}
          />
        </div>
      ) : (
        <div>
          <Spinner
            animation="border"
            variant="dark"
            className="loading-spinner"
          />
        </div>
      )}
    </>
  );
}
