import React from "react";

import DateSingler from "../common/DateSingler";
import GraphViewType from "../common/GraphViewType";
import { positionsGVTOptions } from "../common/constants";

export default function PositionsSnapshotMenu(props) {
  return (
    <>
      <div className="d-inline-block">
        <DateSingler
          date={props.date}
          onDateChange={(value) => {
            props.setDate(value);
          }}
        />
      </div>
      <div className="float-right">
        <GraphViewType
          dropdownOptions={positionsGVTOptions}
          onSelection={(index) => props.setGraphVT(index.value)}
        />
      </div>
      <hr />
    </>
  );
}
