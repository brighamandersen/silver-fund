import React from "react";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";

export default function Performance() {
  return (
    <>
      <Tabs
        className="sub-pane"
        defaultActiveKey="timeseries"
        transition={false}
      >
        <Tab eventKey="timeseries" title="Time Series">
          ** Add PerformanceTimeSeries Component here **
        </Tab>
        <Tab eventKey="barchart" title="Bar Chart">
          ** Add PerformanceBarChart Component here **
        </Tab>
      </Tabs>
    </>
  );
}
