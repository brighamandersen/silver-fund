import React from "react";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";

import Home from "../home/Home";
import Positions from "../positions/Positions";
import TradeHistory from "../trade-history/TradeHistory";
import RiskAnalytics from "../risk-analytics/RiskAnalytics";
import Performance from "../performance/Performance";
import PortfolioConstruction from "../portfolio-construction/PortfolioConstruction";

export default function Panes(props) {
  return (
    <Tabs className="pane" defaultActiveKey="riskanalytics" transition={false}>
      <Tab eventKey="home" title="Home">
        <Home username={props.username} password={props.password} />
      </Tab>
      <Tab eventKey="positions" title="Positions">
        <Positions />
      </Tab>
      <Tab eventKey="tradehistory" title="Trade History">
        <TradeHistory />
      </Tab>
      <Tab eventKey="portfolioconstruction" title="Portfolio Construction">
        <PortfolioConstruction username={props.username} />
      </Tab>
      <Tab eventKey="riskanalytics" title="Risk Analytics">
        <RiskAnalytics />
      </Tab>
      <Tab eventKey="performance" title="Performance" disabled>
        <Performance />
      </Tab>
    </Tabs>
  );
}
