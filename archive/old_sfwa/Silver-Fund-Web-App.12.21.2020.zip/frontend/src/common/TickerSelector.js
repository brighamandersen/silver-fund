import React, { useState, useEffect } from "react";
import Select from "react-select";

import { customRSTheme } from "./constants";

export default function TickerSelector(props) {
  const [tickerFilter, setTickerFilter] = useState([]);
  let tickerOptions = props.optionsData.map(({ ticker }) => ticker);
  tickerOptions = [...new Set(tickerOptions)];

  tickerOptions = tickerOptions.map((item) => ({
    value: item,
    label: item,
  }));

  function filterAllData() {
    if (!tickerFilter) {
      props.onSubmit(props.optionsData);
      return props.optionsData;
    }
    const tickers = tickerFilter.map(({ value }) => value);
    let newData = [];
    for (let i = 0; i < tickers.length; ++i) {
      const filterData = props.optionsData.filter(function (item) {
        return item.ticker === tickers[i];
      });
      newData.push.apply(newData, filterData);
    }

    if (newData.length !== 0) {
      props.onSubmit(newData);
      return newData;
    } else {
      props.onSubmit(props.optionsData);
      return props.optionsData;
    }
  }

  useEffect(() => {
    filterAllData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tickerFilter]);

  return (
    <>
      {props.optionsData && props.optionsData.length > 0 ? (
        <>
          <Select
            theme={customRSTheme}
            options={tickerOptions}
            noOptionsMessage={() => "All tickers have been selected."}
            placeholder="Filter by Ticker"
            onChange={setTickerFilter}
            isMulti
            isSearchable
          />
        </>
      ) : (
        <Select isDisabled placeholder="Select date(s) first." />
      )}
    </>
  );
}
