import { formatAsAmount, formatAsCurrency } from "./helpers";
import React from "react";

/* URL for AWS Backend -- for all api calls */
// export const apiBackendUrl = "https://47fund-dev.byu.edu:4443/";
export const apiBackendUrl = "http://localhost:8000/";

export const positionsGVTOptions = [
  { value: 0, label: "$ Positions by Stock" },
  { value: 1, label: "% Positions by Stock" },
  { value: 2, label: "$ Positions vs. Benchmark by Stock", disabled: true },
  { value: 3, label: "% Positions vs. Benchmark by Stock", disabled: true },
  { value: 4, label: "$ Positions by Industry", disabled: true },
  { value: 5, label: "% Positions by Industry", disabled: true },
  {
    value: 6,
    label: "$ Positions vs. Benchmark by Industry",
    disabled: true,
  },
  {
    value: 7,
    label: "% Positions vs. Benchmark by Industry",
    disabled: true,
  },
];

export const positionsTableCols = [
  {
    Header: "Asset ID",
    accessor: "asset_id",
  },
  {
    Header: "Ticker",
    accessor: "ticker",
  },
  {
    Header: "# of Shares",
    accessor: "num_of_shares",
    Cell: (props) => <div> {formatAsAmount(props.value)}</div>,
    sortType: "basic",
  },
  {
    Header: "Type",
    accessor: "asset_type",
  },
  {
    Header: "Price",
    accessor: "price",
    Cell: (props) => <div> {formatAsCurrency(props.value)}</div>,
    sortType: "basic",
  },
  {
    Header: "Value",
    accessor: "position_value",
    Cell: (props) => <div> {formatAsCurrency(props.value)}</div>,
    sortType: "basic",
  },
  {
    Header: "Date",
    accessor: "date",
  },
];

export const tradeHistoryTableCols = [
  {
    Header: "Trade ID",
    accessor: "trade_id",
  },
  {
    Header: "Asset ID",
    accessor: "asset_id",
  },
  {
    Header: "Ticker",
    accessor: "ticker",
  },
  {
    Header: "Type",
    accessor: "trade_type",
  },
  {
    Header: "# of Shares",
    accessor: "num_of_shares",
    Cell: (props) => <div> {formatAsAmount(props.value)}</div>,
    sortType: "basic",
  },
  {
    Header: "Price",
    accessor: "price",
    Cell: (props) => <div> {formatAsCurrency(props.value)}</div>,
    sortType: "basic",
  },
  {
    Header: "Total Price",
    accessor: "tot_price",
    Cell: (props) => <div> {formatAsCurrency(props.value)}</div>,
    sortType: "basic",
  },
  {
    Header: "Status",
    accessor: "trade_status",
  },
  {
    Header: "Trade Time",
    accessor: "trade_time",
  },
];

export const rASnapshotGVTOptions = [
  { value: 0, label: "Bar Chart for Top 10 Stocks by Risk" },
  {
    value: 1,
    label: "Bar Chart for Top 10 Stocks by Partial Contribution to Risk",
  },
  { value: 2, label: "Bar Chart for Top 10 Stocks by Contribution to Risk" },
  { value: 3, label: "Bar Chart for Top 10 Industries by Risk" },
  {
    value: 4,
    label: "Bar Chart for Top 10 Industries by Partial Contribution to Risk",
  },
  {
    value: 5,
    label: "Bar Chart for Top 10 Industries by Contribution to Risk",
  },
  { value: 6, label: "Bar Chart of All Style Exposures" },
  { value: 7, label: "Bar Chart of Risk for Each Style Factor" },
  {
    value: 8,
    label: "Bar Chart for Partial Contribution to by Style Factor",
  },
  { value: 9, label: "Bar Chart for Contribution to Risk by Style Factor" },
];

/* Custom theme for React Select */
export function customRSTheme(theme) {
  return {
    ...theme,
    colors: {
      ...theme.colors,
      primary25: "#cfcfcf",
      primary: "#002e5d",
    },
  };
}
