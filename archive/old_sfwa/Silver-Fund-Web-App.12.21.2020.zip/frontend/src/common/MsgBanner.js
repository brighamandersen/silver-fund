import React from "react";

export default function MsgBanner(props) {
  function typeToBackgroundColor(type) {
    switch (type) {
      case "error":
        return "#e53935";
      case "success":
        return "#0fb56d";
      default:
        return "#e53935";
    }
  }

  return (
    <>
      {props.msg && (
        <div
          className="msg-banner"
          style={{
            backgroundColor: typeToBackgroundColor(props.type),
          }}
        >
          {props.msg}
          <span className="msg-banner-x" onClick={() => props.setMsg(null)}>
            🞬
          </span>
        </div>
      )}
    </>
  );
}
