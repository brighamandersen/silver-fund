import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import axios from "axios";
import { apiBackendUrl } from "./common/constants";

axios.defaults.baseURL = apiBackendUrl;
axios.defaults.auth = {
  username: "api_auth",
  password: "Seeking4Alpha",
};

ReactDOM.render(<App />, document.getElementById("root"));
