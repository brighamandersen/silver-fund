import "./styles.css";

import React, { useState } from "react";
import axios from "axios";

import { useLocalState } from "./common/helpers";
import Header from "./common/Header";
import Panes from "./common/Panes";
import MsgBanner from "./common/MsgBanner";
import Signin from "./signin/Signin";
import Footer from "./common/Footer";

export default function App() {
  const [token, setToken] = useLocalState("token");
  const [username, setUsername] = useLocalState("username");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState(null);

  function signIn() {
    setLoginError(null);

    if (username === "") {
      setLoginError("No username was entered.");
      return;
    }

    if (password === "") {
      setLoginError("No password was entered.");
      return;
    }

    axios
      .post("api/login/", {
        username: username,
        password: password,
      })
      .then((response) => {
        console.log("Successfully logged in: ", username);
        setToken(response.data.token);
        setUsername(username);
      })
      .catch((error) => {
        console.log(error);
        setLoginError(
          "Oops!  Invalid credentials.  Try again.  If you can't remember your credentials or keep seeing this, contact support."
        );
        setUsername("");
        setPassword("");
      });
  }

  function signOut() {
    setToken(null);
    localStorage.removeItem("token");
    setUsername("");
    localStorage.setItem("username", "");
    setPassword("");
    window.location.reload(true);
  }

  return (
    <>
      <Header token={token} signOut={signOut} />
      {token ? (
        <Panes username={username} password={password} />
      ) : (
        <>
          <MsgBanner
            type="error"
            msg={loginError}
            setMsg={(value) => setLoginError(value)}
          />
          <Signin
            username={username}
            setUsername={setUsername}
            password={password}
            setPassword={setPassword}
            signinPress={() => signIn()}
          />
        </>
      )}
      <Footer />
    </>
  );
}
