from django.db import models
from django.utils import timezone
from datetime import datetime


class Equity_Security_Master(models.Model):
    class Meta:
        verbose_name_plural = "equity security master"

    asset_id = models.CharField(
        verbose_name="asset id",
        max_length=40,
        null=False,
        blank=False,
        default="needs_id",
        primary_key=True,
    )
    ticker = models.CharField(
        verbose_name="ticker", max_length=40, null=True, blank=True
    )
    comnam = models.CharField(
        verbose_name="Company Name", max_length=40, null=True, blank=True
    )
    conid = models.CharField(verbose_name="conid", max_length=40, null=True, blank=True)
    cusip = models.CharField(verbose_name="cusip", max_length=40, null=True, blank=True)
    isin = models.CharField(verbose_name="isin", max_length=40, null=True, blank=True)
    valid_date = models.DateField(default=timezone.now)
    siccd = models.CharField(
        verbose_name="industry code", max_length=40, null=True, blank=True
    )
    country_code = models.CharField(
        verbose_name="country code", max_length=40, null=True, blank=True
    )
    prim_exch = models.CharField(
        verbose_name="prim exch", max_length=40, null=True, blank=True
    )
    currency = models.CharField(
        verbose_name="currency", max_length=40, null=True, blank=True
    )
    bnchmrk = models.CharField(
        verbose_name="benchmark", max_length=40, null=True, blank=True
    )

    def __str__(self):
        return self.asset_id


class Position(models.Model):
    asset = models.OneToOneField(
        Equity_Security_Master,
        related_name="positions",
        on_delete=models.PROTECT,
        verbose_name="asset id",
        primary_key=True,
    )
    ticker = models.CharField(
        verbose_name="ticker", max_length=40, null=True, blank=True
    )
    num_of_shares = models.IntegerField(
        verbose_name="num of shares", null=True, blank=True
    )
    asset_type = models.CharField(
        verbose_name="asset type", max_length=40, null=True, blank=True
    )
    price = models.FloatField(verbose_name="price", null=True, blank=True)
    position_value = models.FloatField(
        verbose_name="position value", null=True, blank=True
    )
    date = models.DateField(default=timezone.now)

    def __str__(self):
        return self.ticker


class Trade(models.Model):
    trade_id = models.CharField(
        verbose_name="trade id",
        max_length=40,
        null=False,
        blank=False,
        primary_key=True,
    )
    asset = models.OneToOneField(
        Equity_Security_Master,
        related_name="trades",
        on_delete=models.PROTECT,
        verbose_name="asset id",
    )
    trade_type = models.CharField(
        verbose_name="trade type", max_length=40, null=True, blank=True
    )
    num_of_shares = models.IntegerField(
        verbose_name="num of shares", null=True, blank=True
    )
    price = models.FloatField(verbose_name="price", null=True, blank=True)
    tot_price = models.FloatField(verbose_name="tot price", null=True, blank=True)
    trade_status = models.CharField(
        verbose_name="status", max_length=40, null=True, blank=True
    )
    trade_time = models.CharField(
        verbose_name="date time", max_length=40, null=True, blank=True
    )

    def __str__(self):
        return self.trade_id


class Market_Data(models.Model):
    asset = models.ForeignKey(
        Equity_Security_Master,
        related_name="market_data",
        on_delete=models.PROTECT,
        verbose_name="asset id",
    )
    caldt = models.DateTimeField(verbose_name="date", null=False, blank=False)
    shrcd = models.CharField(
        verbose_name="share code", max_length=40, null=True, blank=True
    )
    siccd = models.CharField(
        verbose_name="sic code", max_length=40, null=True, blank=True
    )
    prc = models.FloatField(verbose_name="close price", null=True, blank=True)
    vol = models.IntegerField(verbose_name="volume", null=True, blank=True)
    ret = models.FloatField(verbose_name="return", null=True, blank=True)
    shr = models.FloatField(verbose_name="shares outstanding", null=True, blank=True)
    rf = models.FloatField(verbose_name="risk free rate", null=True, blank=True)


class ForeignExchange(models.Model):
    country_code = models.CharField(
        verbose_name="country code",
        max_length=40,
        null=False,
        blank=False,
        primary_key=True,
    )
    date = models.DateTimeField(verbose_name="date", null=True, blank=True)
    exchange_rate = models.FloatField(
        verbose_name="exchange rate", null=True, blank=True
    )
    thirty_day_rate = models.FloatField(
        verbose_name="thirty day rate", null=True, blank=True
    )
    ninety_day_rate = models.FloatField(
        verbose_name="ninety day rate", null=True, blank=True
    )
    one_eighty_day_rate = models.FloatField(
        verbose_name="one eighty day rate", null=True, blank=True
    )
    one_year_rate = models.FloatField(
        verbose_name="one year rate", null=True, blank=True
    )
    two_year_rate = models.FloatField(
        verbose_name="two year rate", null=True, blank=True
    )
    three_year_rate = models.FloatField(
        verbose_name="three year rate", null=True, blank=True
    )
    five_year_rate = models.FloatField(
        verbose_name="five year rate", null=True, blank=True
    )
    seven_year_rate = models.FloatField(
        verbose_name="seven year rate", null=True, blank=True
    )
    ten_year_rate = models.FloatField(
        verbose_name="ten year rate", null=True, blank=True
    )
    twenty_year_rate = models.FloatField(
        verbose_name="twenty year rate", null=True, blank=True
    )
    thirty_year_rate = models.FloatField(
        verbose_name="thirty year rate", null=True, blank=True
    )


class Live_Target_Portfolio(models.Model):
    class Meta:
        verbose_name_plural = "live target portfolio"

    asset = models.ForeignKey(
        Equity_Security_Master,
        related_name="live_target_portfolio",
        on_delete=models.PROTECT,
        verbose_name="asset id",
        null=True,
        blank=True,
    )
    ticker = models.CharField(max_length=40)
    model_er = models.FloatField(verbose_name="model expected return")
    annualized_er = models.FloatField(verbose_name="annualized expected return")
    beta_to_b = models.FloatField(verbose_name="beta to benchmark")
    alpha = models.FloatField()
    oa_weight = models.FloatField(verbose_name="optimal active weight")
    b_weight = models.FloatField(verbose_name="weight in benchmark")
    c_weight = models.FloatField(verbose_name="current weight")
    backlog = models.FloatField()
    backlog_risk = models.FloatField()
    commit_maker = models.CharField(
        max_length=40, null=True, blank=True, default="anonymous"
    )
    is_latest = models.BooleanField(default=False)
    commit_time = models.CharField(
        default=datetime.now().strftime("%Y-%m-%d@%H:%M:%S"),
        max_length=40,
        editable=False,
    )

    def __str__(self):
        return self.ticker


class Portfolio_ExAnte_Stats(models.Model):
    class Meta:
        verbose_name_plural = "portfolio ex-ante stats"

    expected_return = models.FloatField(null=True, blank=True)
    beta_to_b = models.FloatField(
        verbose_name="beta to benchmark", null=True, blank=True
    )
    alpha_to_b = models.FloatField(
        verbose_name="alpha to benchmark", null=True, blank=True
    )
    info_ratio = models.FloatField(
        verbose_name="informational ratio", null=True, blank=True
    )
    commit_maker = models.CharField(
        max_length=40, null=True, blank=True, default="anonymous"
    )
    is_latest = models.BooleanField(default=True)
    commit_time = models.CharField(
        default=datetime.now().strftime("%Y-%m-%d@%H:%M:%S"),
        max_length=40,
        editable=False,
    )

    def __str__(self):
        return self.commit_maker + "'s commit on " + self.commit_time


class Exposures(models.Model):
    # index = models.FloatField(verbose_name="index", null=True, blank=True)
    # FIXME this needs to be added back in when we have Equity Security up

    # id = models.AutoField(
    #     verbose_name="record id", 
    #     null=False, 
    #     blank=False,
    #     primary_key=True,
    #     unique = True
    # )

    asset = models.ForeignKey(
        Equity_Security_Master,
        on_delete=models.PROTECT,
        verbose_name="asset id",
        default='84788'
    )

    caldt = models.DateTimeField(verbose_name="date", null=False, blank=False)

    shrcd = models.FloatField(verbose_name="shrcd", null=True, blank=True)
    siccd = models.FloatField(verbose_name="siccd", null=True, blank=True)
    prc = models.FloatField(verbose_name="price", null=True, blank=True)
    vol = models.FloatField(verbose_name="volume", null=True, blank=True)
    ret = models.FloatField(verbose_name="ret", null=True, blank=True)
    shr = models.FloatField(verbose_name="share", null=True, blank=True)
    rf = models.FloatField(verbose_name="rf", null=True, blank=True)

    agric = models.FloatField(verbose_name="Agriculture", null=True, blank=True)
    food = models.FloatField(verbose_name="Food Products", null=True, blank=True)
    soda = models.FloatField(verbose_name="Candy & Soda", null=True, blank=True)
    beer = models.FloatField(verbose_name="Beer & Liquor", null=True, blank=True)
    smoke = models.FloatField(verbose_name="Tobacco Products", null=True, blank=True)
    toys = models.FloatField(verbose_name="Recreation", null=True, blank=True)
    fun = models.FloatField(verbose_name="Entertainment", null=True, blank=True)
    books = models.FloatField(
        verbose_name="Printing and Publishing", null=True, blank=True
    )
    hshld = models.FloatField(verbose_name="Consumer Goods", null=True, blank=True)
    clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    hlth = models.FloatField(verbose_name="Healthcare", null=True, blank=True)
    medeq = models.FloatField(verbose_name="Medical Equipment", null=True, blank=True)
    drugs = models.FloatField(
        verbose_name="Pharmaceutical Products", null=True, blank=True
    )
    chems = models.FloatField(verbose_name="Chemicals", null=True, blank=True)
    rubbr = models.FloatField(
        verbose_name="Rubber and Plastic Products", null=True, blank=True
    )
    txtls = models.FloatField(verbose_name="Textiles", null=True, blank=True)
    bldmt = models.FloatField(
        verbose_name="construction materials", null=True, blank=True
    )
    cnstr = models.FloatField(verbose_name="Construction", null=True, blank=True)
    steel = models.FloatField(verbose_name="Steel Works Etc", null=True, blank=True)
    fabpr = models.FloatField(verbose_name="Fabricated Products", null=True, blank=True)
    mach = models.FloatField(verbose_name="Machinery", null=True, blank=True)
    elceq = models.FloatField(
        verbose_name="Electrical Equipment", null=True, blank=True
    )
    autos = models.FloatField(verbose_name="Autos", null=True, blank=True)
    aero = models.FloatField(verbose_name="Aircraft", null=True, blank=True)
    ships = models.FloatField(
        verbose_name="Shipbuilding, Railroad Equipment", null=True, blank=True
    )
    guns = models.FloatField(verbose_name="Defense", null=True, blank=True)
    gold = models.FloatField(verbose_name="Precious Metals", null=True, blank=True)
    mines = models.FloatField(
        verbose_name="Non and &sic le Metallic and Industrial Metal Mining",
        null=True,
        blank=True,
    )
    coal = models.FloatField(verbose_name="Coal", null=True, blank=True)
    oil = models.FloatField(
        verbose_name="Petroleum and Natural Gas", null=True, blank=True
    )
    util = models.FloatField(verbose_name="Utilities", null=True, blank=True)
    telcm = models.FloatField(verbose_name="Communication", null=True, blank=True)
    persv = models.FloatField(verbose_name="Personal Services", null=True, blank=True)
    bussv = models.FloatField(verbose_name="Business Services", null=True, blank=True)
    hardw = models.FloatField(verbose_name="Hardware", null=True, blank=True)
    softw = models.FloatField(verbose_name="Software", null=True, blank=True)
    chips = models.FloatField(
        verbose_name="Electronic Equipment", null=True, blank=True
    )
    labeq = models.FloatField(
        verbose_name="Measuring and Control Equipment", null=True, blank=True
    )
    paper = models.FloatField(verbose_name="Business Supplies", null=True, blank=True)
    boxes = models.FloatField(verbose_name="Shipping Containers", null=True, blank=True)
    trans = models.FloatField(verbose_name="Transportation", null=True, blank=True)
    whlsl = models.FloatField(verbose_name="Wholesale", null=True, blank=True)
    rtail = models.FloatField(verbose_name="Retail", null=True, blank=True)
    meals = models.FloatField(
        verbose_name="Restaraunts, Hotels, Motels", null=True, blank=True
    )
    banks = models.FloatField(verbose_name="Banking", null=True, blank=True)
    insur = models.FloatField(verbose_name="Insurance", null=True, blank=True)
    rlest = models.FloatField(verbose_name="RIEST", null=True, blank=True)
    fin = models.FloatField(verbose_name="Trading", null=True, blank=True)
    other = models.FloatField(verbose_name="Almost Nothing", null=True, blank=True)

    industrycheck = models.IntegerField(verbose_name="Industrycheck", null=True, blank=True)
    country = models.FloatField(verbose_name="Country", null=True, blank=True)
    ind_str = models.CharField(verbose_name="Industry String", max_length=60, null=True, blank=True)
    size = models.FloatField(verbose_name="Size", null=True, blank=True)
    mktbeta = models.FloatField(verbose_name="Market Beta", null=True, blank=True)
    mktbetaresid = models.FloatField(
        verbose_name="Market Beta Residual", null=True, blank=True
    )
    momentum = models.FloatField(verbose_name="Momentum", null=True, blank=True)
    liquidity = models.FloatField(verbose_name="Liquidity", null=True, blank=True)
    residual_volatility = models.FloatField(
        verbose_name="Residual Volatility", null=True, blank=True
    )
    nonlinear_beta = models.FloatField(
        verbose_name="Nonlinear Beta", null=True, blank=True
    )
    nonlinear_size = models.FloatField(
        verbose_name="Nonlinear Size", null=True, blank=True
    )
    value = models.FloatField(
        verbose_name="value", null=True, blank=True
    )
    
#     clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
#     rlest = models.FloatField(verbose_name="RLEST", null=True, blank=True)
#     book_to_price = models.FloatField(
#         verbose_name="book to price", null=True, blank=True
#     )
#     dividend_yield = models.FloatField(
#         verbose_name="dividend yield", null=True, blank=True
#     )
#     growth = models.FloatField(verbose_name="growth", null=True, blank=True)
#     earnings_yield = models.FloatField(
#         verbose_name="earnings yield", null=True, blank=True
#     )


class Benchmark(models.Model):
    benchmark = models.CharField(
        verbose_name="benchmark", max_length=40, null=True, blank=True
    )
    # asset = models.OneToOneField(
    #     Equity_Security_Master, on_delete=models.PROTECT, verbose_name="asset id",
    # )

    asset = models.ForeignKey(
        Equity_Security_Master, on_delete=models.PROTECT, verbose_name="asset id"
    )

    caldt = models.DateField(default=timezone.now, null=True, blank=True)
    weight = models.FloatField(verbose_name="weight", null=True, blank=True)
    ticker = models.CharField(
        verbose_name="ticker", max_length=40, null=True, blank=True
    )


class Factor_Return(models.Model):
    date = models.DateField(
        default=timezone.now, null=False, blank=False, primary_key=True
    )
    aero = models.FloatField(verbose_name="Aircraft", null=True, blank=True)
    agric = models.FloatField(verbose_name="Agriculture", null=True, blank=True)
    autos = models.FloatField(verbose_name="Autos", null=True, blank=True)
    banks = models.FloatField(verbose_name="Banking", null=True, blank=True)
    beer = models.FloatField(verbose_name="Beer & Liquor", null=True, blank=True)
    bldmt = models.FloatField(
        verbose_name="construction materials", null=True, blank=True
    )
    books = models.FloatField(
        verbose_name="Printing and Publishing", null=True, blank=True
    )
    boxes = models.FloatField(verbose_name="Shipping Containers", null=True, blank=True)
    bussv = models.FloatField(verbose_name="Business Services", null=True, blank=True)
    chems = models.FloatField(verbose_name="Chemicals", null=True, blank=True)
    chips = models.FloatField(
        verbose_name="Electronic Equipment", null=True, blank=True
    )
    clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    # clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    cnstr = models.FloatField(verbose_name="Construction", null=True, blank=True)
    coal = models.FloatField(verbose_name="Coal", null=True, blank=True)
    drugs = models.FloatField(
        verbose_name="Pharmaceutical Products", null=True, blank=True
    )
    elceq = models.FloatField(
        verbose_name="Electrical Equipment", null=True, blank=True
    )
    fabpr = models.FloatField(verbose_name="Fabricated Products", null=True, blank=True)
    fin = models.FloatField(verbose_name="Trading", null=True, blank=True)
    food = models.FloatField(verbose_name="Food Products", null=True, blank=True)
    fun = models.FloatField(verbose_name="Entertainment", null=True, blank=True)
    gold = models.FloatField(verbose_name="Precious Metals", null=True, blank=True)
    guns = models.FloatField(verbose_name="Defense", null=True, blank=True)
    # hardw = models.FloatField(verbose_name="Fabricated Products", null=True, blank=True)
    hardw = models.FloatField(verbose_name="Hardware", null=True, blank=True)
    hlth = models.FloatField(verbose_name="Healthcare", null=True, blank=True)
    hshld = models.FloatField(verbose_name="Consumer Goods", null=True, blank=True)
    insur = models.FloatField(verbose_name="Insurance", null=True, blank=True)
    labeq = models.FloatField(
        verbose_name="Measuring and Control Equipment", null=True, blank=True
    )
    mach = models.FloatField(verbose_name="Machinery", null=True, blank=True)
    meals = models.FloatField(
        verbose_name="Restaraunts, Hotels, Motels", null=True, blank=True
    )
    medeq = models.FloatField(verbose_name="Medical Equipment", null=True, blank=True)
    mines = models.FloatField(
        verbose_name="Non and &sic le Metallic and Industrial Metal Mining",
        null=True,
        blank=True,
    )
    oil = models.FloatField(
        verbose_name="Petroleum and Natural Gas", null=True, blank=True
    )
    other = models.FloatField(verbose_name="Almost Nothing", null=True, blank=True)
    paper = models.FloatField(verbose_name="Business Supplies", null=True, blank=True)
    persv = models.FloatField(verbose_name="Personal Services", null=True, blank=True)
    # riest = models.FloatField(verbose_name="")
    riest = models.FloatField(verbose_name="RIEST", null=True, blank=True)
    rlest = models.FloatField(verbose_name="RLEST", null=True, blank=True)
    rtail = models.FloatField(verbose_name="Retail", null=True, blank=True)
    rubbr = models.FloatField(
        verbose_name="Rubber and Plastic Products", null=True, blank=True
    )
    ships = models.FloatField(
        verbose_name="Shipbuilding, Railroad Equipment", null=True, blank=True
    )
    smoke = models.FloatField(verbose_name="Tobacco Products", null=True, blank=True)
    soda = models.FloatField(verbose_name="Candy & Soda", null=True, blank=True)
    # softw
    softw = models.FloatField(verbose_name="Software", null=True, blank=True)
    steel = models.FloatField(verbose_name="Steel Works Etc", null=True, blank=True)
    telcm = models.FloatField(verbose_name="Communication", null=True, blank=True)
    toys = models.FloatField(verbose_name="Recreation", null=True, blank=True)
    trans = models.FloatField(verbose_name="Transportation", null=True, blank=True)
    txtls = models.FloatField(verbose_name="Textiles", null=True, blank=True)
    util = models.FloatField(verbose_name="Utilities", null=True, blank=True)
    whlsl = models.FloatField(verbose_name="Wholesale", null=True, blank=True)
    country = models.FloatField(verbose_name="Country", null=True, blank=True)

    mktbeta = models.FloatField(verbose_name="Market Beta", null=True, blank=True)
    size = models.FloatField(verbose_name="Size", null=True, blank=True)
    nonlinear_size = models.FloatField(
        verbose_name="Nonlinear Size", null=True, blank=True
    )
    nonlinear_beta = models.FloatField(
        verbose_name="Nonlinear Beta", null=True, blank=True
    )
    residual_volatility = models.FloatField(
        verbose_name="Residual Volatility", null=True, blank=True
    )
    liquidity = models.FloatField(verbose_name="Liquidity", null=True, blank=True)
    momentum = models.FloatField(verbose_name="Momentum", null=True, blank=True)

    book_to_price = models.FloatField(
        verbose_name="book to price", null=True, blank=True
    )
    dividend_yield = models.FloatField(
        verbose_name="dividend yield", null=True, blank=True
    )
    growth = models.FloatField(verbose_name="growth", null=True, blank=True)
    earnings_yield = models.FloatField(
        verbose_name="earnings yield", null=True, blank=True
    )


class Specific_Volatility(models.Model):
    date = models.DateField(
        default=timezone.now, null=False, blank=False, primary_key=True
    )
    horizion = models.CharField(
        verbose_name="horizion", max_length=40, null=True, blank=True
    )
    permno = models.OneToOneField(
        Equity_Security_Master, on_delete=models.PROTECT, verbose_name="asset id"
    )
    volatility = models.FloatField(verbose_name="volatility", null=True, blank=True)


class Variance_Covariance(models.Model):
    date = models.DateField(
        default=timezone.now, null=False, blank=False, primary_key=True
    )
    field_name = models.DateField(verbose_name="field name")

    aero = models.FloatField(verbose_name="Aircraft", null=True, blank=True)
    agric = models.FloatField(verbose_name="Agriculture", null=True, blank=True)
    autos = models.FloatField(verbose_name="Autos", null=True, blank=True)
    banks = models.FloatField(verbose_name="Banking", null=True, blank=True)
    beer = models.FloatField(verbose_name="Beer & Liquor", null=True, blank=True)
    bldmt = models.FloatField(
        verbose_name="construction materials", null=True, blank=True
    )
    books = models.FloatField(
        verbose_name="Printing and Publishing", null=True, blank=True
    )
    boxes = models.FloatField(verbose_name="Shipping Containers", null=True, blank=True)
    bussv = models.FloatField(verbose_name="Business Services", null=True, blank=True)
    chems = models.FloatField(verbose_name="Chemicals", null=True, blank=True)
    chips = models.FloatField(
        verbose_name="Electronic Equipment", null=True, blank=True
    )
    clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    cnstr = models.FloatField(verbose_name="Construction", null=True, blank=True)
    coal = models.FloatField(verbose_name="Coal", null=True, blank=True)
    drugs = models.FloatField(
        verbose_name="Pharmaceutical Products", null=True, blank=True
    )
    elceq = models.FloatField(
        verbose_name="Electrical Equipment", null=True, blank=True
    )
    fabpr = models.FloatField(verbose_name="Fabricated Products", null=True, blank=True)
    fin = models.FloatField(verbose_name="Trading", null=True, blank=True)
    food = models.FloatField(verbose_name="Food Products", null=True, blank=True)
    fun = models.FloatField(verbose_name="Entertainment", null=True, blank=True)
    gold = models.FloatField(verbose_name="Precious Metals", null=True, blank=True)
    guns = models.FloatField(verbose_name="Defense", null=True, blank=True)
    hardw = models.FloatField(verbose_name="Hardware", null=True, blank=True)
    hlth = models.FloatField(verbose_name="Healthcare", null=True, blank=True)
    hshld = models.FloatField(verbose_name="Consumer Goods", null=True, blank=True)
    insur = models.FloatField(verbose_name="Insurance", null=True, blank=True)
    labeq = models.FloatField(
        verbose_name="Measuring and Control Equipment", null=True, blank=True
    )
    mach = models.FloatField(verbose_name="Machinery", null=True, blank=True)
    meals = models.FloatField(
        verbose_name="Restaraunts, Hotels, Motels", null=True, blank=True
    )
    medeq = models.FloatField(verbose_name="Medical Equipment", null=True, blank=True)
    mines = models.FloatField(
        verbose_name="Non and &sic le Metallic and Industrial Metal Mining",
        null=True,
        blank=True,
    )
    oil = models.FloatField(
        verbose_name="Petroleum and Natural Gas", null=True, blank=True
    )
    other = models.FloatField(verbose_name="Almost Nothing", null=True, blank=True)
    paper = models.FloatField(verbose_name="Business Supplies", null=True, blank=True)
    persv = models.FloatField(verbose_name="Personal Services", null=True, blank=True)
    riest = models.FloatField(verbose_name="RIEST", null=True, blank=True)
    rlest = models.FloatField(verbose_name="RLEST", null=True, blank=True)
    rtail = models.FloatField(verbose_name="Retail", null=True, blank=True)
    rubbr = models.FloatField(
        verbose_name="Rubber and Plastic Products", null=True, blank=True
    )
    ships = models.FloatField(
        verbose_name="Shipbuilding, Railroad Equipment", null=True, blank=True
    )
    smoke = models.FloatField(verbose_name="Tobacco Products", null=True, blank=True)
    soda = models.FloatField(verbose_name="Candy & Soda", null=True, blank=True)
    softw = models.FloatField(verbose_name="Software", null=True, blank=True)
    steel = models.FloatField(verbose_name="Steel Works Etc", null=True, blank=True)
    telcm = models.FloatField(verbose_name="Communication", null=True, blank=True)
    toys = models.FloatField(verbose_name="Recreation", null=True, blank=True)
    trans = models.FloatField(verbose_name="Transportation", null=True, blank=True)
    txtls = models.FloatField(verbose_name="Textiles", null=True, blank=True)
    util = models.FloatField(verbose_name="Utilities", null=True, blank=True)
    whlsl = models.FloatField(verbose_name="Wholesale", null=True, blank=True)
    country = models.FloatField(verbose_name="Country", null=True, blank=True)

    mktbetaresid = models.FloatField(
        verbose_name="Market Beta Residual", null=True, blank=True
    )
    mktbeta = models.FloatField(verbose_name="Market Beta", null=True, blank=True)
    size = models.FloatField(verbose_name="Size", null=True, blank=True)
    nonlinear_size = models.FloatField(
        verbose_name="Nonlinear Size", null=True, blank=True
    )
    nonlinear_beta = models.FloatField(
        verbose_name="Nonlinear Beta", null=True, blank=True
    )
    residual_volatility = models.FloatField(
        verbose_name="Residual Volatility", null=True, blank=True
    )
    liquidity = models.FloatField(verbose_name="Liquidity", null=True, blank=True)
    momentum = models.FloatField(verbose_name="Momentum", null=True, blank=True)

    book_to_price = models.FloatField(
        verbose_name="book to price", null=True, blank=True
    )
    dividend_yield = models.FloatField(
        verbose_name="dividend yield", null=True, blank=True
    )
    growth = models.FloatField(verbose_name="growth", null=True, blank=True)
    earnings_yield = models.FloatField(
        verbose_name="earnings yield", null=True, blank=True
    )


class Performance(models.Model):
    date = models.DateField(
        default=timezone.now, null=False, blank=False, primary_key=True
    )
    ex_ante_portfolio_risk_total = models.FloatField(
        verbose_name="ex_ante_portfolio_risk_total", null=True, blank=True
        )
    ex_ante_portfolio_risk_active = models.FloatField(
        verbose_name="ex_ante_portfolio_risk_active", null=True, blank=True
        )
    ex_ante_portfolio_benchmark_beta_total = models.FloatField(
        verbose_name="ex_ante_portfolio_benchmark_beta_total", null=True, blank=True
        )
    ex_ante_portfolio_benchmark_beta_active = models.FloatField(
        verbose_name="ex_ante_portfolio_benchmark_beta_active", null=True, blank=True
        )
    portfolio_diversity_coefficient_total = models.FloatField(
        verbose_name="portfolio_diversity_coefficient_total", null=True, blank=True
        )
    portfolio_diversity_coefficient_active = models.FloatField(
        verbose_name="portfolio_diversity_coefficient_active", null=True, blank=True
        )
    ex_ante_momentum_total = models.FloatField(
        verbose_name="ex_ante_momentum_total", null=True, blank=True
        )
    ex_ante_momentum_active = models.FloatField(
        verbose_name="ex_ante_momentum_active", null=True, blank=True
        )
    ex_ante_size_total = models.FloatField(
        verbose_name="ex_ante_size_total", null=True, blank=True
        )
    ex_ante_size_active = models.FloatField(
        verbose_name="ex_ante_size_active", null=True, blank=True
        )
    ex_ante_value_total = models.FloatField(
        verbose_name="ex_ante_value_total", null=True, blank=True
        )
    ex_ante_value_active = models.FloatField(
        verbose_name="ex_ante_value_active", null=True, blank=True
        )
    ex_ante_quality_total = models.FloatField(
        verbose_name="ex_ante_quality_total", null=True, blank=True
        )
    ex_ante_quality_active = models.FloatField(
        verbose_name="ex_ante_quality_active", null=True, blank=True
        )
    ex_ante_low_volatility_total = models.FloatField(
        verbose_name="ex_ante_low_volatility_total", null=True, blank=True
        )
    ex_ante_low_volatility_active = models.FloatField(
        verbose_name="ex_ante_low_volatility_active", null=True, blank=True
        )
    ex_ante_low_beta_total = models.FloatField(
        verbose_name="ex_ante_low_beta_total", null=True, blank=True
        )
    ex_ante_low_beta_active = models.FloatField(
        verbose_name="ex_ante_low_beta_active", null=True, blank=True
        )


#     ret = models.FloatField(verbose_name="ret", null=True, blank=True)

#     # Expected Return
#     expected_return_annual_s = models.FloatField(
#         verbose_name="expected return annual S", null=True, blank=True
#     )
#     expected_return_daily_s = models.FloatField(
#         verbose_name="expected return daily S", null=True, blank=True
#     )
#     expected_return_annual_l = models.FloatField(
#         verbose_name="expected return annual L", null=True, blank=True
#     )
#     expected_return_daily_l = models.FloatField(
#         verbose_name="expected return daily L", null=True, blank=True
#     )

#     # Exante Standard Deviation (Volatilty)
#     exante_active_daily_volatility_Russell3000_s = models.FloatField(
#         verbose_name="exante active daily volatility Russell 3000 daily S",
#         null=True,
#         blank=True,
#     )
#     exante_active_annual_volatility_Russell3000_s = models.FloatField(
#         verbose_name="exante active daily volatility Russell 3000 annual S",
#         null=True,
#         blank=True,
#     )
#     exante_active_daily_volatility_Russell3000_l = models.FloatField(
#         verbose_name="exante active daily volatility Russell 3000 daily L",
#         null=True,
#         blank=True,
#     )
#     exante_active_annual_volatility_Russell3000_l = models.FloatField(
#         verbose_name="exante active daily volatility Russell 3000 annual L",
#         null=True,
#         blank=True,
#     )

#     exante_total_daily_volatility_s = models.FloatField(
#         verbose_name="exante total daily volatility S", null=True, blank=True
#     )
#     exante_total_annual_volatility_s = models.FloatField(
#         verbose_name="exante total annual volatility S", null=True, blank=True
#     )
#     exante_total_daily_volatility_l = models.FloatField(
#         verbose_name="exante total daily volatility L", null=True, blank=True
#     )
#     exante_total_annual_volatility_l = models.FloatField(
#         verbose_name="exante total annual volatility L", null=True, blank=True
#     )

#     # FIXME where do we get realized volatility?
#     # realized_total_daily_volatility = models.FloatField(verbose_name="realized total daily volatility", null=True, blank=True)
#     # realized_total_monthly_volatility = models.FloatField(verbose_name="realized total monthly volatility", null=True, blank=True)
#     # realized_active_daily_volatility_Russell3000 = models.FloatField(verbose_name="realized active daily volatility Russell 3000", null=True, blank=True)

#     # Exante Portfolio Attribution
#     aero_exante_attribution = models.FloatField(
#         verbose_name="Aircraft exante attribution", null=True, blank=True
#     )
#     agric_exante_attribution = models.FloatField(
#         verbose_name="Agriculture exante attribution", null=True, blank=True
#     )
#     alpha_exante_attribution = models.FloatField(
#         verbose_name="Alpha exante attribution", null=True, blank=True
#     )
#     autos_exante_attribution = models.FloatField(
#         verbose_name="Autos exante attribution", null=True, blank=True
#     )
#     banks_exante_attribution = models.FloatField(
#         verbose_name="Banking exante attribution", null=True, blank=True
#     )
#     beer_exante_attribution = models.FloatField(
#         verbose_name="Beer & Liquor exante attribution", null=True, blank=True
#     )
#     bldmt_exante_attribution = models.FloatField(
#         verbose_name="construction materials exante attribution", null=True, blank=True
#     )
#     books_exante_attribution = models.FloatField(
#         verbose_name="Printing and Publishing exante attribution", null=True, blank=True
#     )
#     boxes_exante_attribution = models.FloatField(
#         verbose_name="Shipping Containers exante attribution", null=True, blank=True
#     )
#     bussv_exante_attribution = models.FloatField(
#         verbose_name="Business Services exante attribution", null=True, blank=True
#     )
#     chems_exante_attribution = models.FloatField(
#         verbose_name="Chemicals exante attribution", null=True, blank=True
#     )
#     chips_exante_attribution = models.FloatField(
#         verbose_name="Electronic Equipment exante attribution", null=True, blank=True
#     )
#     clths_exante_attribution = models.FloatField(
#         verbose_name="Apparel exante attribution", null=True, blank=True
#     )
#     cnstr_exante_attribution = models.FloatField(
#         verbose_name="Construction exante attribution", null=True, blank=True
#     )
#     coal_exante_attribution = models.FloatField(
#         verbose_name="Coal", null=True, blank=True
#     )
#     country_exante_attribution = models.FloatField(
#         verbose_name="Country exante attribution", null=True, blank=True
#     )
#     drugs_exante_attribution = models.FloatField(
#         verbose_name="Pharmaceutical Products exante attribution", null=True, blank=True
#     )
#     elceq_exante_attribution = models.FloatField(
#         verbose_name="Electrical Equipment exante attribution", null=True, blank=True
#     )  # check spelling
#     fabpr_exante_attribution = models.FloatField(
#         verbose_name="Fabricated Products exante attribution", null=True, blank=True
#     )
#     fin_exante_attribution = models.FloatField(
#         verbose_name="Trading exante attribution", null=True, blank=True
#     )
#     food_exante_attribution = models.FloatField(
#         verbose_name="Food Products exante attribution", null=True, blank=True
#     )
#     fun_exante_attribution = models.FloatField(
#         verbose_name="Entertainment exante attribution", null=True, blank=True
#     )
#     gold_exante_attribution = models.FloatField(
#         verbose_name="Precious Metals exante attribution", null=True, blank=True
#     )
#     guns_exante_attribution = models.FloatField(
#         verbose_name="Defense exante attribution", null=True, blank=True
#     )
#     hardw_exante_attribution = models.FloatField(
#         verbose_name="Hardware exante attribution", null=True, blank=True
#     )
#     hlth_exante_attribution = models.FloatField(
#         verbose_name="Healthcare exante attribution", null=True, blank=True
#     )
#     hshld_exante_attribution = models.FloatField(
#         verbose_name="Consumer Goods exante attribution", null=True, blank=True
#     )
#     insur_exante_attribution = models.FloatField(
#         verbose_name="Insurance exante attribution", null=True, blank=True
#     )
#     labeq_exante_attribution = models.FloatField(
#         verbose_name="Measuring and Control Equipment exante attribution",
#         null=True,
#         blank=True,
#     )
#     mach_exante_attribution = models.FloatField(
#         verbose_name="Machinery exante attribution", null=True, blank=True
#     )
#     meals_exante_attribution = models.FloatField(
#         verbose_name="Restaraunts, Hotels, Motels exante attribution",
#         null=True,
#         blank=True,
#     )
#     medeq_exante_attribution = models.FloatField(
#         verbose_name="Medical Equipment exante attribution", null=True, blank=True
#     )
#     mines_exante_attribution = models.FloatField(
#         verbose_name="Non and &sic le Metallic and Industrial Metal Mining exante attribution",
#         null=True,
#         blank=True,
#     )
#     nonlinear_size_exante_attribution = models.FloatField(
#         verbose_name="nonlinear size exante attribution", null=True, blank=True
#     )
#     oil_exante_attribution = models.FloatField(
#         verbose_name="Petroleum and Natural Gas exante attribution",
#         null=True,
#         blank=True,
#     )
#     other_exante_attribution = models.FloatField(
#         verbose_name="Almost Nothing exante attribution", null=True, blank=True
#     )
#     paper_exante_attribution = models.FloatField(
#         verbose_name="Business Supplies exante attribution", null=True, blank=True
#     )
#     persv_exante_attribution = models.FloatField(
#         verbose_name="Personal Services exante attribution", null=True, blank=True
#     )
#     # riest_exante_attribution = models.FloatField(verbose_name="RIEST", null=True, blank=True)
#     rlest_exante_attribution = models.FloatField(
#         verbose_name="RLEST exante attribution", null=True, blank=True
#     )
#     rtail_exante_attribution = models.FloatField(
#         verbose_name="Retail exante attribution", null=True, blank=True
#     )
#     rubbr_exante_attribution = models.FloatField(
#         verbose_name="Rubber and Plastic Products exante attribution",
#         null=True,
#         blank=True,
#     )
#     ships_exante_attribution = models.FloatField(
#         verbose_name="Shipbuilding, Railroad Equipment exante attribution",
#         null=True,
#         blank=True,
#     )
#     size_exante_attribution = models.FloatField(
#         verbose_name="size exante attribution", null=True, blank=True
#     )
#     smoke_exante_attribution = models.FloatField(
#         verbose_name="Tobacco Products exante attribution", null=True, blank=True
#     )
#     soda_exante_attribution = models.FloatField(
#         verbose_name="Candy & Soda exante attribution", null=True, blank=True
#     )
#     softw_exante_attribution = models.FloatField(
#         verbose_name="Software exante attribution", null=True, blank=True
#     )
#     steel_exante_attribution = models.FloatField(
#         verbose_name="Steel Works Etc exante attribution", null=True, blank=True
#     )
#     telcm_exante_attribution = models.FloatField(
#         verbose_name="Communication exante attribution", null=True, blank=True
#     )
#     toys_exante_attribution = models.FloatField(
#         verbose_name="Recreation exante attribution", null=True, blank=True
#     )
#     trans_exante_attribution = models.FloatField(
#         verbose_name="Transportation exante attribution", null=True, blank=True
#     )
#     txtls_exante_attribution = models.FloatField(
#         verbose_name="Textiles exante attribution", null=True, blank=True
#     )
#     util_exante_attribution = models.FloatField(
#         verbose_name="Utilities exante attribution", null=True, blank=True
#     )
#     whlsl_exante_attribution = models.FloatField(
#         verbose_name="Wholesale exante attribution", null=True, blank=True
#     )

#     # Factor Exposures
#     aero_exposure = models.FloatField(verbose_name="Aircraft", null=True, blank=True)
#     agric_exposure = models.FloatField(
#         verbose_name="Agriculture", null=True, blank=True
#     )
#     autos_exposure = models.FloatField(verbose_name="Autos", null=True, blank=True)
#     banks_exposure = models.FloatField(verbose_name="Banking", null=True, blank=True)
#     beer_exposure = models.FloatField(
#         verbose_name="Beer & Liquor", null=True, blank=True
#     )
#     bldmt_exposure = models.FloatField(
#         verbose_name="construction materials", null=True, blank=True
#     )
#     books_exposure = models.FloatField(
#         verbose_name="Printing and Publishing", null=True, blank=True
#     )
#     boxes_exposure = models.FloatField(
#         verbose_name="Shipping Containers", null=True, blank=True
#     )
#     bussv_exposure = models.FloatField(
#         verbose_name="Business Services", null=True, blank=True
#     )
#     chems_exposure = models.FloatField(verbose_name="Chemicals", null=True, blank=True)
#     chips_exposure = models.FloatField(
#         verbose_name="Electronic Equipment", null=True, blank=True
#     )
#     clths_exposure = models.FloatField(verbose_name="Apparel", null=True, blank=True)
#     cnstr_exposure = models.FloatField(
#         verbose_name="Construction", null=True, blank=True
#     )
#     coal_exposure = models.FloatField(verbose_name="Coal", null=True, blank=True)
#     country_exposure = models.FloatField(verbose_name="Country", null=True, blank=True)
#     drugs_exposure = models.FloatField(
#         verbose_name="Pharmaceutical Products", null=True, blank=True
#     )
#     elceq_exposure = models.FloatField(
#         verbose_name="Electrical Equipment", null=True, blank=True
#     )  # check spelling
#     fabpr_exposure = models.FloatField(
#         verbose_name="Fabricated Products", null=True, blank=True
#     )
#     fin_exposure = models.FloatField(verbose_name="Trading", null=True, blank=True)
#     food_exposure = models.FloatField(
#         verbose_name="Food Products", null=True, blank=True
#     )
#     fun_exposure = models.FloatField(
#         verbose_name="Entertainment", null=True, blank=True
#     )
#     gold_exposure = models.FloatField(
#         verbose_name="Precious Metals", null=True, blank=True
#     )
#     guns_exposure = models.FloatField(verbose_name="Defense", null=True, blank=True)
#     hardw_exposure = models.FloatField(verbose_name="Hardware", null=True, blank=True)
#     hlth_exposure = models.FloatField(verbose_name="Healthcare", null=True, blank=True)
#     hshld_exposure = models.FloatField(
#         verbose_name="Consumer Goods", null=True, blank=True
#     )
#     insur_exposure = models.FloatField(verbose_name="Insurance", null=True, blank=True)
#     labeq_exposure = models.FloatField(
#         verbose_name="Measuring and Control Equipment", null=True, blank=True
#     )
#     mach_exposure = models.FloatField(verbose_name="Machinery", null=True, blank=True)
#     meals_exposure = models.FloatField(
#         verbose_name="Restaraunts, Hotels, Motels", null=True, blank=True
#     )
#     medeq_exposure = models.FloatField(
#         verbose_name="Medical Equipment", null=True, blank=True
#     )
#     mines_exposure = models.FloatField(
#         verbose_name="Non and &sic le Metallic and Industrial Metal Mining",
#         null=True,
#         blank=True,
#     )
#     nonlinear_size_exposure = models.FloatField(
#         verbose_name="none linear size exposure", null=True, blank=True
#     )
#     oil_exposure = models.FloatField(
#         verbose_name="Petroleum and Natural Gas", null=True, blank=True
#     )
#     other_exposure = models.FloatField(
#         verbose_name="Almost Nothing", null=True, blank=True
#     )
#     paper_exposure = models.FloatField(
#         verbose_name="Business Supplies", null=True, blank=True
#     )
#     persv_exposure = models.FloatField(
#         verbose_name="Personal Services", null=True, blank=True
#     )
#     # riest_exposure = models.FloatField(verbose_name="RIEST", null=True, blank=True)
#     rlest_exposure = models.FloatField(verbose_name="RLEST", null=True, blank=True)
#     rtail_exposure = models.FloatField(verbose_name="Retail", null=True, blank=True)
#     rubbr_exposure = models.FloatField(
#         verbose_name="Rubber and Plastic Products", null=True, blank=True
#     )
#     ships_exposure = models.FloatField(
#         verbose_name="Shipbuilding, Railroad Equipment", null=True, blank=True
#     )
#     size_exposure = models.FloatField(
#         verbose_name="size exposure", null=True, blank=True
#     )
#     smoke_exposure = models.FloatField(
#         verbose_name="Tobacco Products", null=True, blank=True
#     )
#     soda_exposure = models.FloatField(
#         verbose_name="Candy & Soda", null=True, blank=True
#     )
#     softw_exposure = models.FloatField(verbose_name="Software", null=True, blank=True)
#     steel_exposure = models.FloatField(
#         verbose_name="Steel Works Etc", null=True, blank=True
#     )
#     telcm_exposure = models.FloatField(
#         verbose_name="Communication", null=True, blank=True
#     )
#     toys_exposure = models.FloatField(verbose_name="Recreation", null=True, blank=True)
#     trans_exposure = models.FloatField(
#         verbose_name="Transportation", null=True, blank=True
#     )
#     txtls_exposure = models.FloatField(verbose_name="Textiles", null=True, blank=True)
#     util_exposure = models.FloatField(verbose_name="Utilities", null=True, blank=True)
#     whlsl_exposure = models.FloatField(verbose_name="Wholesale", null=True, blank=True)

#     # Exante Benchmark Betas
#     russell3000_exante_beta_s = models.FloatField(
#         verbose_name="Russell 3000 exante beta S", null=True, blank=True
#     )
#     russell3000_exante_beta_l = models.FloatField(
#         verbose_name="Russell 3000 exante beta L", null=True, blank=True
#     )

#     # Exante Benchmark Alphas
#     russell3000_exante_alpha_s = models.FloatField(
#         verbose_name="Russell 3000 exante alpha S", null=True, blank=True
#     )
#     russell3000_exante_alpha_l = models.FloatField(
#         verbose_name="Russell 3000 exante alpha L", null=True, blank=True
#     )

    # mktbeta_exposure = models.FloatField(verbose_name="mktbeta_exposures", null=True, blank=True)
    # mktbetaresid_exposure = models.FloatField(verbose_name="mktbetaresid_exposure", null=True, blank=True)

    # nonlinear_beta_exposure = models.FloatField(verbose_name="nonlinear beta exposure", null=True, blank=True)
    # residual_volatility_exposure = models.FloatField(verbose_name="residual volatility exposure", null=True, blank=True)
    # liquidity_exposure = models.FloatField(verbose_name="liquidity exposure", null=True, blank=True)
    # momentum_exposure = models.FloatField(verbose_name="momentum exposure", null=True, blank=True)

    # Russell3000_realized_beta = models.FloatField(verbose_name="Russell 3000 realized beta", null=True, blank=True)

    # mktbeta_exante_attribution = models.FloatField(verbose_name="mktbeta exante attribution", null=True, blank=True)
    # mktbetaresid_exante_attribution = models.FloatField(verbose_name="mktbeta resid exante attribution", null=True, blank=True)

    # nonlinear_beta_exante_attribution = models.FloatField(verbose_name="nonlinear beta exante attribution", null=True, blank=True)
    # residual_volatility_exante_attribution = models.FloatField(verbose_name="residual volatility exante attribution", null=True, blank=True)
    # liquidity_exante_attribution = models.FloatField(verbose_name="liquidtiy exante attribution", null=True, blank=True)
    # momentum_exante_attribution = models.FloatField(verbose_name="momentum exante attribution", null=True, blank=True)

    # exante_active_monthly_volatility_Russell3000 = models.FloatField(verbose_name="exante active monthly volatility Russell3000", null=True, blank=True)
    # realized_active_monthly_volatility_Russell3000 = models.FloatField(verbose_name="realized active monthly volatility Russell3000", null=True, blank=True)
    # mktbeta_realized_attribution = models.FloatField(verbose_name="mktbeta realized attribution", null=True, blank=True)
    # mktbetaresid_realized_attribution = models.FloatField(verbose_name="mktbetaresid realized attribution", null=True, blank=True)

    # size_realized_attribution = models.FloatField(verbose_name="size realized attribution", null=True, blank=True)
    # nonlinear_size_realized_attribution = models.FloatField(verbose_name="nonlinear size realized attribution", null=True, blank=True)
    # nonlinear_beta_realized_attribution = models.FloatField(verbose_name="nonlinear beta realized attribution", null=True, blank=True)
    # residual_volatility_realized_attribution = models.FloatField(verbose_name="residual volatility realized attribution", null=True, blank=True)
    # liquidity_realized_attribution = models.FloatField(verbose_name="liquidtiy realized attribution", null=True, blank=True)
    # momentum_realized_attribution = models.FloatField(verbose_name="momentum realized attribution", null=True, blank=True)

    # aero_realized_attribution = models.FloatField(verbose_name="Aircraft realized attribution", null=True, blank=True)
    # agric_realized_attribution = models.FloatField(verbose_name="Agriculture realized attribution", null=True, blank=True)
    # autos_realized_attribution = models.FloatField(verbose_name="Autos realized attribution", null=True, blank=True)
    # banks_realized_attribution = models.FloatField(verbose_name="Banking realized attribution", null=True, blank=True)
    # beer_realized_attribution = models.FloatField(verbose_name="Beer & Liquor realized attribution", null=True, blank=True)
    # bldmt_realized_attribution = models.FloatField(verbose_name="construction materials realized attribution", null=True, blank=True)
    # books_realized_attribution = models.FloatField(verbose_name="Printing and Publishing realized attribution", null=True, blank=True)
    # boxes_realized_attribution = models.FloatField(verbose_name="Shipping Containers realized attribution", null=True, blank=True)
    # bussv_realized_attribution = models.FloatField(verbose_name="Business Services realized attribution", null=True, blank=True)
    # chems_realized_attribution = models.FloatField(verbose_name="Chemicals realized attribution", null=True, blank=True)
    # chips_realized_attribution = models.FloatField(verbose_name="Electronic Equipment realized attribution", null=True, blank=True)
    # clths_realized_attribution = models.FloatField(verbose_name="Apparel realized attribution", null=True, blank=True)
    # cnstr_realized_attribution = models.FloatField(verbose_name="Construction realized attribution", null=True, blank=True)
    # coal_realized_attribution = models.FloatField(verbose_name="Coal", null=True, blank=True)
    # drugs_realized_attribution = models.FloatField(verbose_name="Pharmaceutical Products realized attribution", null=True, blank=True)
    # elceq_realized_attribution = models.FloatField(verbose_name="Electrical Equipment realized attribution", null=True, blank=True) #check spelling
    # fabpr_realized_attribution = models.FloatField(verbose_name="Fabricated Products realized attribution", null=True, blank=True)
    # fin_realized_attribution = models.FloatField(verbose_name="Trading realized attribution", null=True, blank=True)
    # food_realized_attribution = models.FloatField(verbose_name="Food Products realized attribution", null=True, blank=True)
    # fun_realized_attribution = models.FloatField(verbose_name="Entertainment realized attribution", null=True, blank=True)
    # gold_realized_attribution = models.FloatField(verbose_name="Precious Metals realized attribution", null=True, blank=True)
    # guns_realized_attribution = models.FloatField(verbose_name="Defense realized attribution", null=True, blank=True)
    # hardw_realized_attribution = models.FloatField(verbose_name="Hardware realized attribution", null=True, blank=True)
    # hlth_realized_attribution = models.FloatField(verbose_name="Healthcare realized attribution", null=True, blank=True)
    # hshld_realized_attribution = models.FloatField(verbose_name="Consumer Goods realized attribution", null=True, blank=True)
    # insur_realized_attribution = models.FloatField(verbose_name="Insurance realized attribution", null=True, blank=True)
    # labeq_realized_attribution = models.FloatField(verbose_name="Measuring and Control Equipment realized attribution", null=True, blank=True)
    # mach_realized_attribution = models.FloatField(verbose_name="Machinery realized attribution", null=True, blank=True)
    # meals_realized_attribution = models.FloatField(verbose_name="Restaraunts, Hotels, Motels realized attribution", null=True, blank=True)
    # medeq_realized_attribution = models.FloatField(verbose_name="Medical Equipment realized attribution", null=True, blank=True)
    # mines_realized_attribution = models.FloatField(verbose_name="Non and &sic le Metallic and Industrial Metal Mining realized attribution", null=True, blank=True)
    # oil_realized_attribution = models.FloatField(verbose_name="Petroleum and Natural Gas realized attribution", null=True, blank=True)
    # other_realized_attribution = models.FloatField(verbose_name="Almost Nothing realized attribution", null=True, blank=True)
    # paper_realized_attribution = models.FloatField(verbose_name="Business Supplies realized attribution", null=True, blank=True)
    # persv_realized_attribution = models.FloatField(verbose_name="Personal Services realized attribution", null=True, blank=True)
    # #riest_realized_attribution = models.FloatField(verbose_name="RIEST", null=True, blank=True)
    # rlest_realized_attribution = models.FloatField(verbose_name="RLEST realized attribution", null=True, blank=True)
    # rtail_realized_attribution = models.FloatField(verbose_name="Retail realized attribution", null=True, blank=True)
    # rubbr_realized_attribution = models.FloatField(verbose_name="Rubber and Plastic Products realized attribution", null=True, blank=True)
    # ships_realized_attribution = models.FloatField(verbose_name="Shipbuilding, Railroad Equipment realized attribution", null=True, blank=True)
    # smoke_realized_attribution = models.FloatField(verbose_name="Tobacco Products realized attribution", null=True, blank=True)
    # soda_realized_attribution = models.FloatField(verbose_name="Candy & Soda realized attribution", null=True, blank=True)
    # softw_realized_attribution = models.FloatField(verbose_name="Software realized attribution", null=True, blank=True)
    # steel_realized_attribution = models.FloatField(verbose_name="Steel Works Etc realized attribution", null=True, blank=True)
    # telcm_realized_attribution = models.FloatField(verbose_name="Communication realized attribution", null=True, blank=True)
    # toys_realized_attribution = models.FloatField(verbose_name="Recreation realized attribution", null=True, blank=True)
    # trans_realized_attribution = models.FloatField(verbose_name="Transportation realized attribution", null=True, blank=True)
    # txtls_realized_attribution = models.FloatField(verbose_name="Textiles realized attribution", null=True, blank=True)
    # util_realized_attribution = models.FloatField(verbose_name="Utilities realized attribution", null=True, blank=True)
    # whlsl_realized_attribution = models.FloatField(verbose_name="Wholesale realized attribution", null=True, blank=True)
    # country_realized_attribution = models.FloatField(verbose_name="Country realized attribution", null=True, blank=True)
    # alpha_realized_attribution = models.FloatField(verbose_name="Alpha realized attribution", null=True, blank=True)


class Security_Risk(models.Model):

    asset = models.ForeignKey(
        Equity_Security_Master, on_delete=models.PROTECT, verbose_name="asset id"
    )
    date = models.DateField(default=timezone.now)
    russell3000_exante_beta = models.FloatField(
        verbose_name="Russell 3000 exante beta", null=True, blank=True
    )
    exante_total_daily_volatility = models.FloatField(
        verbose_name="exante total dail volatility", null=True, blank=True
    )
    realized_total_daily_volatility = models.FloatField(
        verbose_name="realized total daily volatiliy", null=True, blank=True
    )
    exante_total_monthly_volatility = models.FloatField(
        verbose_name="exante total monthly volatility", null=True, blank=True
    )
    realized_total_monthly_volatility = models.FloatField(
        verbose_name="realized total monthly volatility", null=True, blank=True
    )
    expected_return_daily = models.FloatField(
        verbose_name="expected return daily", null=True, blank=True
    )
    expected_return_monthly = models.FloatField(
        verbose_name="expected return monthly", null=True, blank=True
    )

