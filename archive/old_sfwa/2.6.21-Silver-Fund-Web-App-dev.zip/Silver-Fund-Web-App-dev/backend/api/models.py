from django.db import models
from django.utils import timezone
from datetime import datetime


class Equity_Security_Master(models.Model):
    class Meta:
        verbose_name_plural = "equity security master"

    asset_id = models.CharField(
        verbose_name="asset id",
        max_length=40,
        null=False,
        blank=False,
        default="needs_id",
        primary_key=True,
    )
    ticker = models.CharField(
        verbose_name="ticker", max_length=40, null=True, blank=True
    )
    comnam = models.CharField(
        verbose_name="Company Name", max_length=40, null=True, blank=True
    )
    conid = models.CharField(verbose_name="conid",
                             max_length=40, null=True, blank=True)
    cusip = models.CharField(verbose_name="cusip",
                             max_length=40, null=True, blank=True)
    isin = models.CharField(verbose_name="isin",
                            max_length=40, null=True, blank=True)
    valid_date = models.DateField(default=timezone.now)
    siccd = models.CharField(
        verbose_name="industry code", max_length=40, null=True, blank=True
    )
    country_code = models.CharField(
        verbose_name="country code", max_length=40, null=True, blank=True
    )
    prim_exch = models.CharField(
        verbose_name="prim exch", max_length=40, null=True, blank=True
    )
    currency = models.CharField(
        verbose_name="currency", max_length=40, null=True, blank=True
    )
    bnchmrk = models.CharField(
        verbose_name="benchmark", max_length=40, null=True, blank=True
    )
    crsp = models.BooleanField(default=False, null=True)

    def __str__(self):
        return self.asset_id


class crsp_securities(models.Model):
    permno = models.IntegerField(verbose_name="permno", null=True, blank=True)
    ticker = models.CharField(null=True, blank=True, max_length=40)
    cusip = models.CharField(null=True, blank=True, max_length=40)
    comnam = models.CharField(null=True, blank=True, max_length=40)
    shrcls = models.CharField(null=True, blank=True, max_length=40)
    tsymbol = models.CharField(null=True, blank=True, max_length=40)
    siccd = models.CharField(null=True, blank=True, max_length=40)


class Position(models.Model):
    asset_id = models.CharField(
        Equity_Security_Master, max_length=40, null=False, blank=False
    )
    ticker = models.CharField(
        verbose_name="ticker", max_length=40, null=True, blank=True
    )
    num_of_shares = models.IntegerField(
        verbose_name="num of shares", null=True, blank=True
    )
    asset_type = models.CharField(
        verbose_name="asset type", max_length=40, null=True, blank=True
    )
    price = models.FloatField(verbose_name="price", null=True, blank=True)
    position_value = models.FloatField(
        verbose_name="position value", null=True, blank=True
    )
    date = models.DateField(default=timezone.now)

    def __str__(self):
        return self.ticker


class Trade(models.Model):
    trade_id = models.CharField(
        verbose_name="trade id",
        max_length=40,
        null=False,
        blank=False,
        primary_key=True,
    )
    asset = models.OneToOneField(
        Equity_Security_Master,
        related_name="trades",
        on_delete=models.PROTECT,
        verbose_name="asset id",
    )
    trade_type = models.CharField(
        verbose_name="trade type", max_length=40, null=True, blank=True
    )
    num_of_shares = models.IntegerField(
        verbose_name="num of shares", null=True, blank=True
    )
    price = models.FloatField(verbose_name="price", null=True, blank=True)
    tot_price = models.FloatField(
        verbose_name="tot price", null=True, blank=True)
    trade_status = models.CharField(
        verbose_name="status", max_length=40, null=True, blank=True
    )
    trade_time = models.CharField(
        verbose_name="date time", max_length=40, null=True, blank=True
    )

    def __str__(self):
        return self.trade_id


class Market_Data(models.Model):
    asset = models.ForeignKey(
        Equity_Security_Master,
        related_name="market_data",
        on_delete=models.PROTECT,
        verbose_name="asset id",
    )
    caldt = models.DateTimeField(verbose_name="date", null=False, blank=False)
    shrcd = models.CharField(
        verbose_name="share code", max_length=40, null=True, blank=True
    )
    siccd = models.CharField(
        verbose_name="sic code", max_length=40, null=True, blank=True
    )
    prc = models.FloatField(verbose_name="close price", null=True, blank=True)
    vol = models.IntegerField(verbose_name="volume", null=True, blank=True)
    ret = models.FloatField(verbose_name="return", null=True, blank=True)
    shr = models.FloatField(
        verbose_name="shares outstanding", null=True, blank=True)
    rf = models.FloatField(verbose_name="risk free rate",
                           null=True, blank=True)


# class Fundementals(models.Model):
#     asset = models.ForeignKey(
#         Equity_Security_Master,
#         related_name="market_data",
#         on_delete=models.PROTECT,
#         verbose_name="asset id",
#     )
#     bv = models.FloatField(verbose_name="book value", null=True, blank=True)
#     dltt = models.FloatField(
#         verbose_name="long term debt", null=True, blank=True)
#     at = models.FloatField(verbose_name="total assets", null=True, blank=True)
#     dt = models.FloatField(verbose_name="total debt", null=True, blank=True)
#     pstk = models.FloatField(
#         verbose_name="perferred equity", null=True, blank=True)
#     epspi = models.FloatField(
#         verbose_name="earnings per share", null=True, blank=True)
#     div_yeild = models.FloatField(
#         verbose_name="dividend yeild", null=True, blank=True)
#     sale = models.FloatField(verbose_name="sales", null=True, blank=True)
#     rev = models.FloatField(verbose_name="revenue", null=True, blank=True)
#     ni = models.FloatField(verbose_name="net income", null=True, blank=True)
#     op_cf = models.FloatField(
#         verbose_name="operating cash flow", null=True, blank=True)


class ForeignExchange(models.Model):
    country_code = models.CharField(
        verbose_name="country code",
        max_length=40,
        null=False,
        blank=False,
        primary_key=True,
    )
    date = models.DateTimeField(verbose_name="date", null=True, blank=True)
    exchange_rate = models.FloatField(
        verbose_name="exchange rate", null=True, blank=True
    )
    thirty_day_rate = models.FloatField(
        verbose_name="thirty day rate", null=True, blank=True
    )
    ninety_day_rate = models.FloatField(
        verbose_name="ninety day rate", null=True, blank=True
    )
    one_eighty_day_rate = models.FloatField(
        verbose_name="one eighty day rate", null=True, blank=True
    )
    one_year_rate = models.FloatField(
        verbose_name="one year rate", null=True, blank=True
    )
    two_year_rate = models.FloatField(
        verbose_name="two year rate", null=True, blank=True
    )
    three_year_rate = models.FloatField(
        verbose_name="three year rate", null=True, blank=True
    )
    five_year_rate = models.FloatField(
        verbose_name="five year rate", null=True, blank=True
    )
    seven_year_rate = models.FloatField(
        verbose_name="seven year rate", null=True, blank=True
    )
    ten_year_rate = models.FloatField(
        verbose_name="ten year rate", null=True, blank=True
    )
    twenty_year_rate = models.FloatField(
        verbose_name="twenty year rate", null=True, blank=True
    )
    thirty_year_rate = models.FloatField(
        verbose_name="thirty year rate", null=True, blank=True
    )


class Live_Target_Portfolio(models.Model):
    class Meta:
        verbose_name_plural = "live target portfolio"

    asset = models.ForeignKey(
        Equity_Security_Master,
        related_name="live_target_portfolio",
        on_delete=models.PROTECT,
        verbose_name="asset id",
        null=True,
        blank=True,
    )
    ticker = models.CharField(max_length=40)
    model_er = models.FloatField(verbose_name="model expected return")
    annualized_er = models.FloatField(
        verbose_name="annualized expected return")
    beta_to_b = models.FloatField(verbose_name="beta to benchmark")
    alpha = models.FloatField()
    oa_weight = models.FloatField(verbose_name="optimal active weight")
    b_weight = models.FloatField(verbose_name="weight in benchmark")
    c_weight = models.FloatField(verbose_name="current weight")
    backlog = models.FloatField()
    backlog_risk = models.FloatField()
    commit_maker = models.CharField(
        max_length=40, null=True, blank=True, default="anonymous"
    )
    is_latest = models.BooleanField(default=False)
    commit_time = models.CharField(
        default=datetime.now().strftime("%Y-%m-%d@%H:%M:%S"),
        max_length=40,
        editable=False,
    )

    def __str__(self):
        return self.ticker


class Portfolio_ExAnte_Stats(models.Model):
    class Meta:
        verbose_name_plural = "portfolio ex-ante stats"

    expected_return = models.FloatField(null=True, blank=True)
    beta_to_b = models.FloatField(
        verbose_name="beta to benchmark", null=True, blank=True
    )
    alpha_to_b = models.FloatField(
        verbose_name="alpha to benchmark", null=True, blank=True
    )
    info_ratio = models.FloatField(
        verbose_name="informational ratio", null=True, blank=True
    )
    commit_maker = models.CharField(
        max_length=40, null=True, blank=True, default="anonymous"
    )
    is_latest = models.BooleanField(default=True)
    commit_time = models.CharField(
        default=datetime.now().strftime("%Y-%m-%d@%H:%M:%S"),
        max_length=40,
        editable=False,
    )

    def __str__(self):
        return self.commit_maker + "'s commit on " + self.commit_time


class Exposures(models.Model):
    # index = models.FloatField(verbose_name="index", null=True, blank=True)
    # FIXME this needs to be added back in when we have Equity Security up

    # id = models.AutoField(
    #     verbose_name="record id",
    #     null=False,
    #     blank=False,
    #     primary_key=True,
    #     unique = True
    # )

    asset = models.ForeignKey(
        Equity_Security_Master,
        on_delete=models.PROTECT,
        verbose_name="asset id",
        default="84788",
    )

    caldt = models.DateTimeField(verbose_name="date", null=False, blank=False)

    shrcd = models.FloatField(verbose_name="shrcd", null=True, blank=True)
    siccd = models.FloatField(verbose_name="siccd", null=True, blank=True)
    prc = models.FloatField(verbose_name="price", null=True, blank=True)
    vol = models.FloatField(verbose_name="volume", null=True, blank=True)
    ret = models.FloatField(verbose_name="ret", null=True, blank=True)
    shr = models.FloatField(verbose_name="share", null=True, blank=True)
    rf = models.FloatField(verbose_name="rf", null=True, blank=True)

    agric = models.FloatField(
        verbose_name="Agriculture", null=True, blank=True)
    food = models.FloatField(
        verbose_name="Food Products", null=True, blank=True)
    soda = models.FloatField(
        verbose_name="Candy & Soda", null=True, blank=True)
    beer = models.FloatField(
        verbose_name="Beer & Liquor", null=True, blank=True)
    smoke = models.FloatField(
        verbose_name="Tobacco Products", null=True, blank=True)
    toys = models.FloatField(verbose_name="Recreation", null=True, blank=True)
    fun = models.FloatField(
        verbose_name="Entertainment", null=True, blank=True)
    books = models.FloatField(
        verbose_name="Printing and Publishing", null=True, blank=True
    )
    hshld = models.FloatField(
        verbose_name="Consumer Goods", null=True, blank=True)
    clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    hlth = models.FloatField(verbose_name="Healthcare", null=True, blank=True)
    medeq = models.FloatField(
        verbose_name="Medical Equipment", null=True, blank=True)
    drugs = models.FloatField(
        verbose_name="Pharmaceutical Products", null=True, blank=True
    )
    chems = models.FloatField(verbose_name="Chemicals", null=True, blank=True)
    rubbr = models.FloatField(
        verbose_name="Rubber and Plastic Products", null=True, blank=True
    )
    txtls = models.FloatField(verbose_name="Textiles", null=True, blank=True)
    bldmt = models.FloatField(
        verbose_name="construction materials", null=True, blank=True
    )
    cnstr = models.FloatField(
        verbose_name="Construction", null=True, blank=True)
    steel = models.FloatField(
        verbose_name="Steel Works Etc", null=True, blank=True)
    fabpr = models.FloatField(
        verbose_name="Fabricated Products", null=True, blank=True)
    mach = models.FloatField(verbose_name="Machinery", null=True, blank=True)
    elceq = models.FloatField(
        verbose_name="Electrical Equipment", null=True, blank=True
    )
    autos = models.FloatField(verbose_name="Autos", null=True, blank=True)
    aero = models.FloatField(verbose_name="Aircraft", null=True, blank=True)
    ships = models.FloatField(
        verbose_name="Shipbuilding, Railroad Equipment", null=True, blank=True
    )
    guns = models.FloatField(verbose_name="Defense", null=True, blank=True)
    gold = models.FloatField(
        verbose_name="Precious Metals", null=True, blank=True)
    mines = models.FloatField(
        verbose_name="Non and &sic le Metallic and Industrial Metal Mining",
        null=True,
        blank=True,
    )
    coal = models.FloatField(verbose_name="Coal", null=True, blank=True)
    oil = models.FloatField(
        verbose_name="Petroleum and Natural Gas", null=True, blank=True
    )
    util = models.FloatField(verbose_name="Utilities", null=True, blank=True)
    telcm = models.FloatField(
        verbose_name="Communication", null=True, blank=True)
    persv = models.FloatField(
        verbose_name="Personal Services", null=True, blank=True)
    bussv = models.FloatField(
        verbose_name="Business Services", null=True, blank=True)
    hardw = models.FloatField(verbose_name="Hardware", null=True, blank=True)
    softw = models.FloatField(verbose_name="Software", null=True, blank=True)
    chips = models.FloatField(
        verbose_name="Electronic Equipment", null=True, blank=True
    )
    labeq = models.FloatField(
        verbose_name="Measuring and Control Equipment", null=True, blank=True
    )
    paper = models.FloatField(
        verbose_name="Business Supplies", null=True, blank=True)
    boxes = models.FloatField(
        verbose_name="Shipping Containers", null=True, blank=True)
    trans = models.FloatField(
        verbose_name="Transportation", null=True, blank=True)
    whlsl = models.FloatField(verbose_name="Wholesale", null=True, blank=True)
    rtail = models.FloatField(verbose_name="Retail", null=True, blank=True)
    meals = models.FloatField(
        verbose_name="Restaraunts, Hotels, Motels", null=True, blank=True
    )
    banks = models.FloatField(verbose_name="Banking", null=True, blank=True)
    insur = models.FloatField(verbose_name="Insurance", null=True, blank=True)
    rlest = models.FloatField(verbose_name="RIEST", null=True, blank=True)
    fin = models.FloatField(verbose_name="Trading", null=True, blank=True)
    other = models.FloatField(
        verbose_name="Almost Nothing", null=True, blank=True)

    industrycheck = models.IntegerField(
        verbose_name="Industrycheck", null=True, blank=True
    )
    country = models.FloatField(verbose_name="Country", null=True, blank=True)
    ind_str = models.CharField(
        verbose_name="Industry String", max_length=60, null=True, blank=True
    )
    size = models.FloatField(verbose_name="Size", null=True, blank=True)
    mktbeta = models.FloatField(
        verbose_name="Market Beta", null=True, blank=True)
    mktbetaresid = models.FloatField(
        verbose_name="Market Beta Residual", null=True, blank=True
    )
    momentum = models.FloatField(
        verbose_name="Momentum", null=True, blank=True)
    liquidity = models.FloatField(
        verbose_name="Liquidity", null=True, blank=True)
    residual_volatility = models.FloatField(
        verbose_name="Residual Volatility", null=True, blank=True
    )
    nonlinear_beta = models.FloatField(
        verbose_name="Nonlinear Beta", null=True, blank=True
    )
    nonlinear_size = models.FloatField(
        verbose_name="Nonlinear Size", null=True, blank=True
    )
    value = models.FloatField(verbose_name="value", null=True, blank=True)


class Benchmark(models.Model):
    benchmark = models.CharField(
        verbose_name="benchmark", max_length=40, null=True, blank=True
    )
    # asset = models.OneToOneField(
    #     Equity_Security_Master, on_delete=models.PROTECT, verbose_name="asset id",
    # )

    asset = models.ForeignKey(
        Equity_Security_Master, on_delete=models.PROTECT, verbose_name="asset id"
    )

    caldt = models.DateField(default=timezone.now, null=True, blank=True)
    weight = models.FloatField(verbose_name="weight", null=True, blank=True)
    ticker = models.CharField(
        verbose_name="ticker", max_length=40, null=True, blank=True
    )


class Factor_Return(models.Model):
    date = models.DateField(
        default=timezone.now, null=False, blank=False, primary_key=True
    )
    aero = models.FloatField(verbose_name="Aircraft", null=True, blank=True)
    agric = models.FloatField(
        verbose_name="Agriculture", null=True, blank=True)
    autos = models.FloatField(verbose_name="Autos", null=True, blank=True)
    banks = models.FloatField(verbose_name="Banking", null=True, blank=True)
    beer = models.FloatField(
        verbose_name="Beer & Liquor", null=True, blank=True)
    bldmt = models.FloatField(
        verbose_name="construction materials", null=True, blank=True
    )
    books = models.FloatField(
        verbose_name="Printing and Publishing", null=True, blank=True
    )
    boxes = models.FloatField(
        verbose_name="Shipping Containers", null=True, blank=True)
    bussv = models.FloatField(
        verbose_name="Business Services", null=True, blank=True)
    chems = models.FloatField(verbose_name="Chemicals", null=True, blank=True)
    chips = models.FloatField(
        verbose_name="Electronic Equipment", null=True, blank=True
    )
    clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    # clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    cnstr = models.FloatField(
        verbose_name="Construction", null=True, blank=True)
    coal = models.FloatField(verbose_name="Coal", null=True, blank=True)
    drugs = models.FloatField(
        verbose_name="Pharmaceutical Products", null=True, blank=True
    )
    elceq = models.FloatField(
        verbose_name="Electrical Equipment", null=True, blank=True
    )
    fabpr = models.FloatField(
        verbose_name="Fabricated Products", null=True, blank=True)
    fin = models.FloatField(verbose_name="Trading", null=True, blank=True)
    food = models.FloatField(
        verbose_name="Food Products", null=True, blank=True)
    fun = models.FloatField(
        verbose_name="Entertainment", null=True, blank=True)
    gold = models.FloatField(
        verbose_name="Precious Metals", null=True, blank=True)
    guns = models.FloatField(verbose_name="Defense", null=True, blank=True)
    # hardw = models.FloatField(verbose_name="Fabricated Products", null=True, blank=True)
    hardw = models.FloatField(verbose_name="Hardware", null=True, blank=True)
    hlth = models.FloatField(verbose_name="Healthcare", null=True, blank=True)
    hshld = models.FloatField(
        verbose_name="Consumer Goods", null=True, blank=True)
    insur = models.FloatField(verbose_name="Insurance", null=True, blank=True)
    labeq = models.FloatField(
        verbose_name="Measuring and Control Equipment", null=True, blank=True
    )
    mach = models.FloatField(verbose_name="Machinery", null=True, blank=True)
    meals = models.FloatField(
        verbose_name="Restaraunts, Hotels, Motels", null=True, blank=True
    )
    medeq = models.FloatField(
        verbose_name="Medical Equipment", null=True, blank=True)
    mines = models.FloatField(
        verbose_name="Non and &sic le Metallic and Industrial Metal Mining",
        null=True,
        blank=True,
    )
    oil = models.FloatField(
        verbose_name="Petroleum and Natural Gas", null=True, blank=True
    )
    other = models.FloatField(
        verbose_name="Almost Nothing", null=True, blank=True)
    paper = models.FloatField(
        verbose_name="Business Supplies", null=True, blank=True)
    persv = models.FloatField(
        verbose_name="Personal Services", null=True, blank=True)
    # riest = models.FloatField(verbose_name="")
    riest = models.FloatField(verbose_name="RIEST", null=True, blank=True)
    rlest = models.FloatField(verbose_name="RLEST", null=True, blank=True)
    rtail = models.FloatField(verbose_name="Retail", null=True, blank=True)
    rubbr = models.FloatField(
        verbose_name="Rubber and Plastic Products", null=True, blank=True
    )
    ships = models.FloatField(
        verbose_name="Shipbuilding, Railroad Equipment", null=True, blank=True
    )
    smoke = models.FloatField(
        verbose_name="Tobacco Products", null=True, blank=True)
    soda = models.FloatField(
        verbose_name="Candy & Soda", null=True, blank=True)
    # softw
    softw = models.FloatField(verbose_name="Software", null=True, blank=True)
    steel = models.FloatField(
        verbose_name="Steel Works Etc", null=True, blank=True)
    telcm = models.FloatField(
        verbose_name="Communication", null=True, blank=True)
    toys = models.FloatField(verbose_name="Recreation", null=True, blank=True)
    trans = models.FloatField(
        verbose_name="Transportation", null=True, blank=True)
    txtls = models.FloatField(verbose_name="Textiles", null=True, blank=True)
    util = models.FloatField(verbose_name="Utilities", null=True, blank=True)
    whlsl = models.FloatField(verbose_name="Wholesale", null=True, blank=True)
    country = models.FloatField(verbose_name="Country", null=True, blank=True)

    mktbeta = models.FloatField(
        verbose_name="Market Beta", null=True, blank=True)
    size = models.FloatField(verbose_name="Size", null=True, blank=True)
    nonlinear_size = models.FloatField(
        verbose_name="Nonlinear Size", null=True, blank=True
    )
    nonlinear_beta = models.FloatField(
        verbose_name="Nonlinear Beta", null=True, blank=True
    )
    residual_volatility = models.FloatField(
        verbose_name="Residual Volatility", null=True, blank=True
    )
    liquidity = models.FloatField(
        verbose_name="Liquidity", null=True, blank=True)
    momentum = models.FloatField(
        verbose_name="Momentum", null=True, blank=True)

    book_to_price = models.FloatField(
        verbose_name="book to price", null=True, blank=True
    )
    dividend_yield = models.FloatField(
        verbose_name="dividend yield", null=True, blank=True
    )
    growth = models.FloatField(verbose_name="growth", null=True, blank=True)
    earnings_yield = models.FloatField(
        verbose_name="earnings yield", null=True, blank=True
    )


class Specific_Volatility(models.Model):
    date = models.DateField(
        default=timezone.now, null=False, blank=False, primary_key=True
    )
    horizion = models.CharField(
        verbose_name="horizion", max_length=40, null=True, blank=True
    )
    permno = models.OneToOneField(
        Equity_Security_Master, on_delete=models.PROTECT, verbose_name="asset id"
    )
    volatility = models.FloatField(
        verbose_name="volatility", null=True, blank=True)


class Variance_Covariance(models.Model):
    date = models.DateField(
        default=timezone.now, null=False, blank=False, primary_key=True
    )
    field_name = models.DateField(verbose_name="field name")

    aero = models.FloatField(verbose_name="Aircraft", null=True, blank=True)
    agric = models.FloatField(
        verbose_name="Agriculture", null=True, blank=True)
    autos = models.FloatField(verbose_name="Autos", null=True, blank=True)
    banks = models.FloatField(verbose_name="Banking", null=True, blank=True)
    beer = models.FloatField(
        verbose_name="Beer & Liquor", null=True, blank=True)
    bldmt = models.FloatField(
        verbose_name="construction materials", null=True, blank=True
    )
    books = models.FloatField(
        verbose_name="Printing and Publishing", null=True, blank=True
    )
    boxes = models.FloatField(
        verbose_name="Shipping Containers", null=True, blank=True)
    bussv = models.FloatField(
        verbose_name="Business Services", null=True, blank=True)
    chems = models.FloatField(verbose_name="Chemicals", null=True, blank=True)
    chips = models.FloatField(
        verbose_name="Electronic Equipment", null=True, blank=True
    )
    clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    clths = models.FloatField(verbose_name="Apparel", null=True, blank=True)
    cnstr = models.FloatField(
        verbose_name="Construction", null=True, blank=True)
    coal = models.FloatField(verbose_name="Coal", null=True, blank=True)
    drugs = models.FloatField(
        verbose_name="Pharmaceutical Products", null=True, blank=True
    )
    elceq = models.FloatField(
        verbose_name="Electrical Equipment", null=True, blank=True
    )
    fabpr = models.FloatField(
        verbose_name="Fabricated Products", null=True, blank=True)
    fin = models.FloatField(verbose_name="Trading", null=True, blank=True)
    food = models.FloatField(
        verbose_name="Food Products", null=True, blank=True)
    fun = models.FloatField(
        verbose_name="Entertainment", null=True, blank=True)
    gold = models.FloatField(
        verbose_name="Precious Metals", null=True, blank=True)
    guns = models.FloatField(verbose_name="Defense", null=True, blank=True)
    hardw = models.FloatField(verbose_name="Hardware", null=True, blank=True)
    hlth = models.FloatField(verbose_name="Healthcare", null=True, blank=True)
    hshld = models.FloatField(
        verbose_name="Consumer Goods", null=True, blank=True)
    insur = models.FloatField(verbose_name="Insurance", null=True, blank=True)
    labeq = models.FloatField(
        verbose_name="Measuring and Control Equipment", null=True, blank=True
    )
    mach = models.FloatField(verbose_name="Machinery", null=True, blank=True)
    meals = models.FloatField(
        verbose_name="Restaraunts, Hotels, Motels", null=True, blank=True
    )
    medeq = models.FloatField(
        verbose_name="Medical Equipment", null=True, blank=True)
    mines = models.FloatField(
        verbose_name="Non and &sic le Metallic and Industrial Metal Mining",
        null=True,
        blank=True,
    )
    oil = models.FloatField(
        verbose_name="Petroleum and Natural Gas", null=True, blank=True
    )
    other = models.FloatField(
        verbose_name="Almost Nothing", null=True, blank=True)
    paper = models.FloatField(
        verbose_name="Business Supplies", null=True, blank=True)
    persv = models.FloatField(
        verbose_name="Personal Services", null=True, blank=True)
    riest = models.FloatField(verbose_name="RIEST", null=True, blank=True)
    rlest = models.FloatField(verbose_name="RLEST", null=True, blank=True)
    rtail = models.FloatField(verbose_name="Retail", null=True, blank=True)
    rubbr = models.FloatField(
        verbose_name="Rubber and Plastic Products", null=True, blank=True
    )
    ships = models.FloatField(
        verbose_name="Shipbuilding, Railroad Equipment", null=True, blank=True
    )
    smoke = models.FloatField(
        verbose_name="Tobacco Products", null=True, blank=True)
    soda = models.FloatField(
        verbose_name="Candy & Soda", null=True, blank=True)
    softw = models.FloatField(verbose_name="Software", null=True, blank=True)
    steel = models.FloatField(
        verbose_name="Steel Works Etc", null=True, blank=True)
    telcm = models.FloatField(
        verbose_name="Communication", null=True, blank=True)
    toys = models.FloatField(verbose_name="Recreation", null=True, blank=True)
    trans = models.FloatField(
        verbose_name="Transportation", null=True, blank=True)
    txtls = models.FloatField(verbose_name="Textiles", null=True, blank=True)
    util = models.FloatField(verbose_name="Utilities", null=True, blank=True)
    whlsl = models.FloatField(verbose_name="Wholesale", null=True, blank=True)
    country = models.FloatField(verbose_name="Country", null=True, blank=True)

    mktbetaresid = models.FloatField(
        verbose_name="Market Beta Residual", null=True, blank=True
    )
    mktbeta = models.FloatField(
        verbose_name="Market Beta", null=True, blank=True)
    size = models.FloatField(verbose_name="Size", null=True, blank=True)
    nonlinear_size = models.FloatField(
        verbose_name="Nonlinear Size", null=True, blank=True
    )
    nonlinear_beta = models.FloatField(
        verbose_name="Nonlinear Beta", null=True, blank=True
    )
    residual_volatility = models.FloatField(
        verbose_name="Residual Volatility", null=True, blank=True
    )
    liquidity = models.FloatField(
        verbose_name="Liquidity", null=True, blank=True)
    momentum = models.FloatField(
        verbose_name="Momentum", null=True, blank=True)

    book_to_price = models.FloatField(
        verbose_name="book to price", null=True, blank=True
    )
    dividend_yield = models.FloatField(
        verbose_name="dividend yield", null=True, blank=True
    )
    growth = models.FloatField(verbose_name="growth", null=True, blank=True)
    earnings_yield = models.FloatField(
        verbose_name="earnings yield", null=True, blank=True
    )


class Portfolio_Performance(models.Model):
    date = models.DateField(
        default=timezone.now, null=False, blank=False, primary_key=True
    )
    ex_ante_portfolio_risk_total = models.FloatField(
        verbose_name="ex_ante_portfolio_risk_total", null=True, blank=True
    )
    ex_ante_portfolio_risk_active = models.FloatField(
        verbose_name="ex_ante_portfolio_risk_active", null=True, blank=True
    )

    realized_portfolio_risk_active = models.FloatField(null=True, blank=True)
    realized_portfolio_risk_total = models.FloatField(null=True, blank=True)

    ex_ante_portfolio_benchmark_beta_total = models.FloatField(
        verbose_name="ex_ante_portfolio_benchmark_beta_total", null=True, blank=True
    )
    ex_ante_portfolio_benchmark_beta_active = models.FloatField(
        verbose_name="ex_ante_portfolio_benchmark_beta_active", null=True, blank=True
    )

    realized_portfolio_benchmark_beta_active = models.FloatField(
        null=True, blank=True)

    realized_portfolio_benchmark_beta_total = models.FloatField(
        null=True, blank=True)

    portfolio_diversity_coefficient_total = models.FloatField(
        verbose_name="portfolio_diversity_coefficient_total", null=True, blank=True
    )
    portfolio_diversity_coefficient_active = models.FloatField(
        verbose_name="portfolio_diversity_coefficient_active", null=True, blank=True
    )
    ex_ante_momentum_total = models.FloatField(
        verbose_name="ex_ante_momentum_total", null=True, blank=True
    )
    ex_ante_momentum_active = models.FloatField(
        verbose_name="ex_ante_momentum_active", null=True, blank=True
    )
    ex_ante_size_total = models.FloatField(
        verbose_name="ex_ante_size_total", null=True, blank=True
    )
    ex_ante_size_active = models.FloatField(
        verbose_name="ex_ante_size_active", null=True, blank=True
    )
    ex_ante_value_total = models.FloatField(
        verbose_name="ex_ante_value_total", null=True, blank=True
    )
    ex_ante_value_active = models.FloatField(
        verbose_name="ex_ante_value_active", null=True, blank=True
    )
    ex_ante_quality_total = models.FloatField(
        verbose_name="ex_ante_quality_total", null=True, blank=True
    )
    ex_ante_quality_active = models.FloatField(
        verbose_name="ex_ante_quality_active", null=True, blank=True
    )
    ex_ante_low_volatility_total = models.FloatField(
        verbose_name="ex_ante_low_volatility_total", null=True, blank=True
    )
    ex_ante_low_volatility_active = models.FloatField(
        verbose_name="ex_ante_low_volatility_active", null=True, blank=True
    )
    ex_ante_low_beta_total = models.FloatField(
        verbose_name="ex_ante_low_beta_total", null=True, blank=True
    )
    ex_ante_low_beta_active = models.FloatField(
        verbose_name="ex_ante_low_beta_active", null=True, blank=True
    )


class Security_Performance(models.Model):

    asset = models.ForeignKey(
        Equity_Security_Master, on_delete=models.PROTECT, verbose_name="asset id"
    )
    date = models.DateField(default=timezone.now)

    exante_total_annual_standard_deviation = models.FloatField(
        verbose_name="annualized risk total", null=True, blank=True
    )
    exante_active_annual_standard_deviation = models.FloatField(
        verbose_name="annualized risk active", null=True, blank=True
    )
    exante_total_annual_standard_deviation_partial = models.FloatField(
        verbose_name="annualized risk total partial contribution", null=True, blank=True
    )
    exante_active_annual_standard_deviation_partial = models.FloatField(
        verbose_name="annualized risk active partial contribution",
        null=True,
        blank=True,
    )
    exante_total_annual_standard_deviation_contrib = models.FloatField(
        verbose_name="annualized risk total contribution", null=True, blank=True
    )
    exante_active_annual_standard_deviation_contrib = models.FloatField(
        verbose_name="annualized risk total contribution", null=True, blank=True
    )
