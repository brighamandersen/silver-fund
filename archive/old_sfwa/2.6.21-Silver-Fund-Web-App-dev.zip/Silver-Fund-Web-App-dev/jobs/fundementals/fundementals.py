import pandas as pd
import requests
from datetime import datetime, timedelta, date
import mysql.connector
import time
from sqlalchemy import create_engine

API_URL = "https://www.alphavantage.co/query"
API_KEY = 'VA355PKBU1CCOU9S'
CONNECTION = mysql.connector.connect(host='sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com',
                                     user='sf_master_db',
                                     passwd='this_is_testing',
                                     db='sandbox_db')


def get_comp_overview(ticker):

    industry = ''
    div_yeild = ''
    book_value = ''
    eps = ''

    pram = {"function": "OVERVIEW",
            "symbol": ticker,
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    response_json = response.json()

    if response_json:
        if 'Industry' in response_json:
            industry = response_json['Industry']
        if 'DividendYield' in response_json:
            div_yeild = response_json['DividendYield']
        if 'BookValue' in response_json:
            book_value = response_json['BookValue']
        if 'EPS' in response_json:
            eps = response_json['EPS']
        else:
            #print('could not find ' + str(ticker))
            return {}
    else:
        #print('could not find ' + str(ticker))
        return {}
    return {'industry': industry, 'div_yeild': div_yeild, 'book_value': book_value, 'eps': eps}


def get_balance_sheet(ticker):

    long_term_debt = ''
    preferred_stock_total_equity = ''
    total_assets = ''
    total_liabilities = ''

    pram = {"function": "BALANCE_SHEET",
            "symbol": ticker,
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    response_json = response.json()

    if response_json.get('annualReports'):
        if 'longTermDebt' in response_json['annualReports'][0]:
            long_term_debt = response_json['annualReports'][0]['longTermDebt']
        if 'preferredStockTotalEquity' in response_json['annualReports'][0]:
            preferred_stock_total_equity = response_json['annualReports'][0]['preferredStockTotalEquity']
        if 'totalAssets' in response_json['annualReports'][0]:
            total_assets = response_json['annualReports'][0]['totalAssets']
        if 'totalLiabilities' in response_json['annualReports'][0]:
            total_liabilities = response_json['annualReports'][0]['totalLiabilities']
        else:
            #print('could not find ' + str(ticker))
            return {}
    else:
        print('could not find ')
        return {}
    return {'long_term_debt': long_term_debt, 'preferred_stock_total_equity': preferred_stock_total_equity, 'total_assets': total_assets, 'total_liabilities': total_liabilities}

# FIXME this may be off


def get_earnings(ticker):
    earnings = ''
    pram = {"function": "EARNINGS",
            "symbol": ticker,
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    response_json = response.json()

    if response_json.get('annualEarnings'):
        if 'reportedEPS' in response_json['annualEarnings'][0]:
            earnings = response_json['annualEarnings'][0]['reportedEPS']
        else:
            #print('could not find ' + str(ticker))
            return {}
    else:
        print('could not find ')
        return {}
    return {'anual_earnings': earnings}


def get_cashflow(ticker):
    cashflow = ''

    pram = {"function": "CASH_FLOW",
            "symbol": ticker,
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    response_json = response.json()

    if response_json.get('annualReports'):
        if 'operatingCashflow' in response_json['annualReports'][0]:
            cashflow = response_json['annualReports'][0]['operatingCashflow']
    else:
        return {}
    return {'operating_cash_flow': cashflow}


def get_fundementals(ticker):
    overview = get_comp_overview(ticker)
    balancesheet = get_balance_sheet(ticker)
    earnings = get_earnings(ticker)
    cashflow = get_cashflow(ticker)

    # fundementals = overview.update(balancesheet)
    return {**overview, **balancesheet, **earnings, **cashflow}


def format_comnam(comnam):
    comnam = comnam.lower()
    comnam = comnam.replace('inc', '')
    comnam = comnam.replace('corp', '')
    split = comnam.split()
    if len(split) == 1:
        return split[0]
    return split[0] + " " + split[1]


def asset_lookup(searchword):
    pram = {"function": "SYMBOL_SEARCH",
            "keywords": searchword,
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    response_json = response.json()

    if response_json.get('bestMatches'):
        curr_score = 0
        curr_ticker = ''
        for item in response_json['bestMatches']:
            if (item['3. type'] == 'Equity') and (item['8. currency'] == 'USD'):
                if float(item['9. matchScore']) > curr_score:
                    curr_score = float(item['9. matchScore'])
                    curr_ticker = item['1. symbol']
    else:
        #print('asset look up could not find ' + str(searchword))
        return None
    if curr_score < 0.8:
        return None
    return curr_ticker


def gen_ticker(ticker, tsymbol, shrcls):
    if shrcls:
        search_ticker = tsymbol + '-' + shrcls
    else:
        search_ticker = ticker
    return ticker

##############################################
####### ACTUAL LOOP ##########################
##############################################


print('starting')

crsp = pd.read_sql_query(
    "select * from api_crsp_securities", CONNECTION)
assets = crsp.permno.unique()
start_time = time.time()
time_check = start_time
req_num = 0
count = 1

df = pd.DataFrame()
for security in assets[:25]:
    # Check for nan permnos (should not be any)
    if(str(security) == 'nan'):
        continue
    if security == None:
        continue

    info = crsp[crsp['permno'] == security]
    ticker = info['ticker'].values[0]
    if ticker == None:
        continue
    tsymbol = info['tsymbol'].values[0]
    shrcls = info['shrcls'].values[0]
    comnam = format_comnam(info['comnam'].values[0])
    gensymbol = gen_ticker(ticker, tsymbol, shrcls)

    lookup_ticker = asset_lookup(tsymbol)
    req_num = req_num+1
    if not lookup_ticker:
        lookup_ticker = asset_lookup(ticker)
        req_num = req_num+1
        if not lookup_ticker:
            lookup_ticker = asset_lookup(gen_ticker)
            req_num = req_num+1
            if not lookup_ticker:
                lookup_ticker = asset_lookup(comnam)
                req_num = req_num+1
                if not lookup_ticker:
                    print('could not find ' + str(comnam) +
                          ' with ticker ' + str(ticker))
                    continue

    fundementals = get_fundementals(lookup_ticker)
    req_num = req_num + 4
    # print(pd.DataFrame.from_dict([fundementals]))

    df = pd.concat([df, pd.DataFrame.from_dict([fundementals])])
    if not fundementals:
        continue

    if (time.time()-time_check > 50) and req_num > 118:
        time.sleep(5)
        time_check = time.time()
        req_num = 0
    if req_num > 120:
        req_num = 0
        time_check = time.time()


print(df)
