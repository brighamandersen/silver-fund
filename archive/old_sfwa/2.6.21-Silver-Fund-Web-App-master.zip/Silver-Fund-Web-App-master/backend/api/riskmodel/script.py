import pickle
import pandas as pd

m = pickle.load(open("./model2.p", "rb"))
er = pd.Series([0.2, 0.1, 0.15], index=[10026, 10032, 10051])
summary, stats = m.port_opt(er)

print(summary)
print(stats)
