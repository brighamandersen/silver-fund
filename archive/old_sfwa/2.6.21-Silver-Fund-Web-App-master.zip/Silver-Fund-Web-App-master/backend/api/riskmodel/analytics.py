import pandas as pd
import numpy as np
from model import risk_model

class portfolio:
    """
    A base portfolio class that is used for analytics and generating data for panes. It needs to take a 
    a series of weights indexed by permno (for now, target: asset_id) and model instance. A mapping between 
    statistics and methods is hosted can be found here: 
    
    https://docs.google.com/document/d/1huGBBEig5w7bhe5tcsF4tv7TGThXmqzd4oJ8zHmNVhI/edit?usp=sharing


    Parameters
    ----------

    port_weights:
    
        The base class is formed in such a way that the class takes a :codeseries of weights
        to instantiate, and has the methods to use :code:`byuriskmodel.model.risk_model` atributes
        to return a corresponding portfolio analytics. 
        
    model_instance:
        
        Initialized :code:`byuriskmodel.model.risk_model`. 
        
    investment_horizon:
    
        Investment horizon for the portfolio: 'S' for short-term, and 'L' for long-term.
        
    Methods
    --------

    TODO
        
    

    Notes
    ------

    

    """

    def __init__(self,port_weights,model_instance,quiet=False,investment_horizon=None):
        port_weights = port_weights.sort_index()
        self.weights_total = port_weights.sort_index()
        self.holdings = np.array(port_weights.index)
        self.realized_betas = pd.Series(index=port_weights.index)
        self.realized_pcr = pd.Series(index=port_weights.index)
        self.realized_tcr = pd.Series(index=port_weights.index)
        if investment_horizon is None:
            self.horizon = 'S'
        else:
            self.horizon = investment_horizon
        self.model = model_instance #alternatively, only grab atributes required for analytics (TODO)
        self.recent = model_instance.estu_exposures_db.caldt.max()
        self._check_model_attributes()
        self.exante_betas, self.exante_alphas = self._benchmark_betas_alphas(exante=True)
        self._get_active_weights()
        permnoexisting = self.model.SV[self.horizon].sort_index().index
        self.model.permnoexisting = self.model.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(list(permnoexisting),self.recent)).sort_values(by='permno').permno
        self._assertions()
        

    def _assertions(self):
        assert isinstance(self.weights_total,pd.core.series.Series), "portfolio_weights must be a series"
        assert self.weights_total.index.isin(self.model.permnoexisting).all(), "the securities indexing portfolio_weights must be included in the estimation universe (in the risk_model.SV object and in the most recent date in estu_exposures_db)."
        assert self.horizon == 'S' or self.horizon == 'L', "investment horizon should be 'S' or 'L'"
    
    def _check_model_attributes(self):
        #assert isinstance(self.model,risk_model), "model_instance argument must of risk_model class"
        if ('daily' not in self.model.expected_returns.keys()):
            self.model._calculate_expected_returns()
        if ('S' not in self.model.SV.keys()) or ('L' not in self.model.SV.keys()):
            self.model.predict_specific_vol()
        if ('S' not in self.model.VCV.keys()) or ('L' not in self.model.VCV.keys()):
            self.model.predict_VCV()

   
    def _extract_expected_returns(self,exante=True):
        self.asset_er = {}
        for x in self.model.expected_returns:
            self.asset_er[x] = self.model.expected_returns[x].loc[list(self.holdings)]
        return self.asset_er
    
    def _get_exposures(self):
        self.expos_port = self.model.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(list(self.holdings),self.recent)).sort_values(by='permno').set_index('permno')[list(self.model.xvarlist)]
        return self.expos_port
    
    def _get_factor_returns(self):
        self.factor_returns = self.model.factor_returns_db.tail(1)[self.model.xvarlist]
        return self.factor_returns
    
    def _get_active_weights(self):
        holdings = self.holdings
        b = self.model.benchmark_db[self.model.benchmark_db.permno.isin(self.holdings)]['weight'].to_numpy()
        w = self.weights_total.to_numpy()
        self.weights_active = w-b
        return self.weights_active
        
    def _exante_portfolio_return(self):
        self.portfolio_return = {}
        self.model._calculate_expected_returns()
        for x in self.model.expected_returns:
            self.portfolio_return[x] = self.model.expected_returns[x].loc[self.holdings].values @ self.weights_total.to_numpy()
        return self.portfolio_return

    def _exante_std_daily(self,active=False):
        holdings = self.holdings
        w = self.weights_total
        if active:
            w = self.weights_active
        V = self.model.V
        var = w @ V[self.horizon].loc[list(holdings), list(holdings)] @ w.T
        std = np.sqrt(var)
        return std
    
    def _exante_std_dbd(self,active=False):
        stds = {}
        for s in self.holdings:
            stds[s] = self.model.V[self.horizon].loc[s,s]
        return pd.Series(data=stds)
    
    def _realized_std_daily(self,active=False,std_weighting=None):
        equity_ret_ts = self.model.stk_db.loc[self.model.stk_db.permno.isin(self.holdings),['permno','ret','caldt']]
        w = self.weights_total
        if active:
            w = self.weights_active
        port_ret_ts = equity_ret_ts.groupby('caldt').apply(self._ret_by_date,w)
        std = np.std(port_ret_ts[-23:])
        return std
    
    def _realized_std_dbd(self,active=False):
        stds = {}
        for s in self.holdings:
            ret_ts = self.model.stk_db.loc[self.model.stk_db.permno==s,['ret']]
            stds[s] = np.std(ret_ts.to_numpy()[-23:])
        return pd.Series(data=stds)
    
    @staticmethod
    def _ret_by_date(g,weights):
        g = g.sort_values(by = ['permno'])
        g = g
        try:
            r = weights.values.T @ g.ret.values
        except:
            r = np.nan
            pass
        return r
    
    def _portfolio_beta(self,active=False,exante=None):
        if exante is None:
            raise ValueError("Ex-ante vs Realized? Specify with exante=True or exante=False (for realized)") 
        if active:
            w = self.weights_active
        else:
            w = self.weights_total[list(self.holdings)].to_numpy()
        b,a = self._benchmark_betas_alphas(exante)
        pb = b[list(self.holdings)].to_numpy() @ w
        return pb
    
    def _holdings_betas(self,exante=None):
        if exante is None:
            raise ValueError("Ex-ante vs Realized? Specify with exante=True or exante=False (for realized)")
        b,a = self._benchmark_betas_alphas(exante)
        return b[list(self.holdings)]
    
    def _holdings_alphas(self,exante=None):
        if exante is None:
            raise ValueError("Ex-ante vs Realized? Specify with exante=True or exante=False (for realized)")
        b,a = self._benchmark_betas_alphas(exante)
        return a[list(self.holdings)]
    
    def _exposures(self,active=False):
        if active:
            w = self.weights_total.to_numpy()
        else:
            w = self.weights_active
        expos_ = self.model.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(list(self.holdings),self.recent)).sort_values(by='permno').set_index('permno')[list(self.model.xvarlist)]
        expos = expos_.to_numpy()
        port_expos = w @ expos
        return pd.Series(data = port_expos, index = self.model.xvarlist)
    
    def _exposures_bd(self):
        expos_ = self.model.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(list(self.holdings),self.recent)).sort_values(by='permno').set_index('permno')[list(self.model.xvarlist)]
        return expos_
    
    
    def _portfolio_attribution(self,exante=None):
        if exante is None:
            raise ValueError("Ex-ante vs Realized? Specify with exante=True or exante=False (for realized)") 
        if exante:
            fac_pred_= self.model._EWMA_factor_return_prediction()
            expos_ = self.model.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(list(self.holdings),self.recent)).sort_values(by='permno').set_index('permno')[list(self.model.xvarlist)]
            w = self.weights_total.sort_index().to_numpy()
            expos = expos_.to_numpy()
            fac_pred = fac_pred_.to_numpy()
            fX = np.multiply(expos, fac_pred[:, np.newaxis].T)
            wfX = w @ fX
            summ = np.sum(wfX,axis = 0)
            er_ = self.model.expected_returns['daily'].loc[list(self.holdings)].sort_index()
            er = er_.to_numpy()
            wer = np.dot(w,er)
            alpha_ex_ = wer - summ
            alpha_ex = pd.DataFrame([alpha_ex_],index = ['alpha'], columns = ['daily_exante'])
            exante_port = pd.DataFrame(data = wfX, index = self.model.xvarlist, columns = ['daily_exante']).append(alpha_ex)
            exante_port['annual_exante'] = exante_port['daily_exante'] * 252.
            return exante_port
        else:
            expos_ = self.model.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(list(self.holdings),self.recent)).sort_values(by='permno').set_index('permno')[list(self.model.xvarlist)]
            fac_ret_ = self.model.factor_returns.loc[self.recent][list(self.model.xvarlist)]
            ret_ = self.model.stk_db.query("(permno in {0}) & (caldt=='{1}')".format(list(self.holdings),self.recent)).sort_values(by='permno').set_index('permno').ret
            if exante:
                ret = self.model.expected_returns['daily'].loc[list(self.holdings)].sort_index()
            ret = ret_.to_numpy()
            expos = expos_.to_numpy()
            fac_ret = fac_ret_.to_numpy()
            #multiply factor returns to each exposure - n x k matrix
            fX = np.multiply(expos, fac_ret[:, np.newaxis].T)
            #fX = np.matmul(expos,fac_ret.T)
            w = self.weights_total.sort_index().to_numpy()
            wfX = w @ fX
            summ = np.sum(wfX,axis = 0)
            wret = np.dot(w,ret)
            alpha = wret -summ
            alpha_ = pd.DataFrame([alpha], index = ['alpha'],columns = ['daily'])
            realized_port = pd.DataFrame(data = wfX, index = self.model.xvarlist, columns = ['daily']).append(alpha_)
            return realized_port
    
        
    def _industry_attribution_breakdown(self,exante=True):
        if exante is None:
            raise ValueError("Ex-ante vs Realized? Specify with exante=True or exante=False (for realized)") 
        current_portfolio = pd.Series(data = self.weights_total, index = self.holdings)
        #port = self._portfolio_attribution(exante)
        #sw = current_portfolio.sort_index()
        recent_expos = self.model.estu_exposures_db.query("(caldt == '{0}') & (permno in {1})".format(self.recent, list(self.holdings))).set_index('permno')
        industries_rep = recent_expos.industry.unique()
        X = recent_expos[self.model.xvarlist + ['industry']]
        #styles = [x for x in self.xvarlist if x not in self.indlist]
        industry_breakdown = []
        for ind in industries_rep:
            exp_ = X.loc[X['industry']==ind]
            exp_ = exp_[self.model.xvarlist]
            w = current_portfolio.loc[exp_.index]
            exp = exp_.to_numpy()
            # att = self._exante_portfolio_attribution(exp)
            fac_ = self.model.factor_returns.loc[self.recent][list(self.model.xvarlist)]
            if exante:
                fac_= self.model._EWMA_factor_return_prediction()
            fac = fac_.to_numpy()
            fX = np.multiply(exp, fac[:, np.newaxis].T) 
            wfX = w @ fX
            summ = np.sum(wfX,axis = 0)
            #MAKE THOSE ER for exante==True!
            ret_ = self.model.stk_db.query("(permno in {0}) & (caldt=='{1}')".format(list(exp_.index),self.recent)).sort_values(by='permno').set_index('permno').ret
            if exante:
                ret = self.model.expected_returns['daily'].loc[list(self.holdings)].sort_index()
            ret = ret_.to_numpy()
            wer = np.dot(w,ret)
            alpha_ex_ = wer - summ
            alpha_ex = pd.DataFrame([alpha_ex_],index = ['alpha'], columns = [ind])
            port = pd.DataFrame(data = wfX, index = self.model.xvarlist, columns = [ind]).append(alpha_ex)
            industry_breakdown.append(port)
        df = pd.DataFrame()
        for i in range(len(industry_breakdown)):
            df = pd.concat([df, industry_breakdown[i]], axis = 1)
        industry_attribution = df.T
        return industry_attribution
    
    def _benchmark_betas_alphas(self,exante=None):
        if exante is None:
            raise ValueError("Ex-ante vs Realized? Specify with exante=True or exante=False (for realized)") 
        permnoexisting = self.model.SV['S'].sort_index().index
        recent = self.model.estu_exposures_db.caldt.max()
        b_permnos = self.model.benchmark_db[self.model.benchmark_db.permno.isin(list(permnoexisting))].sort_values(by = 'permno').permno
        expos_ = self.model.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(list(b_permnos),recent)).sort_values(by='permno')[list(self.model.xvarlist)]
        expos = expos_.to_numpy()
        final_permnos = self.model.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(list(b_permnos),recent)).sort_values(by='permno').permno
        bw_ = self.model.benchmark_db[self.model.benchmark_db.permno.isin(list(final_permnos))].sort_values(by = 'permno').weight
        bw = bw_.to_numpy()
        ret_ = self.model.stk_db.query("(permno in {0}) & (caldt=='{1}')".format(list(final_permnos),self.recent)).sort_values(by='permno').set_index('permno').ret
        if exante:
            ret_ = self.model.expected_returns['daily'].loc[final_permnos]
        ret = ret_.to_numpy()
        V = self.model._stock_level_VCV(expos, final_permnos)[self.horizon] 
        betas = V @ bw / (bw.T @ V @ bw)
        fac_ = self.model.factor_returns.loc[self.recent][list(self.model.xvarlist)]
        if exante:
            fac_ = self.model._EWMA_factor_return_prediction()
        fac = fac_.to_numpy()
        alphas = ret - betas * np.matmul(np.matmul(bw.T,expos),fac)
        alphas = pd.Series(alphas,index=final_permnos)
        betas = pd.Series(betas,index=final_permnos)
        return betas, alphas

    def _marginal_contribution_risk(self,active=False):
        sigma = self._exante_std_daily(active)
        V = self.model.V[self.horizon].loc[list(self.holdings),list(self.holdings)]
        w = self.weights_total
        if active:
            w = self.weights_active
        mcr = V @ w / sigma
        return mcr
        
    def _total_contribution_risk(self, active = False):
        w = self.weights_total
        if active:
            w = self.weights_active
        tcr = w * self._marginal_contribution_risk(active)
        return tcr
        
    def _percent_contribution_risk(self,active=False):
        tcr = self._total_contribution_risk(active)
        sigma = self._exante_std_daily(active)
        if active:
            w = self.weights_active
        pcr = tcr/sigma
        return pcr
    
    def _diversification_coefficient(self,active=False):
        pcr = self._percent_contribution_risk(active)
        summ = (pcr**2).sum()
        self.dc = summ **-1
        return self.dc
    
    def _factor_mcr(self,active=False):
        w = self.weights_total
        sigma = self._exante_std_daily(active)
        if active:
            w = self.weights_active
        expos = self._get_exposures().to_numpy()
        beta_p = w @ expos
        beta_star = np.concatenate((beta_p, np.array([1])))
        VCV = self.model.VCV[self.horizon]
        VCV_ = VCV.to_numpy()
        u = self.model.SV[self.horizon].loc[list(self.holdings), list(self.holdings)]
        u_port = w.T @ u @ w
        newcol = np.zeros((len(VCV_),1))
        VCV_ = np.hstack((VCV_, newcol))
        newrow = np.zeros((1,len(VCV_)+1))
        VCV_ = np.vstack((VCV_,newrow))
        VCV_[-1,-1] = u_port 
        fmcr = beta_star @ VCV_ / sigma
        return fmcr
    
    def _factor_tcr(self,active=False):
        w = self.weights_total
        if active:
            w = self.weights_active
        factor_mcr = self._factor_mcr(active)
        expos = self._get_exposures().to_numpy()
        beta_p = w @ expos
        beta_star = np.concatenate((beta_p, np.array([1])))
        factor_tcr = beta_star * factor_mcr
        return pd.Series(data=factor_tcr,index=self.model.xvarlist+['specific'])
    
    def _factor_pcr(self,active=False):
        factor_tcr = self._factor_tcr(active)
        sigma = self._exante_std_daily(active)
        factor_pcr = factor_tcr / sigma
        return pd.Series(data=factor_pcr,index=self.model.xvarlist+['specific'])
        

    