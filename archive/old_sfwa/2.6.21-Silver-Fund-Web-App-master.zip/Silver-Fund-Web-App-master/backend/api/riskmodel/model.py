import pandas as pd
import numpy as np
from tabulate import tabulate
# import styles as styles_module
# import industries as industries_module
# import filter as filter_module
# import model_validation as model_validation_module
from api.riskmodel import styles as styles
from api.riskmodel import industries as industries
from api.riskmodel import filter as filter_module
from api.riskmodel import model_validation as model_validation
import math
import cvxpy as cp
import statsmodels.api as sm
import time
import warnings


class risk_model:
    """    
    Main class for Silver Fund risk model. Under construction: more documentation to come.

    Parameters
    ----------

    stk_db: pandas.core.frame.DataFrame
        :code:`DataFrame` containing daily price, return, shares outstanding, volume, and security identifiers (SIC Code, CUSIP, BYU ID, etc.).
    fundamentals_db: pandas.core.frame.DataFrame
        :code:`DataFrame` containing fundamentals data for securities including 12-month forward earnings, trailing 12-month earnings, long-term earnings
        growth analyst forecasts, trailing 5 years earnings growth, trailing 5 years sales growth, trailing 12-month dividend, book-value of common equity, 
        book-value of preferred equity, book value of long-term debt, book-value of total debt, and book value of total assets.
    exposures_db: pandas.core.frame.DataFrame
        :code:`DataFrame` containing historical factor exposures (None if calculating historical factor exposures from scratch). An error will be thrown if 
        the contents of :code:`exposures_db` do not match the style and industry factor print(c, 'summed to zero, somethings is wrong!')ations in from :code:`model_type` and :code:`ind`.
    benchmark_db: pandas.core.frame.DataFrame
        :code:`DataFrame` containing historical constituent data for selected benchmarks (currently Russell 3000 and S&P 500).
    factor_returns_db: pandas.core.frame.DataFrame
        :code:`DataFrame` containing historical factor returns.
    ind: str
        Defaults to 'fama_french_49_industries', which is currently the only available industry definition scheme. Future definition schemes may be developed 
        for other industry definitions based on SIC code, GICS code, etc.
    model_type: str
        Defaults to :code:`'USE4'` which includes industry factors as well as all style factors defined in the Barra USE4 model. Other available model types currently 
        include :code:`'USE4_nofundamentals'` which includes all Barra USE4 style factors that do not require data from corporate financial statements. Future development
        will likely include options for the style factors in the Barra GEM model. :code:`'custom'` is also an option. If :code:`'custom'` is selected, the user inputs 
        a list of string names for style factors in the :code:`style_factors` argument.
    filter: str
        String name of the filter class in the filter module to use as the filter for the model. Defaults to 'common_equity_illiquidity1'.
    quiet: bool
        Whether or not to suppress updates to standard ouput. Defaults to False.
    style_factors: None or list(str)
        Only used if :code:`model_type` is set to :code:`'custom'`. List of string style factors to use in a custom model.

    Methods
    -------
    gen_factors()
        Return factor returns and factor portfolio compositions (portfolio weights).
    predict_VCV()
        Predict and return factor covariance matrix via Newey-West exponential weighted methodology. Returns dictionary with keys 'L' and 'S' for 
        long- or short-term predictions (corresponding to USE4S and USE4L prediction horizons in Barra methodology).
    predict_specific_vol()
        Predict a diagonal matrix of specific volatilities by security. Returns dictionary with keys 'L' and 'S' for long- or short-term predictions (corresponding to 
        USE4L and USE4S prediction horizons in Barra methodology).
    analyze_portfolio(portfolio_weights, time_series_historical=False)
        Return volatility forecasts, expected returns, and factor exposures for a portfolio defined in :code:`portfolio_weights`. If :code:`time_series_historical` is 
        specified, historical forecasts and exposures will be returned in addition to future forecasts and current exposures (requires a historical time-series of portfolio weights).
        Return object is a tuple of the form tuple(exposures,variance,expected_return) where exposures is a :code:`pandas` :code:`Series` with factor exposures of the portfolio, 
        variance is a dictionary with portfolio predicted volatility (variance of return) indexed by keys 'L' and 'S' for long- or short-term predictions (corresponding to USE4L and 
        USE4S prediction horizons in Barra methodology), and expected_return is a dictionary indexed in the same manner.
    portfolio_optimization(expected_return, class_distribution = None, horizon = 'S', benchmark = 'russell_3000', active_risk_target = 0.1)
        Constrained optimization of information ratio relative to a given benchmark. User provies an array of expected returns - assumed to be such that alpha is zero for all stocks without user input), this method outputs weights of an optimal portfolio given 
        an :code:`active_risk_target`. More functionality is planned for future development (more flexible constraints, etc.).

    Notes
    ------
    Filtering, data-replacement, and updating the exposures database (if :code:`stk_db` contains more recent data than :code:`exposures_db`) is completed upon initialization of the model object.

    """

    def __init__(self, stk_db, fundamentals_db, exposures_db, benchmark_db, factor_returns_db, positions_db, ind='fama_french_49_industries', model_type='USE4', filter='common_equity_illiquidity1', quiet=False, style_factors=None, adhoc=None):
        self.stk_db = stk_db
        if adhoc != None:
            self._get_adhoc_data(adhoc)
        self.fundamentals_db = fundamentals_db
        self.exposures_db = exposures_db
        self.benchmark_db = benchmark_db
        self.factor_returns_db = factor_returns_db
        self.positions_db = positions_db
        self.quiet = quiet
        self.custom_style_factors = style_factors
        self._assign_attributes(ind, filter, model_type)
        self._assertions()
        self._initial_filter()
        self._initial_data_replacement()
        self._update_exposures()
        self._secondary_filter()
        self._secondary_data_replacement()
        self._update_factors()
        self.VCV = {}
        self.SV = {}
        self.benchmark_betas = {}
        self.benchmark_alphas = {}
        self.expected_returns = {}
        self.adhoc = adhoc
        if adhoc != None:
            self._add_adhoc(adhoc)

    def _assign_attributes(self, ind, filter, model_type):
        if not self.quiet:
            print("Initializing style, filter, and industry classes")
        available_industries = ['fama_french_49_industries',
                                'fama_french_38_industries', 'fama_french_17_industries']
        available_filters = ['common_equity_illiquidity1', 'common_equity']
        available_model_types = ['USE4', 'USE4_nofundamentals', 'custom']
        available_style_factors = ['mktbeta', 'momentum', 'size', 'nonlinear_beta', 'nonlinear_size',
                                   'liquidity', 'residual_volatility', 'value', 'div_yield', 'leverage', 'earnings_yield', 'growth']
        assert ind in available_industries, "ind must be one of the available industry definition schemes: {}".format(
            available_industries)
        assert filter in available_filters, "filter must be one of the available filters: {}".format(
            available_filters)
        assert model_type in available_model_types, "model_type must be one of the available model types: {}".format(
            available_model_types)
        if model_type == 'custom':
            for s in self.custom_style_factors:
                assert (
                    s in available_style_factors), "style {} is not available".format(s)
            if ('nonlinear_beta' in self.custom_style_factors) & ('mktbeta' not in self.custom_style_factors):
                raise ValueError(
                    "mktbeta must be included in custom style factors if nonlinear_beta is specified")
            if ('nonlinear_size' in self.custom_style_factors) & ('size' not in self.custom_style_factors):
                raise ValueError(
                    "size must be included in custom style factors if nonlinear_size is specified")
            if ('residual_volatility' in self.custom_style_factors) & ('mktbeta' not in self.custom_style_factors):
                raise ValueError(
                    "mktbeta must be included in custom style factors if residual_volatility is specified")

        if ind == 'fama_french_49_industries':
            self.industries = industries_module.fama_french_49_industries()
        elif ind == 'fama_french_38_industries':
            self.industries = industries_module.fama_french_38_industries()
        elif ind == 'fama_french_17_industries':
            self.industries = industries_module.fama_french_17_industries()
        if filter == 'common_equity_illiquidity1':
            self.filter = filter_module.common_equity_illiquidity1()
        elif filter == 'common_equity':
            self.filter = filter_module.common_equity()
        if model_type == 'USE4':
            self.styles = []
            self.styles.append(styles_module.mktbeta())
            self.styles.append(styles_module.momentum())
            self.styles.append(styles_module.size())
            self.styles.append(styles_module.residual_volatility())
            self.styles.append(styles_module.liquidity())
            self.styles.append(styles_module.nonlinear_beta())
            self.styles.append(styles_module.nonlinear_size())
            self.styles.append(styles_module.value())
            self.styles.append(styles_module.div_yield())
            self.styles.append(styles_module.leverage())
            self.styles.append(styles_module.growth())
            self.styles.append(styles_module.earnings_yield())
        elif model_type == 'USE4_nofundamentals':
            self.styles = []
            self.styles.append(styles_module.mktbeta())
            self.styles.append(styles_module.momentum())
            self.styles.append(styles_module.size())
            self.styles.append(styles_module.residual_volatility())
            self.styles.append(styles_module.liquidity())
            self.styles.append(styles_module.nonlinear_beta())
            self.styles.append(styles_module.nonlinear_size())
        elif model_type == 'custom':
            self.styles = []
            if 'mktbeta' in self.custom_style_factors:
                self.styles.append(styles_module.mktbeta())
            if 'size' in self.custom_style_factors:
                self.styles.append(styles_module.size())
            if 'momentum' in self.custom_style_factors:
                self.styles.append(styles_module.momentum())
            if 'residual_volatility' in self.custom_style_factors:
                self.styles.append(styles_module.residual_volatility())
            if 'liquidity' in self.custom_style_factors:
                self.styles.append(styles_module.liquidity())
            if 'nonlinear_beta' in self.custom_style_factors:
                self.styles.append(styles_module.nonlinear_beta())
            if 'nonlinear_size' in self.custom_style_factors:
                self.styles.append(styles_module.nonlinear_size())
            if 'value' in self.custom_style_factors:
                self.styles.append(styles_module.value())
            if 'div_yield' in self.custom_style_factors:
                self.styles.append(styles_module.div_yield())
            if 'leverage' in self.custom_style_factors:
                self.styles.append(styles_module.leverage())
            if 'growth' in self.custom_style_factors:
                self.styles.append(styles_module.growth())
            if 'earnings_yield' in self.custom_style_factors:
                self.styles.append(styles_module.earnings_yield())

        if 'mcap' not in list(self.stk_db.columns):
            self.stk_db['mcap'] = self.stk_db.prc * self.stk_db.shr * 1000.
        self.available_benchmarks = ['Russell3000']
        self.indlist = list(self.industries.indlist)
        self.xvarlist = [
            s.__class__.__name__ for s in self.styles] + self.indlist + ['country']

    def _assertions(self):
        assert isinstance(
            self.stk_db, pd.core.frame.DataFrame), "stk_db must be a pandas dataframe"
        assert isinstance(
            self.fundamentals_db, pd.core.frame.DataFrame), "fundamentals_db must be a pandas dataframe"
        assert isinstance(
            self.benchmark_db, pd.core.frame.DataFrame), "benchmark_db must be a pandas dataframe"
        assert isinstance(self.factor_returns_db,
                          pd.core.frame.DataFrame), "factor_returns_db must be a pandas dataframe"
        #assert isinstance(self.performance_db,pd.core.frame.DataFrame), "performance_db must be a pandas dataframe"
        #assert isinstance(self.security_risk_db,pd.core.frame.DataFrame), "security_risk_db must be a pandas dataframe"
        assert all([(s in list(self.benchmark_db.columns)) for s in ['permno', 'caldt',
                                                                     'benchmark', 'weight']]), "benchmark_db must have caldt, permno, and benchmark columns"
        #assert all([(s in list(self.benchmark_db.benchmark.unique())) for s in self.available_benchmarks]), "All available benchmarks ({}) must be included in benchmark_db".format(self.available_benchmarks)
        # parent-child assertion instance stuff -- debug
        assert all([isinstance(s, styles_module.style) for s in self.styles]
                   ), "styles must be a list of styles.style from the styles module"
        # parent-child assertion instance stuff -- debug
        assert isinstance(
            self.industries, industries_module.industries), "industries must be an industries.industries class from the industries module"
        assert isinstance(
            self.filter, filter_module.filter), "filter must be a filter.filter class from the filter module"
        assert all([(s.__class__.__name__ in list(self.exposures_db.columns)) for s in self.styles]
                   ), "all styles specified in class instantiation must be present in exposures_db"
        assert all([(s.__class__.__name__ in list(self.factor_returns_db.columns)) for s in self.styles]
                   ), "all styles specified in class instantiation must be present in factor_returns_db"
        assert isinstance(self.quiet, bool), "quiet must be boolean"
        # performance_db_columns =    ['caldt','ret']+[s.__class__.__name__+'_exposure' for s in self.styles]+[benchmark+'_exante_beta' for benchmark in self.available_benchmarks]+\
        #                            [benchmark+'_realized_beta' for benchmark in self.available_benchmarks]+['exante_total_daily_volatility','realized_total_daily_volatility']+\
        #                            ['exante_active_daily_volatility_'+benchmark for benchmark in self.available_benchmarks]+['realized_active_daily_volatility_'+benchmark for benchmark in self.available_benchmarks]+\
        #                            ['exante_total_annual_volatility','realized_total_annual_volatility']+[x+'_exante_attribution' for x in self.xvarlist+['alpha']]+\
        #                            ['exante_active_annual_volatility_'+benchmark for benchmark in self.available_benchmarks]+['realized_active_annual_volatility_'+benchmark for benchmark in self.available_benchmarks]+\
        #                            [x+'_realized_attribution' for x in self.xvarlist+['alpha']]+['expected_return_annual','expected_return_daily']
        #assert all([(col in list(self.performance_db.columns)) for col in performance_db_columns]), "please ensure all necessary columns are present in the performance_db object"
        # security_risk_db_columns =  ['caldt','permno']+[benchmark+'_exante_beta' for benchmark in self.available_benchmarks]+['exante_total_daily_volatility','realized_total_daily_volatility']+\
        #                            ['exante_total_annual_volatility','realized_total_annual_volatility']+['expected_return_annual','expected_return_daily']
        #assert all([(col in list(self.security_risk_db.columns)) for col in security_risk_db_columns]), "please ensure all necessary columns are present in the security_risk_db object"

    def _get_adhoc_data(self, adhoc):
        """
        This is designed to get ad hoc data from the stock database fed to the model object 
        before it is filtered out in the filter class.
        """
        self.adhocdata = {}
        for permno in adhoc:
            self.adhocdata[permno] = self.stk_db.loc[self.stk_db.permno == permno, [
                'ret', 'permno', 'caldt']]

    def _add_adhoc(self, adhoc):
        """
        This function adds a list of ad hoc securities to the estimation universe exposures 
        table after factor returns are generated so it can be used in portfolio analysis and 
        optimization without being part of model estimation. The security must have 
        a time series of returns in the stock database for this to work. If one of the ad hoc 
        assets in the list is not in the stock database, a warning will be given and it will 
        not be added (unavailable for analysis in a portfolio). The way this works is the 
        time series in the stock database is used with the factor returns database to regress
        coefficients from a time series regression of the security returns on the factor 
        returns to get exposures. The time series used may be historical (not recent). For 
        example, maybe you have data from up to the last quarter (from CRSP) for this security
        but you don't have it updating daily. Then this will use the entire time series 
        in the stock database provided for regressions, but it will put the exposures from 
        those regressions in the most recent date in the estimation universe exposures 
        database so it can be used for analysis. These ad hoc securities will also be added 
        to specific volatility (see specific volatility methods for details). 
        For these (or any) securities to be considered in portfolio optimization, they 
        also need to be in the most recent date in the benchmark database.

        An ad hoc security should NOT be a security already considered in the model. There will 
        be serious problems if the security is both considered in the model construction (i.e. share code 
        10 and 11 and in both the stock and fundamentals databases) and in ad hoc.
        """
        for permno in adhoc:
            if permno not in self.stk_db.permno:
                warnings.warn(
                    "Asset ID / PERMNO {} is not in the stock database. It cannot be added as an ad hoc security to the exposures database for analysis.".format(permno))
            else:
                tsret = self.adhocdata[permno]
                tsret = tsret.merge(self.factor_returns, on='caldt')
                exposures = sm.OLS(
                    tsret.ret, tsret[self.xvarlist]).fit().params
                exposures['caldt'] = self.estu_exposures_db.caldt.max()
                exposures['permno'] = permno
                self.estu_exposures_db = self.estu_exposures_db.append(
                    exposures, ignore_index=True)

    def _initial_filter(self):
        if not self.quiet:
            print("Initial filtering")
        if 'Unnamed: 0' in self.factor_returns_db.columns:
            self.factor_returns_db = self.factor_returns_db.drop(
                'Unnamed: 0', axis=1)
        self.stk_db, self.fundamentals_db = self.filter.initial_filter(
            self.stk_db, self.fundamentals_db)

    def _secondary_filter(self):
        # estu: estimation universe
        if not self.quiet:
            print("Secondary filtering")
        self.estu_stk_db, self.estu_fundamentals_db, self.estu_exposures_db = self.filter.secondary_filter(
            self.stk_db, self.fundamentals_db, self.exposures_db)

    def _initial_data_replacement(self):
        # TODO: This needs to replace all NAN in fundamentals_db and stk_db to the point that linear algebra routines will have no issues generating style and industry exposures
        #       Can be from forward filling within reason, filtering out NANs if necessary further than the filter class specifies, etc.
        if not self.quiet:
            print("Initial data replacement")
            self.stk_db['rf'] = self.stk_db.rf.fillna(method='ffill')
            self.stk_db['siccd'] = self.stk_db.groupby('permno')[
                'siccd'].ffill()
        pass

    def _secondary_data_replacement(self):
        # TODO: This needs to replace all NAN in exposures_db to the point that linear algebra routines will have no issues generating VCV and factor returns from exposures_db
        #       This will probably use a structural model similar to the specific return structural model to generate exposures for securities with missing exposures by assuming
        #       that a missing exposure will be similar to the exposures of similar stocks.

        if not self.quiet:
            print("Secondary data replacement")
        # for xvar in self.xvarlist:
        #    self.estu_exposures_db = self.estu_exposures_db.query("{} == {}".format(xvar,xvar))

        implementation1 = True
        implementation2 = False
        placeholderimplmentation = False
        noimplementation = False

        if implementation1:
            self.estu_exposures_db['industry'] = np.nan
            #debuga = self.estu_exposures_db.query("caldt > '12-01-2019'")
            for ind in self.indlist:
                self.estu_exposures_db.loc[self.estu_exposures_db[ind]
                                           == 1, 'industry'] = ind
                #debuga = self.estu_exposures_db.query("caldt > '12-01-2019'")
            self.estu_stk_db = self.estu_stk_db.merge(
                self.estu_exposures_db[['permno', 'caldt', 'industry']], on=['permno', 'caldt'])
            #debugb = self.estu_stk_db.query("caldt > '12-01-2019'")
            self.estu_exposures_db = self.estu_exposures_db.query(
                "(caldt == caldt) and (industry == industry)")
            #debuga = self.estu_exposures_db.query("caldt > '12-01-2019'")
            self.estu_exposures_db.caldt = self.estu_exposures_db.caldt.astype(
                'str')
            #debuga = self.estu_exposures_db.query("caldt > '12-01-2019'")
            for x in [x for x in self.xvarlist if x not in self.indlist+['country']]:
                self.estu_exposures_db[x] = self.estu_exposures_db.groupby('permno')[
                    x].ffill()
                #debuga = self.estu_exposures_db.query("caldt > '12-01-2019'")
                self.estu_exposures_db[x] = self.estu_exposures_db.groupby(
                    ['industry', 'caldt'])[x].transform(lambda g: g.fillna(g.mean()))
                #debuga = self.estu_exposures_db.query("caldt > '12-01-2019'")
                #self.estu_exposures_db[x] = self.estu_exposures_db.groupby(['caldt'])[x].transform(lambda g: g.fillna(g.mean()))
            self.estu_exposures_db.caldt = self.estu_exposures_db.caldt.astype(
                'datetime64[D]')
            #debuga = self.estu_exposures_db.query("caldt > '12-01-2019'")
            # for x in self.indlist+['country']:
            for x in self.xvarlist:
                self.estu_exposures_db = self.estu_exposures_db.query(
                    "{} == {}".format(x, x))
                #debuga = self.estu_exposures_db.query("caldt > '12-01-2019'")
            for x in ['ret', 'prc', 'vol', 'shr', 'rf', 'permno', 'caldt']:
                self.estu_stk_db = self.estu_stk_db.query(
                    "{} == {}".format(x, x))
                #debugb = self.estu_stk_db.query("caldt > '12-01-2019'")

            # check and raise error if there are still nan
            if self.estu_stk_db[['ret', 'prc', 'vol', 'shr', 'rf', 'permno', 'caldt']].isnull().values.any():
                raise ValueError(
                    "estimation universe stock database has missing values (nan). Secondary data replacment failed.")
            if self.estu_exposures_db[self.xvarlist].isnull().values.any():
                raise ValueError(
                    "estimation universe exposures database has missing values (nan). Secondary data replacement failed.")
        # print(self.estu_exposures_db.isna().sum())
        # print(self.estu_stk_db.isna().sum())

        # Note: This is simply wrong -- and is only here as a placeholder
        if placeholderimplmentation:
            replacementdf = pd.DataFrame(np.random.random(
                self.estu_exposures_db.shape), columns=self.estu_exposures_db.columns, index=self.estu_exposures_db.index)
            self.estu_exposures_db = self.estu_exposures_db.fillna(
                replacementdf)
            replacementdf = pd.DataFrame(np.random.random(
                self.estu_stk_db.shape), columns=self.estu_stk_db.columns, index=self.estu_stk_db.index)
            self.estu_stk_db = self.estu_stk_db.fillna(replacementdf)
        # ---------------------------------------
        # Paige's code (currently not working)
        # ---------------------------------------
        if implementation2:
            self.estu_stk_db, self.estu_fundamentals_db, self.estu_exposures_db = self.exp_replacement(
                self.estu_stk_db, self.estu_fundamentals_db, self.estu_exposures_db)

        if noimplementation:
            pass

    # def exp_replacement(self, stk_db, fundamentals_db, exposures_db):
    #     """
    #     This function replaces missing exposure data. Exposures are first forward filled
    #     at the stock identifier level, and further missing data are replaced via industry
    #     averages. The function requires stk_db, fundamentals_db, and exposures_db as pandas
    #     dataframes.  It returns the non-NAN exposures database along with associated
    #     fundamentals and stk_db

    #     ----------
    #     """
    #     #filters missing exposures based on stk_db
    #     stk=stk_db.copy()
    #     #ind = Industries()
    #     stk_w_ind = self.industries.form_industries(stk_db)
    #     list_ind=stk_w_ind.columns.tolist()
    #     cols_to_remove = ['permno', 'caldt', 'country']
    #     for col in cols_to_remove:
    #          list_ind.remove(col)
    #     #print(list_ind)
    #     stk_m=pd.melt(stk_db, id_vars=['permno', 'caldt'], value_vars=list_ind)
    #     stk_m=stk_m.loc[stk_m['value']==1].drop(columns=['value'])
    #     stk_merged=stk.merge(stk_m,on=['permno', 'caldt'])

    #     exp_columns_to_merge_on = ['permno','caldt']
    #     exp_columns_to_replace_on = exposures_db.columns.tolist()
    #     for merged_column in exp_columns_to_merge_on:
    #          exp_columns_to_replace_on.remove(merged_column)
    #     #exp_columns_to_replace_on.remove('variable')
    #     #print(exp_columns_to_replace_on)

    #     stk_exp_df = exposures_db.merge(stk_merged,on=exp_columns_to_merge_on)

    #     for exp_col in exp_columns_to_replace_on:
    #          stk_exp_df[exp_col] = stk_exp_df.groupby('permno')[exp_col].transform(lambda x: x.ffill())
    #          stk_exp_df[exp_col] = stk_exp_df.groupby('variable')[exp_col].transform(lambda x: x.fillna(x.mean()))
    #          stk_exp_df = stk_exp_df.loc[stk_exp_df[exp_col].notna()]

    #     final_stk_db_cols = ['permno','caldt','shrcd','excd','siccd','prc','ret','vol','shr','rf']
    #     final_stk_db = stk_exp_df[final_stk_db_cols]

    #     final_exp_db_cols = exp_columns_to_replace_on + ['permno', 'caldt']
    #     final_exp_db = stk_exp_df[final_exp_db_cols]

    #     #TO DO:When have fundamentals DB and exposures, run for fundamentals
    #     return final_stk_db, fundamentals_db, final_exp_db

    def _update_exposures(self):
        # TODO: Make this runs only for dates that are not already in the self.exposures_db
        recent_stk_db = self.stk_db.caldt.max()
        recent_exposures_db = self.exposures_db.caldt.max()
        if recent_exposures_db < recent_stk_db:
            if not self.quiet:
                print("Updating exposures")
            num_update = self.stk_db.loc[self.stk_db.caldt >
                                         recent_exposures_db, 'caldt'].unique().shape[0]
            try:
                if num_update < 600:
                    relmin = list(
                        self.stk_db.caldt.sort_values().unique())[-600]
                else:
                    relmin = self.stk_db.caldt.min()
            except IndexError:
                raise IndexError(
                    "Input stk_db is too short. There are not enough dates in the time series.")
            rel = self.stk_db.query("caldt > '{}'".format(relmin)).copy()
            rel2 = self.fundamentals_db.query(
                "caldt > '{}'".format(relmin)).copy()
            if not self.quiet:
                print("Updating industries")
            exposures = self.industries.form_industries(rel)
            #self.indlist = list(exposures.columns)
            # self.indlist.remove('country')
            for s in self.styles:
                if not self.quiet:
                    print("Updating {}".format(s.__class__.__name__))
                if s.__class__.__name__ == 'nonlinear_beta':
                    exposures = exposures.merge(s.generate_exposures(rel, rel2, num_update, extra=exposures[[
                                                'mktbeta', 'caldt', 'permno']]), on=['permno', 'caldt'], how='outer')
                elif s.__class__.__name__ == 'nonlinear_size':
                    exposures = exposures.merge(s.generate_exposures(rel, rel2, num_update, extra=exposures[[
                                                'size', 'caldt', 'permno']]), on=['permno', 'caldt'], how='outer')
                elif s.__class__.__name__ == 'residual_volatility':
                    mbrdb = pd.concat([self.exposures_db.query("caldt > '{}'".format(relmin)).copy()[
                                      ['mktbetaresid', 'caldt', 'permno']], exposures.loc[exposures.caldt > recent_exposures_db].copy()[['mktbetaresid', 'caldt', 'permno']]])
                    exposures = exposures.merge(s.generate_exposures(
                        rel, rel2, num_update, extra=mbrdb), on=['permno', 'caldt'], how='outer')
                    #exposures = exposures.merge(s.generate_exposures(rel,rel2,num_update,extra=exposures[['mktbetaresid','caldt','permno']]),on=['permno','caldt'],how='outer')
                else:
                    exposures = exposures.merge(s.generate_exposures(
                        rel, rel2, num_update), on=['permno', 'caldt'], how='outer')
            #debuga = exposures.loc[exposures.caldt > recent_exposures_db]
            #debugb = self.exposures_db
            self.exposures_db = pd.concat(
                [self.exposures_db, exposures.loc[exposures.caldt > recent_exposures_db]])
            #debugc = self.exposures_db.query("caldt == '{}'".format(recent_stk_db))
            #debugbla = 2
            #self.exposures_db = self.exposures_db.merge(exposures.loc[exposures.caldt > recent_exposures_db],how='outer',on=['permno','caldt'])

    def _update_factors(self):
        recent_stk_db = self.stk_db.caldt.max()
        recent_factor_returns_db = self.factor_returns_db.caldt.max()
        if recent_factor_returns_db < recent_stk_db:
            # if not self.quiet:
            #    print("Updating factor returns database object")
            num_update = self.stk_db.loc[self.stk_db.caldt >
                                         recent_factor_returns_db, 'caldt'].unique().shape[0]
            self.gen_factors()
            #debugd = self.factor_returns_db
            #debuge = self.factor_returns
            #self.factor_returns_db = pd.concat([self.factor_returns_db,self.factor_returns.loc[self.factor_returns.index > recent_factor_returns_db]])
            #self.factor_returns_db.caldt = self.factor_returns_db.index
            #debugf = self.factor_returns_db
            self.factor_returns_db = self.factor_returns.reset_index()
        else:
            self.factor_returns = self.factor_returns_db
            self.factor_returns.index = self.factor_returns.caldt
            self.factor_returns = self.factor_returns.drop('caldt', axis=1)

    def gen_factors(self):
        if not self.quiet:
            print("Generating factor returns")
        df = self.estu_exposures_db.merge(
            self.estu_stk_db[['mcap', 'permno', 'caldt', 'ret']], on=['permno', 'caldt'])
        # print(df)
        # print(df.columns)
        self.factor_returns = df.groupby('caldt').apply(
            self._constrained_ols, self.xvarlist, self.indlist).unstack()
        self.factor_returns.columns = self.factor_returns.columns.droplevel()
        self.factor_returns = self.factor_returns.drop('lambda', axis=1)
        self.factor_returns_db = self.factor_returns
        return self.factor_returns

    def predict_specific_vol(self):
        if not self.quiet:
            print("Predicting specific volatility")
        # generate factor returns if they have not already been generated
        if not hasattr(self, 'factor_returns'):
            self.gen_factors()
        df = self.estu_exposures_db.merge(
            self.estu_stk_db, on=['permno', 'caldt'])
        # make sure that at this stage there are no ad hoc securities in the mix.
        # those need to be added in later in the structural model (SV based on exposures)
        if self.adhoc != None:
            df = df.query("permno not in {}".format(self.adhoc))
        df = df.merge(self.factor_returns, on=[
                      'caldt'], suffixes=('_exposure', '_return'))
        df['u'] = df.ret.copy()
        for xvar in self.xvarlist:
            df.u = df.u - \
                df['{}_exposure'.format(xvar)] * df['{}_return'.format(xvar)]
        for l in ['S', 'L']:
            ###########################################
            #       Assign half-life
            ###########################################
            if l == 'S':
                svhl = 84  # specific volatility half-life
            elif l == 'L':
                svhl = 252  # factor volatility half-life
            sv = df.groupby('permno').apply(self._specific_vol_a, svhl)
            sv = self._specific_structural(sv)
            self.SV[l] = pd.DataFrame(
                np.diag(sv.sv), columns=sv.index, index=sv.index)

        # THIS SHOULD BE CHANGED -- CURRENT HACK SOLUTION
        # note: this is a nice fix for something that might be off, but
        # this really only works on things that aren't even in the estimation universe usually,
        # but it's a good catch for things that might be funky (replaces with cross-sectional average)
        for horizon in ['S', 'L']:
            myidx = self.SV[horizon].index
            dc = self.SV[horizon].to_numpy().diagonal().copy()
            x = dc[~np.isnan(dc)]
            x = x[~np.isinf(x)]
            fillval = np.median(x)
            dc = pd.Series(dc, index=myidx)
            dc.loc[np.isinf(dc)] = np.nan
            dc.loc[dc > 1] = np.nan
            dc.loc[np.isnan(dc)] = fillval
            rc = pd.DataFrame(np.diag(dc.to_numpy()),
                              index=myidx, columns=myidx)
            self.SV[horizon] = rc
        # END HACK SOLUTION

        return self.SV

    @staticmethod
    def remove_collinear(data, correlation_threshold=0.9):
        col_corr = set()
        corr_matrix = data.corr()
        for i in range(len(corr_matrix.columns)):
            for j in range(i):
                if (corr_matrix.iloc[i, j] >= correlation_threshold) and (corr_matrix.columns[j] not in col_corr):
                    colname = corr_matrix.columns[i]
                    col_corr.add(colname)
                    if colname in data.columns:
                        del data[colname]
        return data

    def _specific_structural(self, sv):
        if not self.quiet:
            print("Specific volatility structural model")
        sv = pd.DataFrame(sv)
        sv.columns = ['sv']
        # if there are ad hoc securities, add them in as nan to the SV vector to
        # be filled in by the structural model. We added the ad hoc securities
        # to the most recent date of the estimation universe exposures database.
        # we add them in here as nan, then they have SV estimated via the
        # structural model
        if self.adhoc != None:
            for permno in self.adhoc:
                sv.loc[permno] = np.nan
        recent = self.estu_exposures_db.caldt.max()
        svts = sv.query("sv == sv").copy()
        svts['logsv'] = np.log(svts.sv.astype(float))
        svts = svts.sort_values(by='permno')
        svts['permno'] = svts.index
        tss = svts.permno.unique()  # time-series securities
        X_ = self.estu_exposures_db.query("(caldt == '{0}') & (permno in {1})".format(
            recent, list(tss))).sort_values(by=['caldt', 'permno'])[list(self.xvarlist)+['permno']]
        #X_ = self.remove_collinear(X_)
        X_ = X_.drop('country', axis=1)  # remove collinearity
        usablepermno = list(X_.permno.unique())
        X_.index = X_.permno
        X_ = X_.drop('permno', axis=1)
        # for c in X_.columns: ##HACK SOLUTION!
        #    if X_[c].values.sum() == 0:
        #        print(c, 'summed to zero, somethings is wrong!')
        #        time.sleep(2)
        #X_[c] = 1e-7 * np.random.random(len(X_))
        X = X_.to_numpy()
        b = np.matmul(np.linalg.inv(np.matmul(X.T, X)), np.matmul(
            X.T, svts.query("permno in {}".format(usablepermno))['logsv'].to_numpy()))
        sv['permno'] = sv.index
        strs = set(sv.permno.unique()).difference(
            set(svts.permno.unique()))  # structural securities
        X2_ = self.estu_exposures_db.query("(caldt == '{0}') & (permno in {1})".format(
            recent, list(strs))).sort_values(by=['caldt', 'permno'])[list(self.xvarlist)+['permno']]
        usablepermno2 = list(X2_.permno.unique())
        X2_.index = X2_.permno
        X2_ = X2_.drop('permno', axis=1)
        # removal of collinearity and maintaining matrix dimensions for multiplications
        X2_ = X2_.drop('country', axis=1)
        X2 = X2_.to_numpy()
        sigmastr = np.exp(np.matmul(X2, b))
        sigmastr = pd.DataFrame(
            sigmastr, columns=['sv'], index=pd.Series(usablepermno2).sort_values())
        sv = sv.fillna(sigmastr)
        return sv

    @staticmethod
    def _lags_by_halflife(hl, d_param=1e-5):
        # hl: half-life parameter tau; d_papram = convergence cut-off
        # return the efficient number of lags
        w = - (hl * np.log(d_param)) / np.log(2)
        return math.ceil(w)

    def _specific_vol_a(self, g, hl):
        #n = self._lags_by_halflife(hl)
        n = 252 * 2  # use 2 years of data rather than efficient lag since efficient lag is too long for data purposes
        w = self._exponential_weights(n, hl)
        g = g.sort_values(by='caldt').reset_index(drop=True)
        grel = g.iloc[-n:, :]
        ubar = grel.u.mean()
        grel['u2'] = grel.u - ubar
        grel['u2'] = np.power(grel.u2, 2.0)
        if w.shape[0] > grel.shape[0]:
            sigma = np.nan
        else:
            sigma = np.matmul(w.to_numpy().T, np.reshape(
                grel.u2.to_numpy(), (n, 1)))[0, 0]
        return sigma

    @staticmethod
    def _exponential_weights(n, tau):
        # old to recent
        lamb = np.power(0.5, 1./tau)
        df = pd.DataFrame(np.nan, index=np.arange(n), columns=['w'])
        df['T-t'] = n-pd.Series(df.index.to_list())
        df['w'] = np.power(lamb, df['T-t'])
        df['w'] = df['w'] / df.w.sum()
        return df[['w']]

    def predict_VCV(self):
        if not self.quiet:
            print("Predicting factor covariance matrix")
        # generate factor returns if they have not already been generated
        if not hasattr(self, 'factor_returns'):
            self.gen_factors()

        for l in ['S', 'L']:
            ###########################################
            #       Assign half-lives and lags
            ###########################################
            if l == 'S':
                fvhl = 84  # factor volatility half-life
                nwvl = 5   # newey-west volatility lags
                fchl = 504  # factor correlation half-life
                nwcl = 2   # newey-west correlation lags
            elif l == 'L':
                fvhl = 252  # factor volatility half-life
                nwvl = 5   # newey-west volatility lags
                fchl = 504  # factor correlation half-life
                nwcl = 2   # newey-west correlation lags

            corrcov = self._cov_matrix(self.factor_returns, fchl, nwcl)
            volcov = self._cov_matrix(self.factor_returns, fvhl, nwvl)
            k = len(self.factor_returns.columns)
            retval = np.zeros((k, k))
            for i in range(k):
                for j in range(k):
                    retval[i, j] = corrcov[i, j] / (np.sqrt(corrcov[i, i]) * np.sqrt(
                        corrcov[j, j])) * np.sqrt(volcov[i, i]) * np.sqrt(volcov[j, j])
            self.VCV[l] = pd.DataFrame(
                retval, index=self.factor_returns.columns, columns=self.factor_returns.columns)
        return self.VCV

    def _calculate_expected_returns(self):
        if ('S' not in self.SV.keys()) or ('L' not in self.SV.keys()):
            self.predict_specific_vol()
        factor_returns_ = self._EWMA_factor_return_prediction()
        factor_returns = factor_returns_.to_numpy()
        maxdate = self.estu_exposures_db.caldt.max()
        permnoexisting = self.SV['S'].sort_index().index
        permnoexisting = self.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(
            list(permnoexisting), maxdate)).sort_values(by='permno').permno
        expos_ = self.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(
            list(permnoexisting), maxdate)).sort_values(by='permno')[list(self.xvarlist)]
        expos = np.array(expos_)
        self.expected_returns['daily'] = pd.DataFrame(np.matmul(
            factor_returns, expos.T).T, index=permnoexisting, columns=['er'])['er']
        self.expected_returns['annual'] = (
            self.expected_returns['daily']) * 252.
        return self.expected_returns

    def _EWMA_factor_return_prediction(self):
        window = 30  # was 500
        w_ = self._exponential_weights(window, 8).T  # was window,30
        w = np.array(w_)
        factor_selection = self.factor_returns_db.iloc[:window]
        factors = factor_selection[self.xvarlist]
        factors = np.array(factors)
        predicted_factor_returns = np.matmul(w, factors)
        # np.array (vector) indexed by xvarlist - predicted next period daily returns
        return pd.DataFrame(predicted_factor_returns.T, index=self.xvarlist, columns=['fr'])['fr']

    def _benchmark_betas_alphas(self, horizon=None, exante=None):
        if horizon is None:
            print("Investment horizon not defined, using 'S' by default.")
            horizon = 'S'
        if exante is None:
            raise ValueError(
                "Ex-ante vs Realized? Specify with exante=True or exante=False (for realized)")
        permnoexisting = self.SV['S'].sort_index().index
        recent = self.estu_exposures_db.caldt.max()
        b_permnos = self.benchmark_db[self.benchmark_db.permno.isin(
            list(permnoexisting))].sort_values(by='permno').permno
        expos_ = self.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(
            list(b_permnos), recent)).sort_values(by='permno')[list(self.xvarlist)]
        expos = expos_.to_numpy()
        final_permnos = self.estu_exposures_db.query("(permno in {0}) & (caldt=='{1}')".format(
            list(b_permnos), recent)).sort_values(by='permno').permno
        bw_ = self.benchmark_db[self.benchmark_db.permno.isin(
            list(final_permnos))].sort_values(by='permno').weight
        bw = bw_.to_numpy()
        er_ = self.expected_returns['daily'].loc[final_permnos]
        er = er_.to_numpy()
        V = self._stock_level_VCV(expos, final_permnos)[horizon]
        betas = V @ bw / (bw.T @ V @ bw)
        fr_predicted_ = self._EWMA_factor_return_prediction()
        fr_predicted = fr_predicted_.to_numpy()
        alphas = er - betas * np.matmul(np.matmul(bw.T, expos), fr_predicted)
        alphas = pd.Series(alphas, index=final_permnos)
        betas = pd.Series(betas, index=final_permnos)
        self.benchmark_betas = betas
        self.benchmark_alphas = alphas
        return self.benchmark_betas, self.benchmark_alphas

    def _stock_level_VCV(self, expos, permnos):
        self.V = {}
        for h in ['S', 'L']:
            VCV_ = self.VCV[h]
            VCV = VCV_.to_numpy()
            SV_ = self.SV[h].loc[list(permnos), list(permnos)]
            SV = SV_.to_numpy()
            V = expos @ VCV @ expos.T + SV
            V = pd.DataFrame(V, index=permnos, columns=permnos)
            self.V[h] = V
        return self.V

    def loose_data(self):
        self.stk_db = self.stk_db[self.stk_db['caldt'] >= '2020-09-28']
        self.estu_fundamentals_db = self.estu_fundamentals_db[
            self.estu_fundamentals_db['caldt'] >= '2020-09-28']
        self.estu_exposures_db = self.estu_exposures_db[self.estu_exposures_db['caldt'] >= '2020-09-28']

        del self.estu_stk_db
        del self.exposures_db
        del self.fundamentals_db

        print("DROPPED DATA FOR SAM")
        return None

    def port_opt(self, er_active, active_risk=0.04, dist=None, horizon='S', er_horizon=252, benchmark_student='russell_3000', return_benchmark=.108):
        permnoexisting = self.SV[horizon].sort_index().index
        brecent = self.benchmark_db.caldt.max()
        Xrecent = self.estu_exposures_db.caldt.max()
        stkrecent = self.stk_db.caldt.max()
        # pull benchmark weights and permnos of most recent date
        bm_permnos = self.benchmark_db.query("(permno in {0}) & (caldt=='{1}'& (benchmark == '{2}'))".format(
            list(permnoexisting), brecent, benchmark_student)).sort_values(by='permno').permno
        bm_weights = self.benchmark_db.query("(permno in {0}) & (caldt=='{1}'& (benchmark == '{2}'))".format(
            list(permnoexisting), brecent, benchmark_student)).sort_values(by='permno').set_index('permno').weight
        rf = self.stk_db.query("(caldt=='{0}')".format(stkrecent)).rf.max()
        expos_ = self.estu_exposures_db.query("(permno in {0}) & (caldt == '{1}')".format(
            list(bm_permnos), Xrecent)).set_index('permno').sort_index()[self.xvarlist]
        missing = list(set(bm_permnos) ^ set(expos_.index))

        bm_permnos = self.benchmark_db.query("(permno in {0}) & (caldt=='{1}'& (benchmark == '{2}'))".format(
            list(expos_.index), brecent, benchmark_student)).sort_values(by='permno').permno
        bm_weights = self.benchmark_db.query("(permno in {0}) & (caldt=='{1}'& (benchmark == '{2}'))".format(
            list(expos_.index), brecent, benchmark_student)).sort_values(by='permno').set_index('permno').weight
        # --- Get Ordering of Stocks ---
        active_permno = er_active.index
        for stk in list(active_permno):
            if stk not in list(bm_permnos):
                raise ValueError('{0} is not in benchmark_db'.format(stk))
        passive_permno = [
            item for item in bm_permnos if item not in active_permno]
        active = bm_weights.index.get_indexer(active_permno)
        passive = bm_weights.index.get_indexer(passive_permno)
        order = list(active) + list(passive)
        ordered_bm_w = np.array([bm_weights.iloc[i]for i in order])
        ordered_bm_permnos = np.array([bm_permnos.iloc[i] for i in order])
        b = ordered_bm_w/ordered_bm_w.sum()

        # Generating alpha to the benchmark
        er = pd.Series(np.nan, index=bm_permnos).sort_index()
        for idx, val in er.iteritems():
            if idx in active_permno:
                er[idx] = er_active[idx]
            else:
                er[idx] = 0
        er = np.array([er.iloc[i] for i in order])
        # ----Construction of V_{t+1} covariance matrix for benchmark ----

        expos = pd.DataFrame(data=[expos_.iloc[i]
                                   for i in order], index=list(ordered_bm_permnos))
        expos_np = expos.to_numpy()

        SV_ = self.SV[horizon].to_numpy()
        diag = np.diag(SV_)
        SV_benchmark_vector = pd.Series(
            diag, index=permnoexisting).loc[expos.index]
        SV_reorder = [SV_benchmark_vector.iloc[i] for i in order]
        SV_matrix = np.diagflat(SV_reorder)
        factor = (self.VCV[horizon]).to_numpy()

        V_ = expos_np @ (factor @ expos_np.T) + SV_matrix
        V = V_ * 252

        if dist is None:
            V = V
        else:
            zeros = np.zeros((len(SV_matrix)-len(active_permno)))
            var_class = np.power(np.append(dist, zeros), 2)
            gamma0 = np.diag(var_class)
            V = V + gamma0

        beta2bench = V @ b.T / (b @ V @ b.T)
        alpha = er - rf - beta2bench * (return_benchmark - rf)
        #   --- force alpha to be zero for all passive stocks ---
        n = len(bm_permnos)
        a = len(active_permno)
        for i in range(a, n):
            alpha[i] = 0.
            # --- Benchmark Components ---
        sigma = V
        bench_alpha = alpha @ b.T
        bench_var = b @ sigma @ b.T
        bench_cov = sigma @ b.T
        beta2bench = sigma @ b.T / (b @ sigma @ b.T)

        # -- augmented variables ----
        alpha_a = np.append(alpha[0:a], bench_alpha)
        intermediate_sigma = np.concatenate(
            (sigma[0:a, 0:a], bench_cov[0:a, None]), axis=1)
        final_col = np.append(bench_cov[0:a], bench_var)
        sigma_a = np.concatenate(
            (intermediate_sigma, final_col[:, None].T), axis=0)
        beta_a = np.append(beta2bench[0:a], 1)

        h = cp.Variable(a+1)
        gamma = 2
        risk = cp.quad_form(h, sigma_a)
        utility = alpha_a @ h - 0.5 * gamma * risk

        prob = cp.Problem(objective=cp.Maximize(utility),
                          constraints=[cp.sum(h) == 0,
                                       h @ beta_a == 0])
        prob.solve()
        # ---Getting values for panes ---
        betas = sigma_a[-1:, :]/sigma_a[a, a]
        betas = betas[0]
        h = h.value
        h_rescaled = h * (active_risk / np.sqrt(h.transpose() @ sigma_a @ h))
        w = h_rescaled
        w_star = w[:a]
        bench_amt = 1 + h_rescaled[-1]
        w_all = np.append(w_star, bench_amt)

        # --- extract model attributes ---
        pos = self.positions_db
        active_str = active_permno.astype(str)
        self._calculate_expected_returns()
        er_barra = self.expected_returns['annual'].loc[list(active_permno)]

        current_bm_weight = pos[pos['asset_id'] ==
                                'russell3000_bretf'].weights.to_numpy()
        er_i = np.append(np.array(er_active), return_benchmark)
        Er_p = er_i @ w_all
        IR = alpha_a @ h - 0.5 * gamma * (h @ sigma_a @ h.T)
        port_beta = w_all @ betas
        port_alpha = Er_p - rf - port_beta * (return_benchmark - rf)
        active = pd.DataFrame(index=active_permno)
        active['model_er'] = er_barra

        active['optimal_active_weight'] = w_star
        active['beta_to_bench'] = betas[:a]
        active['alpha'] = alpha[:a]
        active['weight_in_bench'] = ordered_bm_w[:a]

        w = []
        #active['backlog'] = current_weight - active['opt_weights']
        for x in list(active_str):
            if x in list(pos.asset_id):
                current_w = pos[pos['asset_id'] == x].weights
                w = np.append(w, current_w)
            else:
                w = np.append(w, [0])

        active['current_weight'] = w
        active['backlog'] = active['optimal_active_weight'] - \
            active['current_weight']

        bench = pd.DataFrame(index=['benchmark'])
        bench['model_er'] = return_benchmark
        bench['annualized_er'] = return_benchmark
        bench['beta_to_bench'] = 1.0
        bench['alpha'] = 0.
        bench['optimal_active_weight'] = bench_amt
        bench['weight_in_bench'] = np.nan
        bench['current_weight'] = current_bm_weight
        bench['backlog'] = bench['optimal_active_weight'] - \
            bench['current_weight']

        summary = bench.append(active)

        # --- Calculate Backlog Risk ---

        port_w = summary['backlog'].to_numpy()
        backlog_risk = np.sqrt(port_w.T @ sigma_a @ port_w)
        mcr = sigma_a @ port_w / backlog_risk
        tcr = (port_w * mcr)
        summary['backlog_risk'] = tcr
        tcr_port = tcr.sum()

        stats = pd.Series(data=[Er_p, port_beta, port_alpha, IR, tcr_port],  index=[
                          'Er_p', 'beta_to_bench', 'alpha_to_bench', 'IR', 'backlog_risk_total'])
        # --- Verify Constraints ---
        # if w_all.sum() != 1.0:
        #     raise ValueError('Weights do not sum to 1.0')
        # if (w_all @ betas.T) != 1.0:
        #     raise ValueError('Beta of portfolio to the benchmark is not 1.0')
        # if (h_rescaled.sum()) >= 1e-10:
        #     raise ValueError('Active weights do not sum to zero.')

        return summary, stats

    def _expected_return_translator(self, expected_returns, horizon, benchmark):
        # TODO:
        # translate expected returns to alpha given a benchmark
        er = expected_returns.sort_index()
        permnoheld = expected_returns.index
        recent = self.estu_exposures_db.caldt.max()
        rf = self.stk_db.query("(permno in {0}) & (caldt=='{1}')".format(
            list(permnoheld), recent)).sort_values(by='permno').set_index('permno').rf
        betas = self.benchmark_betas[horizon][benchmark].loc[permnoheld]
        er_barra = self.expected_returns['daily'].loc[permnoheld]
        # no risk free subtraction in this alpha to the benchmark? Check with Brandon
        active_alpha = er - rf - betas * (er_barra - rf)
        return active_alpha

    @staticmethod
    def _constrained_ols(g, xvarlist, indlist):
        totmcap = g.mcap.sum()
        capwtind = []
        for ind in indlist:
            capwtind.append((g[ind]*g.mcap).sum()/totmcap)
        g['mcapsv'] = np.sqrt(g.mcap)
        # ensure no NAN are produced in square root procedure
        g = g.query("mcapsv == mcapsv")
        mcaps = np.diag(g.mcapsv)
        myx_ = g[xvarlist]
        for c in myx_.columns:  # HACK SOLUTION!
            if myx_[c].values.sum() == 0:
                print(c, 'summed to zero, somethings is wrong!')
                time.sleep(2)
                #myx_[c] = 1e-7 * np.random.random(len(myx_))
        myx = np.array(myx_, dtype=float)
        myy = np.matmul(np.matmul(myx.T, mcaps), np.array(g.ret, dtype=float))
        myxx = np.matmul(np.matmul(myx.T, mcaps), myx)
        stylenum = len(xvarlist) - len(indlist) - 1
        cols = np.concatenate(
            (myxx, np.array([[0]+capwtind+[0]*stylenum], dtype=float)), axis=0)
        cols = np.hstack([cols, np.array([[0]+capwtind+[0]*(stylenum+1)]).T])
        yy = np.concatenate((myy, [[0]]), axis=None)
        b = np.linalg.solve(cols, yy)
        b = pd.DataFrame(b, index=xvarlist+['lambda'], columns=['Factor'])
        #assert (b.loc[indlist,'Factor']*capwtind).sum() < 1.0e-12
        return b

    def _cov_matrix(self, factors, hl, lag):
        # factors is pandas dataframe with factors as columns and rows as time periods
        # hl is half-life
        # lag is number of newey-west lags
        factorcols = factors.columns
        k = len(factorcols)
        factors = factors.reset_index(drop=True)
        zbar = factors.mean().to_numpy()
        lamb = np.power(0.5, 1./hl)
        T = factors.shape[0]
        factors['T-t'] = T-pd.Series(factors.index.to_list())
        factors['w'] = np.power(lamb, factors['T-t'])
        factors['w'] = factors['w'] / factors.w.sum()
        factorsnp = factors[factorcols].to_numpy()
        gamma0 = np.zeros((k, k))
        for t in range(T):
            gamma0 = np.add(gamma0, self._element1(
                t, 0, factorsnp, zbar, factors.loc[t, 'w']))
        gammas = {}
        for v in range(lag):
            gammas[v] = np.zeros((k, k))
            for t in range(v, T):
                gammas[v] = np.add(gammas[v], self._element1(
                    t, v+1, factorsnp, zbar, factors.loc[t, 'w']))
        S = gamma0
        for v in range(lag):
            S = np.add(S, (1-(v+1)/(lag+1))*np.add(gammas[v], gammas[v].T))
        return S

    @staticmethod
    def _element1(t, v, factors, zbar, w):
        k = len(zbar)
        return w * np.matmul(np.reshape((factors[t, :] - zbar), (k, 1)), np.reshape((factors[t-v, :] - zbar), (1, k)))

    def _realized_held_portfolio(self, current_portfolio):
        # TODO: take the performance_db, and use the existing data to calculate the following:
        #   - realized active (for each benchmark) and total risk
        #   - realized portfolio attribution
        #   - realized beta to benchmarks (time series rather than ex-ante VCV predictions probably)
        # and update the performance_db
        cols = [benchmark+'_realized_beta' for benchmark in self.available_benchmarks]+['realized_active_daily_volatility_'+benchmark for benchmark in self.available_benchmarks] +\
            ['realized_active_annual_volatility_'+benchmark for benchmark in self.available_benchmarks]+['realized_total_daily_volatility', 'realized_total_annual_volatility'] +\
            [x+'_realized_attribution' for x in self.xvarlist]
        return pd.Series(np.random.random(len(cols)), index=cols)

    def _realized_security_risk(self, current_portfolio):
        # TODO: take the security_risk_db, and use existing data from stk_db to calculate the following:
        #    - realized total risk
        # and return (only for securities held last period) so CS team can update security_risk_db to match ex ante with realized
        permnos_held = current_portfolio.index.unique()
        cols = ['realized_total_daily_volatility',
                'realized_total_annual_volatility']
        return pd.DataFrame(np.random.random((len(permnos_held), len(cols))), columns=cols, index=list(permnos_held))


##################################
#       Notes on CS Team Work
##################################

# CS team should run nightly to update performance_db, exposures_db, security_risk_db, and a two over-written tables:
#           (1) with ex-ante betas, alphas, expected returns for every security in the estimation universe
#           (2) with optimal weights for optimized portfolios with respect to risk-free rate and to each benchmark
#   - run an analyze_portfolio call on the current portfolio to update the performance_db with ex-ante information on the held portfolio
#   - run a _realized_held_portfolio call on the current portfolio to update the performance_db with realized information
#   - query ex-ante beta and alpha information from the self.benchmark_alphas and self.benchmark_betas objects for all stocks (portfolio construction pane - don't need to store historical)
#           (need to run _calculate_benchmark_betas_alphas() if you haven't done an analyze_portfolio call prior to querying)
#   - also query ex-ante beta information from self.benchmark_betas object to store historical in security_risk_db for held securities
#   - query the self.factor_returns object to update the factor_returns_db -- we don't update that. We keep them separate -- the factor_returns_db is historical, factor_returns is calculated this period
#   - query expected return infomration from self.expected_returns for all stocks (portfolio construction pane - don't need to store historical)
#           (need to run _calculate_expected_returns() prior)
#   - run portfolio optimization for the risk-free rate as the benchmark and with each benchmark to get the max IR and max Sharpe optimal weights (don't need to store historical)
#   - run _realized_security_risk on the current portfolio to update the security_risk_db with realized risks for each currently held security
# CS team should be able to call from those maintained databases to fill all data on the panes
# CS team should be able to make on-the-fly calls to analyze_portfolio or portfolio_optimization to complete all user-specified calculations
