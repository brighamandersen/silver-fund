 # coding=utf-8
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from time import sleep
import os
import json
import mysql.connector
from datetime import date
from datetime import datetime

import requests
import json
from sqlalchemy import create_engine
import pandas as pd

PAPER_USERNAME = "shusv1875"
PAPER_PASSWORD = "Shr990214"
ACCOUNT_ID = "U4297056"

capabilities = DesiredCapabilities.CHROME
capabilities["loggingPrefs"] = {
    "performance": "ALL",
}

# Settings to get past Chrome local host privacy
options = webdriver.ChromeOptions()
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--headless")
options.add_argument("--ignore-ssl-errors=yes")
options.add_argument("--ignore-certificate-errors")

# Set path to driver
chromedriver = "/usr/bin/chromedriver"

# get today's date
today = str(date.today())

def selenium_auth(username, pwd):
    driver = webdriver.Chrome(
        chromedriver, desired_capabilities=capabilities, options=options
    )

    # Go to login page
    driver.get("https://localhost:5000")

    # Type in username and password
    username_textbox = driver.find_element_by_id("user_name")
    username_textbox.send_keys(username)
    password_textbox = driver.find_element_by_id("password")
    password_textbox.send_keys(pwd)

    # Click login button / submit
    login_button = driver.find_element_by_id("submitForm")
    login_button.submit()

    sleep(4)
    driver.refresh()
    # print(driver.page_source)
    driver.close()


def refresh_auth():
    driver = webdriver.Chrome(
        chromedriver, desired_capabilities=capabilities, options=options
    )

    driver.get("https://localhost:5000/v1/portal/tickle")
    sleep(4)
    driver.refresh()
    # print(driver.page_source)
    driver.close()


def validate_sso():
    driver = webdriver.Chrome(
        chromedriver, desired_capabilities=capabilities, options=options
    )

    driver.get("https://localhost:5000/v1/portal/sso/validate")
    sleep(4)
    driver.refresh()
    # print(driver.page_source)
    driver.close()


def get_accounts():
    driver = webdriver.Chrome(
        chromedriver, desired_capabilities=capabilities, options=options
    ) 
    driver.get("https://localhost:5000/v1/portal/portfolio/accounts")
    # print(driver.page_source)
    driver.close()


def get_account_info(info_type):
    driver = webdriver.Chrome(
        chromedriver, desired_capabilities=capabilities, options=options
    ) 

    if info_type == "position":
        driver.get(
            "https://localhost:5000/v1/portal/portfolio/" + ACCOUNT_ID + "/positions/0"
        )

    elif info_type == "cash":
        driver.get(
            "https://localhost:5000/v1/portal/portfolio/" + ACCOUNT_ID + "/ledger"
        )

    elif info_type == "trade":
        driver.get("https://localhost:5000/v1/portal/iserver/account/trades")

    sleep(4)
    pre = driver.find_element_by_tag_name("pre").text
    data = json.loads(pre)
    driver.close()
    return data


def insert_into_db(tbname, data):
    db = mysql.connector.connect(
        host="sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com",
        database="sfdb",
        port=3306,
        user="sf_master_db ",
        password="this_is_testing",
    )

    if tbname == "api_position":
        mycursor = db.cursor()
        sql = (
            "INSERT INTO sandbox_db."
            + tbname
            + "(asset_id, ticker, num_of_shares, asset_type, price, position_value, date) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        )
        mycursor.executemany(sql, data)
        db.commit()
        print(mycursor.rowcount, "was inserted.")

    if tbname == "all_6_days_api_trade":
        mycursor = db.cursor()
        sql = "DROP TABLE IF EXISTS api_trade"
        mycursor.execute(sql)
        db.commit()
        print("table is deleted")
        sql2 = "CREATE TABLE api_trade (id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, trade_id varchar(40) DEFAULT NULL, asset_id varchar(40) DEFAULT NULL, trade_type varchar(40) DEFAULT NULL, num_of_shares int(11) DEFAULT NULL,price double DEFAULT NULL,tot_price double DEFAULT NULL,trade_time varchar(40) DEFAULT NULL,trade_status varchar(40) DEFAULT NULL)"
        mycursor.execute(sql2)
        db.commit()
        print("table is created")
        sql3 = "INSERT INTO api_trade (trade_id, asset_id, trade_type, num_of_shares, price, tot_price, trade_status, trade_time) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
        mycursor.executemany(sql3, data)
        db.commit()
        print(mycursor.rowcount, "trade records were inserted.")

    if tbname == "new_api_trade":
        mycursor = db.cursor()
        sql3 = "INSERT INTO sandbox_db.api_trade (trade_id, asset_id, trade_type, num_of_shares, price, tot_price, trade_status, trade_time) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
        mycursor.executemany(sql3, data)
        db.commit()
        print(mycursor.rowcount, "trade records were inserted.")


# Grabs market data for one security and formats it as a row in the market data table
#FIXME need to grab data from yahoo finance
# def get_today_market_data(conid, asset_id, siccd):
#     constrains = {'conid': conid, 'period': '1w', 'bar': '1d'}
#     resp = requests.get("https://localhost:5000/v1/portal/iserver/marketdata/history",  params = constrains, verify = False)  
    
#     data = resp.json()
#     if('error' in data):
#         data = {'o': 'error', 'c': 'error', 'h': 'error', 'l': 'error'}
#     elif not data['data']:
#         data = {'o': 'empty', 'c': 'empty', 'h': 'empty', 'l': 'empty'}
#     else:
#         data = data['data'][-1]
    
#     #FIXME we need to do a 90 avg for volume and number of shares outstanding from CRSP data
#     new_row = {'asset_id': asset_id, 'date': str(date.today()), 'PRC': data['c'], 'volume': data['v'],'siccd': siccd}
    
#     return new_row


def find_asset_id(ticker_name, conid):

    db = mysql.connector.connect(
        host="sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com",
        database="sfdb",
        port=3306,
        user="sf_master_db ",
        password="this_is_testing",
    )
    mycursor = db.cursor()
    sql = (
            "Select asset_id from sandbox_db.api_equity_security_master"
            + " where ticker = '" + str(ticker_name) + "' and conid = '" + str(conid) + "';"
        )
    print(sql)
    mycursor.execute(sql)
    row = mycursor.fetchone()
    asset_id = row[0]
    return asset_id




selenium_auth(PAPER_USERNAME, PAPER_PASSWORD)        
validate_sso()
refresh_auth()
get_accounts()

# data list for api_position
position_data = get_account_info("position")
all_positions = []
for position in position_data:
    if position["contractDesc"] == "IWV":
        asset_id = "russell3000_bretf"
    else:
        asset_id = find_asset_id(position["contractDesc"], position["conid"])

    new_position = (
        asset_id,
        position["contractDesc"],
        position["position"],
        position["assetClass"],
        position["avgPrice"],
        position["mktValue"],
        today,
    )
    all_positions.append(new_position)

# Insert Cash Info
cash = get_account_info("cash")
base_cash = cash["BASE"]
new_cash = ("cash", "CASH", "1", "cash", "1", base_cash["cashbalance"], today)
all_positions.append(new_cash)

# insert data into api_position
insert_into_db("api_position", all_positions)

# data list for api_trade
trades = get_account_info("trade")
formatted_trades = []

for trade in trades:
    # only add today's data
    valid_time = datetime.strptime(trade["trade_time"], "%Y%m%d-%H:%M:%S")
    validate_date = valid_time.strftime("%Y-%m-%d")

    if validate_date == today:
        # convert time from 20200818-07:07:55 to 2020-08-18@07:07:55
        convert_time = datetime.strptime(trade["trade_time"], "%Y%m%d-%H:%M:%S")
        convert_time = convert_time.strftime("%Y-%m-%d@%H:%M:%S")
        print(convert_time)
        new_trade = (
            trade["execution_id"],
            trade["contract_description_1"],
            trade["sec_type"],
            trade["size"],
            trade["price"],
            trade["net_amount"],
            "complete",
            convert_time,
        )
        formatted_trades.append(new_trade)

# insert data into api_trade
if formatted_trades:
    insert_into_db("new_api_trade", formatted_trades)
