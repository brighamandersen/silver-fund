import pandas as pd
import numpy as np
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from webdriver_manager.chrome import ChromeDriverManager
from datetime import date
from selenium.webdriver.support.wait import WebDriverWait
from datetime import datetime
import time
from sqlalchemy import create_engine
import mysql.connector


def clean_str(x):
    x = x.replace(",","")
    return x

options = webdriver.ChromeOptions()
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--headless")
options.add_argument("--window-size=1920x1920")
driver = webdriver.Chrome('/usr/bin/chromedriver', options=options)


#This function does all of the actual webscraping. 
def get_ETFs(url):
    options = webdriver.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--headless")
    options.add_argument("--window-size=1920x1920")
    driver = webdriver.Chrome('/usr/bin/chromedriver', options=options)
    try:
        print('getting page for ' + url)
        connection = mysql.connector.connect(host='sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com',
                        user = 'sf_master_db',
                        passwd = 'this_is_testing',
                        db = 'sandbox_db')

        df = pd.DataFrame(columns = ['ticker', 'comname', 'industry', 'marketvalue', 'weight', 'shares', 'cusip', 'isin', 'sedol'])

        #Pull up web page and grab the table
        driver.get(url)
        time.sleep(2)
        driver.find_element_by_xpath("//*[@id='allHoldingsTable_wrapper']/div[2]/div[3]/a").click()
        table =  driver.find_element_by_id('allHoldingsTable')
    
        #Iterate through each row in the table and grab needed data
        for row in table.find_elements_by_css_selector('tr'):
            df_row = {'ticker' : '', 'comname' : '', 'industry': '', 'marketvalue': 0, 'weight': 0, 'shares': 0, 'cusip': 0, 'isin': '', 'sedol': 0}
            for i, cell in enumerate(row.find_elements_by_tag_name('td')):
                if(i==0):
                    df_row["ticker"] = cell.text

                    asset_id = pd.read_sql_query("select * from api_benchmark where ticker='"+cell.text+"'", connection)
                    if not asset_id.empty:
                        df_row["asset_id"] = asset_id['asset_id'].values[0]
                    else:
                        print(df_row["ticker"])
                        df_row["asset_id"] = 0

                if(i==1):
                    df_row["comname"] = cell.text
                if(i==2):
                    df_row["industry"] = cell.text
                if(i==5):
                    df_row["weight"] = cell.text
                if(i==6):
                    df_row["marketvalue"] = cell.text
                if(i==7):
                    df_row["shares"] = cell.text
                if(i==8):
                    df_row["cusip"] = cell.text
                if(i==9):
                    df_row["isin"] = cell.text
                if(i==10):
                    df_row["sedol"] = cell.text
            df = df.append(df_row,ignore_index=True)
            
        driver.close()
        print('done gathering data')
        return df

    except NoSuchElementException:
        print("FAILED")

print("Start: " + str(datetime.now()))

df = get_ETFs('https://www.ishares.com/us/products/239714/ishares-russell-3000-etf')
#Remove asset's without ids
df = df[df['asset_id']!=0]
df['benchmark'] = 'russell_3000'
df['date'] = date.today()
df = df.query('weight != 0')

#Clean the data and reweight the weights 
df = df[['comname','ticker','marketvalue','weight','asset_id', 'date', 'benchmark']]
df = df.rename(columns = {'marketvalue':'mcap','date':'caldt'})
df['mcap'] = df['mcap'].apply(clean_str).astype(float)
df.weight = df.weight.astype(float)/100
df = df.query('asset_id != 0')
df = df[['benchmark', 'asset_id', 'weight', 'caldt', 'ticker']]

print('pushing to databse')
#This engine lets us access our RDS database
engine = create_engine("mysql+pymysql://sf_master_db:this_is_testing@sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com/sandbox_db"
                       .format(user="sf_master_db",
                               pw="this_is_testing",
                               db="sandbox_db"))
#Insert the data into the database
df.to_sql('api_benchmark', con = engine, if_exists = 'append', chunksize = 1000, index=False)
print('pushed to database successfuly')
print("END: " + str(datetime.now()))
