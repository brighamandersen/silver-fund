import React from "react";

import { SubpaneBar, Tab, activeStyle } from "../shared/NavComponents";

export const RiskSubpanes = () => (
  <SubpaneBar>
    <Tab to="/risk/snapshot" activeStyle={activeStyle}>
      Portfolio Snapshot
    </Tab>
    <Tab to="/risk/throughtime" activeStyle={activeStyle}>
      Portfolio Risk Through Time
    </Tab>
    <Tab to="/risk/whatif" activeStyle={activeStyle}>
      What-If Analysis
    </Tab>
  </SubpaneBar>
);

export default RiskSubpanes;
