import React, { useState } from "react";
import { getDateStr, getDateStr3MonthsBack } from "../../utils/helpers";
import { Content, FixMeWrapper } from "../shared/SharedStyles";
import RiskThroughTimeMenu from "./RiskThroughTimeMenu";

export const RiskThroughTime = () => {
  // eslint-disable-next-line
  const [graphVT, setGraphVT] = useState(0);
  const [riskVT, setRiskVT] = useState("total");
  const [unitType, setUnitType] = useState("portfolio");
  const [aggrType, setAggrType] = useState("");
  const [start, setStart] = useState(getDateStr3MonthsBack());
  const [end, setEnd] = useState(getDateStr(-1));

  return (
    <Content>
      <RiskThroughTimeMenu
        start={start}
        end={end}
        setStart={setStart}
        setEnd={setEnd}
        riskVT={riskVT}
        setRiskVT={setRiskVT}
        unitType={unitType}
        setUnitType={setUnitType}
        aggrType={aggrType}
        setAggrType={setAggrType}
        setGraphVT={setGraphVT}
      />
      <FixMeWrapper />
    </Content>
  );
};

export default RiskThroughTime;
