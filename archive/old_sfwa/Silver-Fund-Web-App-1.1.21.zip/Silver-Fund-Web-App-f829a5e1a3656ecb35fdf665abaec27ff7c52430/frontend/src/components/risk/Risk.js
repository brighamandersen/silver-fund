import React from "react";
import { Route, Switch, Redirect } from "react-router-dom";

import RiskSubpaneBar from "./RiskSubpanes";
import RiskSnapshot from "./RiskSnapshot";
import RiskThroughTime from "./RiskThroughTime";
import RiskWhatIf from "./RiskWhatIf";
import NotFound from "../shared/NotFound";

export const Risk = () => (
  <>
    <RiskSubpaneBar />
    <Switch>
      <Route exact path="/risk/snapshot">
        <RiskSnapshot />
      </Route>
      <Route exact path="/risk/throughtime">
        <RiskThroughTime />
      </Route>
      <Route exact path="/risk/whatif">
        <RiskWhatIf />
      </Route>
      {/* Default Active */}
      <Route exact path="/risk">
        <Redirect to="/risk/snapshot" />
      </Route>
      <Route path="*">
        <NotFound />
      </Route>
    </Switch>
  </>
);

export default Risk;
