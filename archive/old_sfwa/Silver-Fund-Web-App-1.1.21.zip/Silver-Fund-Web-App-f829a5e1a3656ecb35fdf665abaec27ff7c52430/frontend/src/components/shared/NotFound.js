import React from "react";
import { Content } from "./SharedStyles";

export const NotFound = () => (
  <Content>
    <h1>404</h1>
    <p>Page Not Found</p>
  </Content>
);

export default NotFound;
