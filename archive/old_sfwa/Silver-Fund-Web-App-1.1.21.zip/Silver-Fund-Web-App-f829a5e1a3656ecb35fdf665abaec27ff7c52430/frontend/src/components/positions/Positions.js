import React from "react";
import { Route, Switch, Redirect } from "react-router-dom";

import PositionsSubpanes from "./PositionsSubpanes";
import PositionsSnapshot from "./PositionsSnapshot";
import PositionsHistory from "./PositionsHistory";
import NotFound from "../shared/NotFound";

export const Positions = () => (
  <>
    <PositionsSubpanes />
    <Switch>
      <Route exact path="/positions/snapshot">
        <PositionsSnapshot />
      </Route>
      <Route exact path="/positions/history">
        <PositionsHistory />
      </Route>
      {/* Default Active */}
      <Route exact path="/positions">
        <Redirect to="/positions/snapshot" />
      </Route>
      <Route path="*">
        <NotFound />
      </Route>
    </Switch>
  </>
);

export default Positions;
