import "./styles.css";

import React, { useState } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import { useLocalState } from "./utils/helpers";
import PrivateRoute from "./utils/PrivateRoute";
import Header from "./components/shared/Header";
import Panes from "./components/shared/Panes";
import Login from "./components/login/Login";
import Home from "./components/home/Home";
import Positions from "./components/positions/Positions";
import Trades from "./components/trades/Trades";
import Construction from "./components/construction/Construction";
import Risk from "./components/risk/Risk";
import NotFound from "./components/shared/NotFound";
import Footer from "./components/shared/Footer";

export const App = () => {
  const [token, setToken] = useLocalState("token");
  const [username, setUsername] = useLocalState("username");
  const [password, setPassword] = useState("");

  return (
    <Router>
      <Header
        token={token}
        setToken={setToken}
        setUsername={setUsername}
        setPassword={setPassword}
      />
      <Panes token={token} />
      <Switch>
        <Route path="/login">
          <Login
            username={username}
            setUsername={setUsername}
            password={password}
            setPassword={setPassword}
            setToken={setToken}
          />
        </Route>
        <PrivateRoute exact path="/" token={token}>
          <Home username={username} />
        </PrivateRoute>
        <PrivateRoute path="/positions" token={token}>
          <Positions />
        </PrivateRoute>
        <PrivateRoute path="/trades" token={token}>
          <Trades />
        </PrivateRoute>
        <PrivateRoute path="/construction" token={token}>
          <Construction username={username} />
        </PrivateRoute>
        <PrivateRoute path="/risk" token={token}>
          <Risk />
        </PrivateRoute>
        <Route path="*">
          <NotFound />
        </Route>
      </Switch>
      <Footer />
    </Router>
  );
};

export default App;
