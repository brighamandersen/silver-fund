import React from "react";
import { Route, Redirect } from "react-router-dom";

export const PrivateRoute = (props) =>
  props.token ? (
    <Route exact={props.exact} path={props.path}>
      {props.children}
    </Route>
  ) : (
    <Redirect to="/login" />
  );

export default PrivateRoute;
