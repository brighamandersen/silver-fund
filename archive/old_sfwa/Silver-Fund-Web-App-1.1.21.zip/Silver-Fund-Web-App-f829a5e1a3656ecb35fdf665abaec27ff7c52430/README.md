# Silver-Fund-Web-App
An institutional-quality web app created for use by Silver Fund, The Marriott Business School's student-run investment fund. This app aims to support investment research, trading, risk management, and portfolio analysis.

[Production URL - 47fund.byu.edu](https://47fund.byu.edu/)

[Development URL - 47fund-dev.byu.edu](https://47fund-dev.byu.edu/)

Want to learn more about the Silver Fund?  Visit [our general webpage](https://silverfund.byu.edu/)!
