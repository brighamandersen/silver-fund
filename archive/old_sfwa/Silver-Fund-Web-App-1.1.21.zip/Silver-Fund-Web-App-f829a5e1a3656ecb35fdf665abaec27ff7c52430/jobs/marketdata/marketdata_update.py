import pandas as pd
import requests
from datetime import datetime, timedelta
import mysql.connector
import time

connection = mysql.connector.connect(host='sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com',
                                     user='sf_master_db',
                                     passwd='this_is_testing',
                                     db='sandbox_db')
assets = pd.read_sql_query(
    "select * from api_equity_security_master", connection)
assets = assets[assets['bnchmrk'] == 'Russell_3000']

API_URL = "https://www.alphavantage.co/query"
API_KEY = 'VA355PKBU1CCOU9S'

end = datetime.strftime((datetime.now() - timedelta(1)), '%Y-%m-%d')
start = datetime.strftime((datetime.now() - timedelta(3)), '%Y-%m-%d')

start_time = time.time()
time_check = time.time()
req_num = 0

df = pd.DataFrame()
for index, row in assets[:1000].iterrows():
    
    pram = {"function": "TIME_SERIES_DAILY_ADJUSTED",
            "symbol": row['ticker'],
            "outputsize": "compact",
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    req_num = req_num + 1
    response_json = response.json()

    if 'Error Message' not in response_json:
        mkdata = pd.DataFrame.from_dict(
            response_json['Time Series (Daily)'], orient='index').sort_index(axis=1)
        mkdata['caldt'] = mkdata.index
        mask = (mkdata['caldt'] > start) & (mkdata['caldt'] <= end)
        mkdata = mkdata.loc[mask]
        mkdata['ticker'] = row['ticker']
    else:
        print(row['ticker'])
        continue

    pram = {"function": "OVERVIEW",
            "symbol": row['ticker'],
            "outputsize": "compact",
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    req_num = req_num + 1
    response_json = response.json()

    if bool(response_json):
        mkdata['shr'] = response_json['SharesOutstanding']
    else:
        mkdata['shr'] = 0
        print(row['ticker'])

    mkdata = mkdata.rename(columns={'1. open': 'open', '2. high': 'high', '3. low': 'low',
                                    '4. close': 'close', '5. adjusted close': 'prc', '6. volume': 'vol'})
    mkdata['prc'] = mkdata['prc'].astype(float)
    mkdata['ret'] = mkdata['prc']/mkdata['prc'].shift(-1)

    mkdata = mkdata[mkdata['caldt'] == end]

    mkdata = mkdata[['prc', 'vol', 'ticker', 'caldt', 'shr', 'ret']]
    mkdata['asset_id'] = row['asset_id']
    mkdata['shrcd'] = 0
    mkdata['siccd'] = row['siccd']
    mkdata['rf'] = 0

    df = pd.concat([df, mkdata])
    if (time.time()-time_check > 55) and req_num > 118:
        print('sleep')
        time.sleep(5)
        time_check = time.time()
        req_num = 0
    if req_num > 120:
        req_num = 0
        time_check = time.time()

end_time = time.time()
print(end_time - start_time)
print(df)
