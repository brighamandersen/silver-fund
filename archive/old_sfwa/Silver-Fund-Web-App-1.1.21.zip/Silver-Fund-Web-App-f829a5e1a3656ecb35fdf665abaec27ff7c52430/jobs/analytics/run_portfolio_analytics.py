import pandas as pd
from byuriskmodel.model import risk_model
import numpy as np
from sqlalchemy import create_engine
import pprint

#Stock database test data (this will come from the market data table)
stk_db = pd.read_csv('dstk_small.csv')
stk_db['rf'] = 0.0002
stk_db.caldt = stk_db.caldt.astype('datetime64[D]')
stk_db.head(10)

#Fundementals test data
fdb = pd.DataFrame(np.random.random((stk_db.shape[0],3)),columns=['a','b','c'])
fdb['caldt'] = stk_db.caldt
fdb['permno'] = stk_db.permno

#Exposures test data
edb = pd.DataFrame(np.random.random((2,8)),columns=['mktbeta','mktbetaresid','size','nonlinear_size','nonlinear_beta','residual_volatility','liquidity','momentum'])
edb['caldt'] = ['1920-12-30','1920-11-20']
edb['permno'] = 10001
edb.caldt = edb.caldt.astype('datetime64[D]')

#Factor returns test data
frdb = pd.DataFrame(np.random.random((2,8)),columns=['mktbeta','mktbetaresid','size','nonlinear_size','nonlinear_beta','residual_volatility','liquidity','momentum'])
frdb['caldt'] = ['1920-12-30','1920-11-20']
frdb.caldt = frdb.caldt.astype('datetime64[D]')

#Benchmark test data
bdb = pd.DataFrame(columns=['benchmark','permno','caldt'])
bdb['benchmark'] = ['SP500']*5 + ['Russell3000']*5
bdb['permno'] = [10026, 10032, 10044, 10051, 10104] + [10107, 10138, 10145, 10158, 10180] 
bdb['caldt'] = '2019-11-20'
bdb['weight'] = np.random.random((bdb.shape[0],1))
bdb2 = bdb.copy()
bdb2.caldt = '2018-05-02'
bdb = pd.concat([bdb,bdb2])
bdb.caldt = bdb.caldt.astype('datetime64[D]')

#Initialize model
m = risk_model(stk_db,fdb,edb,bdb,frdb,model_type='custom',style_factors=['size','nonlinear_size'])
print('done')

myexposures = m.exposures_db
engine = create_engine("mysql+pymysql://admin:f1UQ2vt528FthXPty7Ty@sfdb.csndhrnbcsgs.us-west-2.rds.amazonaws.com/sfdb"
                       .format(user="admin",
                               pw="f1UQ2vt528FthXPty7Ty",
                               db="sfdb"))
myexposures.to_sql('api_equity_security_master', con = engine, if_exists = 'append', chunksize = 1000)

