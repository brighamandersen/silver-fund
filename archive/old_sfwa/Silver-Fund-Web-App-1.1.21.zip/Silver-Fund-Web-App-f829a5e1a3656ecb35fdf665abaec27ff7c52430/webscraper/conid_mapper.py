from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
import os

def check_text_auth(driver):
    try:
        img = driver.find_element_by_xpath("/html/body/form/img").get_attribute('src')
        submit = driver.find_element_by_xpath("/html/body/form/input[1]")
        submit.send_keys(img.split('=')[1])
        driver.find_element_by_xpath("/html/body/form/input[88]").click()

    except NoSuchElementException:
        return None


def get_conids(tickers):
    driver = webdriver.Chrome(ChromeDriverManager().install())
    conids = []

    for ticker in tickers:
        try:
            url = 'https://misc.interactivebrokers.com/cstools/contract_info/v3.10/index.php?site=IB&action=Top+Search&symbol=' + ticker + '&description=' + ticker
            driver.get(url)
            window_search = driver.window_handles[0]

            check_text_auth(driver)

            element = driver.find_element_by_id('stk')
            element.click()

            symbol = driver.find_element_by_id('symbol')
            symbol.send_keys(ticker)

            currency = driver.find_element_by_id('currency')
            for option in currency.find_elements_by_tag_name('option'):
                if option.text == 'U.S. Dollar (USD)':
                    option.click() # select() in earlier versions of webdriver
                    break

            search = driver.find_element_by_xpath("//input[@value='Search']").click()

            window_options = driver.window_handles[1]
            driver.switch_to.window(window_options)
            check_text_auth(driver)

            driver.find_element_by_link_text("Details").click()

            window_details = driver.window_handles[2]
            driver.switch_to.window(window_details)
            check_text_auth(driver)
            conid = driver.find_element_by_xpath("//*[@id='contractSpecs']/table[3]/tbody/tr[2]/td").text
            conids.append(conid)
            
            driver.close()
            driver.switch_to.window(window_options)
            driver.close()
            driver.switch_to.window(window_search)

        except NoSuchElementException:
            conids.append('error')
        
    return conids


tickers = ['IBM',  'APPL', 'AAPL', 'FB', 'ABT', 'ADBE', 'AMD', 'AMZN', 'ATVI', 'BABA', 'BIGC',  'DIS', 'GE', 'GOOG']
conids_test = ['8314', 'error' '265598', '107113386']

conids_res = []
conids_res = get_conids(tickers)

print(conids_res)

# for i in range(0,len(conids_res)):
#     if (conids_test[i] == conids_res[i]):
#         print('Pass: ' + conids_res[i])
#     else:
#         print('Fail: ' + conids_res[i])
