import os


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = "-6jcf!4k&yclk#%zm!$2#)my-f!z3jp*@@yf%i#6=62to+^$+&"

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# add our public IP to it
ALLOWED_HOSTS = [
    "127.0.0.1",
    "localhost",
    "ec2-54-202-198-188.us-west-2.compute.amazonaws.com",
    "54.202.198.188",
    "https://47fund-dev.byu.edu",
    "47fund.byu.edu",
    "10.215.80.130",
]

# Allowed hosts for prd
# ALLOWED_HOSTS = [
#     "127.0.0.1",
#     "localhost",
#     "ec2-54-70-150-56.us-west-2.compute.amazonaws.com",
#     " 54.70.150.56",
#     "47fund.byu.edu",
# ]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "rest_framework.authtoken",
    "api",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "corsheaders.middleware.CorsMiddleware",
]

CORS_ORIGIN_ALLOW_ALL = True

ROOT_URLCONF = "backend.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "backend.wsgi.application"


# DATABASES = {
#     "default": {
#         "ENGINE": "django.db.backends.mysql",
#         "NAME": os.environ.get("SFWA_DB_NAME"),
#         "USER": os.environ.get("SFWA_DB_USER"),
#         "PASSWORD": os.environ.get("SFWA_DB_PASSWORD"),
#         "HOST": os.environ.get("SFWA_DB_HOST"),
#         "PORT": "3306",
#     }
# }

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "NAME": "production_db",
        "USER": "sf_master_db",
        "PASSWORD": "this_is_testing",
        "HOST": "sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com",
        "PORT": "3306",
        "OPTIONS": {"sql_mode": "traditional", },
    }
}

# DB for prd
# DATABASES = {
#     "default": {
#         "ENGINE": "django.db.backends.mysql",
#         "NAME": "sandbox_db",
#         "USER": "sf_master_db",
#         "PASSWORD": "this_is_testing",
#         "HOST": "sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com",
#         "PORT": "3306",
#     }
# }

# DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": "dbç",}}

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework.authentication.BasicAuthentication",
    ],
    "DEFAULT_PERMISSIONS_CLASSES": ["rest_framework.permissions.IsAuthenticated", ],
}

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", },
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator", },
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator", },
]

LANGUAGE_CODE = "en-us"

USE_I18N = True

USE_TZ = False

STATIC_URL = "/static/"
