import pandas as pd
import numpy as np
import time
from tabulate import tabulate
import scipy.stats as sp


class style():
    """
    Base style factor class for input to :code:`byuriskmodel.model.risk_model`.
    The base class holds hidden methods for error checking, input checking, and cleaning
    that would be redundant if held in child classes. Each child class should have a
    :code:`_generate_exposures` method in which the style factor exposures for that
    particular style factor is completed.

    Parameters
    ----------

    None.
        The base class is formed in such a way that the class takes no arguments
        to instantiate, but has the methods to process :code:`byuriskmodel.model.risk_model.stk_db`
        and :code:`byuriskmodel.model.risk_model.fundamentals_db` and return a corresponding :code:`DataFrame`
        containing security exposures to the given style factor.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db):
        Return corresponding :code:`DataFrame` of exposures to given style factor.

    Notes
    ------

    The child class name must match the variable column name for the exposure.

    """

    def __init__(self):
        self.descriptor_weights = [1.]

    def _assertions(self, stk_db, fundamentals_db):
        assert isinstance(
            stk_db, pd.core.frame.DataFrame), "stk_db must be a pandas dataframe"
        assert isinstance(fundamentals_db, pd.core.frame.DataFrame)
        for c in ['caldt', 'ret', 'siccd', 'prc', 'shr', 'rf', 'permno']:
            assert c in list(stk_db.columns), "{} must be in stk_db".format(c)
        # for c in []
        #    assert c in list(fundamentals_db.columns), "{} must be in fundamentals_db".format(c)

    def _clean(self, stk_db):
        pass

    def generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        self._assertions(stk_db, fundamentals_db)
        self.dates = stk_db.caldt.unique()
        self.dates.sort()
        exposures = self._generate_exposures(
            stk_db, fundamentals_db, num_update, extra=extra)
        return exposures.reset_index(drop=True)

    @staticmethod
    def _gb_reb_weight(x, weights, desc):
        desc_weighted_sum = 0
        nonempty_weights = 0
        for i in range(len(desc)):
            d = desc[i]
            dv = x[d].values[0]
            if dv != dv:
                desc_weighted_sum += 0
            else:
                desc_weighted_sum += weights[i] * dv
                nonempty_weights += weights[i]
        if nonempty_weights == 0:
            desc_weighted_sum = np.nan
        else:
            desc_weighted_sum = desc_weighted_sum / nonempty_weights
        return desc_weighted_sum

    @staticmethod
    def _exponential_weights(n, tau):
        # old to recent
        lamb = np.power(0.5, 1./tau)
        df = pd.DataFrame(np.nan, index=np.arange(n), columns=['w'])
        df['T-t'] = n-pd.Series(df.index.to_list())
        df['w'] = np.power(lamb, df['T-t'])
        df['w'] = df['w'] / df.w.sum()
        return df[['w']]

    @staticmethod
    def _orthogonalize(base, new, mcap):
        # base is what we are orthogonalizing to and new is what we are orthogonalizing
        base = np.array(base)
        new = np.array(new)
        n = base.shape[0]
        base = np.reshape(base, (n, 1))
        new = np.reshape(new, (n, 1))
        mcapsv = np.sqrt(mcap)
        mcaps = np.diag(mcapsv)
        myinv = np.linalg.inv(np.matmul(base.T, np.matmul(mcaps, base)))
        orth = new - np.matmul(np.matmul(base, myinv),
                               np.matmul(new.T, np.matmul(mcaps, base)))
        return orth

    @staticmethod
    def _ew_diag(tau, window):
        # diagonal matrix of exponential weights
        ew_mat = np.zeros((window, window))
        ew_tot = 0
        for t in range(window):
            exp_weight = (1/2) ** ((t+1)/tau)
            ew_mat[window-1-t][window-1-t] = exp_weight
            ew_tot += exp_weight
        ew_mat = (1 / ew_tot) * ew_mat
        return ew_mat

    @staticmethod
    def _ew_vec(tau, window):
        # vector of exponential weights
        ew_vec = np.zeros(window)
        ew_tot = 0
        for t in range(window):
            exp_weight = (1/2) ** (t/tau)
            ew_vec[t] = exp_weight
            ew_tot += exp_weight
        ew_vec = (1 / ew_tot) * ew_vec
        return np.flip(ew_vec)

    def _wstd(self, s, tau):
        # weighted standard deviation
        s = pd.DataFrame(s).reset_index(drop=True)
        n = s.shape[0]
        s.columns = ['main']
        s['w'] = self._exponential_weights(n, tau)
        wbar = (s.main * s.w).sum()
        s['tmp1'] = s.w * np.power(s.main - wbar, 2)
        std = np.sqrt(s.tmp1.sum()*n / ((n-1) * s.w.sum()))
        return std

    @staticmethod
    def _cumret(g, win, col='ret'):
        g = g.sort_values('caldt').reset_index(drop=True)
        n = g.shape[0]
        g['grouper'] = pd.Series(np.arange(12)).repeat(
            21).reset_index(drop=True)
        return g.groupby('grouper').apply(lambda x: (1.0+x[col]).prod()-1.0)

#     @staticmethod
#     def _standardize_2(col,vw):
#         std = np.sqrt(np.cov(col, aweights = vw, ddof = 1))
#         mu = (col*vw).sum()
#         newcol = (col-mu)/std
#         return newcol

#     def _standardize(self,g,descriptors):
#         # g needs to have an mcap column
#         g['vw'] = g.mcap / g.mcap.sum()
#         for d in descriptors:
#             g.loc[g[d] == g[d], d] = g.loc[g[d] == g[d], d].apply(self._standardize_2, vw = g.loc[g[d] == g[d], 'vw'])
#         return g.drop('mcap',axis=1)

    def _standardize(self, g, desc):
        # g needs to have an mcap column
        nn = g[g[desc] == g[desc]]
        if nn.mcap.sum() > 0:
            mu = np.average(nn[desc].values, weights=nn['mcap'].values)
            st = np.sqrt(np.cov(nn[desc].values, ddof=1))
            g.loc[g[desc] == g[desc], desc] = (
                g.loc[g[desc] == g[desc], desc] - mu) / st
        else:
            #print('Mcap summed to zero, using uniform weights')
            mu = np.average(nn[desc].values)
            st = np.sqrt(np.cov(nn[desc].values, ddof=1))
            g.loc[g[desc] == g[desc], desc] = (
                g.loc[g[desc] == g[desc], desc] - mu) / st
        return g[[desc]]

    @staticmethod
    def _winsorize(g, col, stds):
        # winsorize 'col' to 'stds' standard deviations away from mean
        std = g[col].std(ddof=1)
        mu = g[col].mean()
        g.loc[g[col] > mu+stds*std, col] = mu+stds*std
        g.loc[g[col] < mu-stds*std, col] = mu-stds*std
        return g[col]


class value(style):
    """
    Value style factor.

    Parameters
    ----------

    None.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db):
        Returns :code:`DataFrame` of :code:`value` by :code:`permno` and :code:`caldt`.


    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        values = fundamentals_db.copy()
        # values = values.merge(
        #     stk_db[['caldt', 'permno', 'prc', 'shr']], on=['caldt', 'permno'])
        # if 'mcap' not in list(values.columns):
        #     values['mcap'] = values.prc * values.shr * 1000.
        values['mcap'] = abs(values['mcap'])  # make sure mcap >0
        values.sort_values(by=['caldt'], inplace=True)
        windowd = 1
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()
        values['bv'] = values.groupby(
            'permno')['bv'].transform(lambda x: x.ffill())
        values['value'] = values['bv']/values['mcap']
        values.loc[values.caldt > '{}'.format(mind), 'value'] = values.loc[values.caldt > '{}'.format(
            mind), ['mcap', 'value', 'caldt']].groupby('caldt').apply(self._standardize, 'value')
        #values.loc[values.caldt > '{}'.format(mind),'value'] = values.loc[values.caldt > '{}'.format(mind),'value']
        #values['value'] = values.groupby('caldt').apply(self._standardize,'value')
        values = values.query("caldt >= '{}'".format(mind))
        return values[['value', 'caldt', 'permno']]


class div_yield(style):
    """
    Dividend yield style factor.

    Parameters
    ----------

    None.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db):
        Returns :code:`DataFrame` of :code:`div_yield` by :code:`permno` and :code:`caldt`.
    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        div_yields = fundamentals_db.copy()
        windowd = 1
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()
        div_yields.loc[div_yields.caldt > '{}'.format(mind), 'div_yield'] = div_yields.loc[div_yields.caldt > '{}'.format(mind), [
            'mcap', 'div_yield', 'caldt']].groupby('caldt').apply(self._standardize, 'div_yield')  # .reset_index(level=0, drop=True)
        div_yields = div_yields.query("caldt >= '{}'".format(mind))
        return div_yields[['div_yield', 'caldt', 'permno']]


class leverage(style):
    """
    Leverage style factor.

    Parameters
    ----------

    None.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db):
        Returns :code:`DataFrame` of :code:`leverage` by :code:`permno` and :code:`caldt`.
    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        levgs = fundamentals_db.copy()
        levgs = levgs.merge(stk_db[['caldt', 'permno', 'prc', 'shr']], on=[
                            'caldt', 'permno'])
        if 'mcap' not in list(levgs.columns):
            levgs['mcap'] = levgs.prc * levgs.shr * 1000.
        windowd = 4
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()
        levgs = levgs.query("caldt >= '{}'".format(mind))
        #print(mind)
        #print(levgs)
        levgs.sort_values(by=['caldt'], inplace=True)
        for x in ['dltt', 'pstk', 'bv', 'at']:
            levgs[x] = levgs.groupby(
                'permno')[x].transform(lambda x: x.ffill())
        levgs['mcap'] = abs(levgs['mcap'])
        levgs['m_lev'] = (levgs['mcap']+levgs['pstk'] +
                          levgs['dltt'])/levgs['mcap']
        levgs['b_lev'] = (levgs['bv']+levgs['pstk']+levgs['dltt'])/levgs['bv']
        levgs['debt_a'] = levgs['dt']/levgs['at']
        #print(levgs)
        levgs['leverage'] = levgs.groupby(['caldt', 'permno']).apply(
            self._gb_reb_weight, [.75, .15, .10], ['m_lev', 'debt_a', 'b_lev']).reset_index(drop=True).values
        levgs['leverage'] = levgs.groupby(
            'caldt').apply(self._standardize, 'leverage')
        return levgs[['permno', 'caldt', 'leverage']].query('permno == permno')


class growth(style):
    """
    Growth style factor.

    Parameters
    ----------

    None.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db):
        Returns :code:`DataFrame` of :code:`growth` by :code:`permno` and :code:`caldt`.
    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        growth = fundamentals_db.copy()
        growth.sort_values(by=['caldt'], inplace=True)
        growth['sale'] = growth.groupby(
            'permno')['sale'].transform(lambda x: x.ffill())
        forecasts = ['one_year_forecast', 'three_year_forecast']
        growth[forecasts] = growth.groupby(
            'cusip')[forecasts].transform(lambda x: x.ffill())
        growth['sps'] = growth['sale']/growth['shrout']
        growth['pred_eps_growth'] = growth['three_year_forecast']/growth['epspi']
        growth['mcap'] = abs(growth['mcap'])
        x = ['epspi', 'sps', 'permno', 'caldt']
        growth.dropna(inplace=True, subset=x)
        windowd = 5
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()
        growth = growth.query("caldt >= '{}'".format(mind))
        #print(mind)
        #print(growth)

        def regress_eps(df):
            y = np.array(df['epspi'].dropna().values, dtype=float)
            x = np.array(df['caldt'].dropna().index.values, dtype=float)
            slope, intercept, r_value, p_value, std_err = sp.linregress(x, y)
            df['epspi_reg'] = slope
            return df

        def regress_sps(df):
            y = np.array(df['sps'].dropna().values, dtype=float)
            x = np.array(df['caldt'].dropna().index.values, dtype=float)
            slope, intercept, r_value, p_value, std_err = sp.linregress(x, y)
            df['sps_reg'] = slope
            return df

        growth = growth.groupby('permno').apply(regress_eps)
        growth = growth.groupby('permno').apply(regress_sps)

        growth['year'] = pd.DatetimeIndex(growth['caldt']).year
        avg1 = pd.DataFrame(data=growth.groupby(
            ['permno', 'year'])['epspi', 'sps'].mean())
        avg2 = pd.DataFrame(data=avg1.groupby(
            ['permno'])['epspi', 'sps'].mean())
        avg2 = avg2.rename(
            columns={"epspi": "avg_eps", "sps": "avg_sps"}, errors="raise")
        growth = pd.merge(growth, avg2, on=['permno'])
        growth['earnings_growth'] = growth['epspi_reg']/growth['avg_eps']
        growth['sales_growth'] = growth['sps_reg']/growth['avg_sps']
        #print(growth)
        growth['growth'] = growth.groupby(['caldt', 'permno']).apply(
            self._gb_reb_weight, [.7, .2, .1], ['pred_eps_growth', 'earnings_growth', 'sales_growth']).reset_index(drop=True).values
        growth['growth'] = growth.groupby(
            'caldt').apply(self._standardize, 'growth')
        return growth[['permno', 'caldt', 'growth']].query('permno == permno')


class earnings_yield(style):
    """
    Earnings Yield style factor.

    Parameters
    ----------

    None.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db):
        Returns :code:`DataFrame` of :code:`earnings_yield` by :code:`permno` and :code:`caldt`.
    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        earnings = fundamentals_db.copy()
        earnings.sort_values(by=['caldt'], inplace=True)
        earnings['mcap'] = abs(earnings['mcap'])
        windowd = 5
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()
        earnings = earnings.query("caldt >= '{}'".format(mind))
        #print(mind)
        #print(earnings)

        earnings['one_year_forecast'] = earnings.groupby(
            'cusip')['one_year_forecast'].transform(lambda x: x.ffill())
        for x in ['op_cf', 'ni']:
            earnings[x] = earnings.groupby(
                'permno')[x].transform(lambda x: x.ffill())
        earnings['forward_earnings'] = earnings['one_year_forecast']
        earnings.sort_values(by=['permno', 'caldt'], inplace=True)

        earnings['op_cf_lag'] = earnings.groupby('permno')['op_cf'].shift(252)
        earnings['cash_earnings'] = earnings['op_cf_lag']/earnings['mcap']
        earnings['ni_lag'] = earnings.groupby('permno')['ni'].shift(252)
        earnings['trailing_EPS'] = earnings['ni_lag']/earnings['mcap']

        #print(earnings)
        earnings['earnings_yield'] = earnings.groupby(['caldt', 'permno']).apply(
            self._gb_reb_weight, [.75, .15, .10], ['forward_earnings', 'cash_earnings', 'trailing_EPS']).reset_index(drop=True).values
        earnings['earnings_yield'] = earnings.groupby(
            'caldt').apply(self._standardize, 'earnings_yield')
        return earnings[['permno', 'caldt', 'earnings_yield']].query('permno == permno')


class mktbeta(style):
    """    
    Market beta style factor. Returns both market beta exposures by security and time point 
    but also residuals from market beta exponential weighted least squares estimation for use in 
    residual volatility style factor formation.

    Parameters
    ----------

    None. 

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db): 
        Returns :code:`DataFrame` of :code:`mktbeta` and :code:`mktbetaresid` by :code:`permno` and :code:`caldt`.


    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        if 'mcap' not in list(stk_db.columns):
            stk_db['mcap'] = stk_db.prc * stk_db.shr * 1000.

        windowd = 252.
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()

        mktbetas = stk_db.query("caldt >= '{}'".format(
            mind)).sort_values(by=['caldt', 'permno'])
        mktbetas['mcap'] = abs(mktbetas['mcap'])
        mktbetas['exret'] = mktbetas.ret - mktbetas.rf
        mktbetas.reset_index(drop=True, inplace=True)
        mktbetas['rme'] = mktbetas['mcap'] * mktbetas['ret']
        mktvw = mktbetas.pivot_table('rme', 'caldt', aggfunc='sum')['rme']
        x = mktbetas.pivot_table('mcap', 'caldt', aggfunc='sum')['mcap']
        mktvw = mktvw.divide(x)
        mktvw = pd.DataFrame(mktvw)
        mktvw.columns = ['mktvw']
        mktbetas = mktbetas.merge(mktvw, on='caldt', how='left')
        mktbetas['exmktvw'] = mktbetas.mktvw - mktbetas.rf

        gb_betas = mktbetas.groupby('permno').apply(self._mktbeta_by_security)
        for i in gb_betas.index:
            mktbetas.loc[mktbetas['permno'].isin([i]), 'mktbeta'] = gb_betas[i]
        del [gb_betas]

        gb_const = mktbetas.groupby('permno').apply(self._const_by_security)
        for i in gb_const.index:
            mktbetas.loc[mktbetas['permno'].isin([i]), 'const'] = gb_const[i]
        del [gb_const]

        mktbetas['mktbetaresid'] = mktbetas['exret'] - \
            (mktbetas['const'] + (mktbetas['exmktvw'] * mktbetas['mktbeta']))
        mktbetas['mktbeta'] = mktbetas.groupby('caldt').apply(
            self._standardize, 'mktbeta')  # .reset_index(level=0, drop=True)
        return mktbetas[['mktbeta', 'mktbetaresid', 'permno', 'caldt']]

    def _mktbeta_by_security(self, g):
        tau_wls = 63
        tr_window = 252
        T = int(len(g))
        b = np.empty(T)
        b[:] = np.nan
        mkt = g.exmktvw.values
        ret = g.exret.values
        W = self._ew_diag(tau_wls, tr_window)
        if T > tr_window:
            for i in range(tr_window, T):
                X = np.column_stack([np.ones(tr_window), mkt[i-tr_window:i]])
                XWX = X.T @ W @ X
                XWY = X.T @ W @ ret[i-tr_window:i]
                sol = np.linalg.solve(XWX, XWY)
                b[i] = sol[1]
        return b

    def _const_by_security(self, g):
        tau_wls = 63
        tr_window = 252
        T = int(len(g))
        r = np.empty(T)
        r[:] = np.nan
        mkt = g.exmktvw.values
        ret = g.exret.values
        W = self._ew_diag(tau_wls, tr_window)
        if T > tr_window:
            for i in range(tr_window, T):
                X = np.column_stack([np.ones(tr_window), mkt[i-tr_window:i]])
                XWX = X.T @ W @ X
                XWY = X.T @ W @ ret[i-tr_window:i]
                sol = np.linalg.solve(XWX, XWY)
                r[i] = sol[0]
        return r


class momentum(style):
    """    
    Momentum style factor. 

    Parameters
    ----------

    None. 

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db): 
        Returns :code:`DataFrame` of :code:`momentum` by :code:`permno` and :code:`caldt`.


    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        windowd = 504+21
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()
        stk_db['mcap'] = abs(stk_db['mcap'])
        momentums = stk_db.query("caldt >= '{}'".format(mind)).groupby(
            'permno').apply(self._momentum_by_security)
        momentums['momentum'] = momentums.groupby('caldt').apply(
            self._standardize, 'momentum')  # .reset_index(level=0, drop=True)
        #momentums['caldt'] = momentums.index.get_level_values('caldt')
        return momentums[['momentum', 'caldt', 'permno']]

    def _momentum_by_security(self, g):
        L = 21  # days
        T = 504  # days
        tau = 126  # days
        n = g.shape[0]
        w = self._exponential_weights(T-L, tau)
        g = g.sort_values('caldt').reset_index(drop=True)
        g['momentum'] = np.nan
        for i in range(n):
            if i > (T+L):
                df = g.iloc[(i-(T+L)):(i-L), :]
                df['w'] = w
                df['intermediate'] = df.w * \
                    (np.log(1.0+df.ret) - np.log(1.0+df.rf))
                g.loc[i, 'momentum'] = df.intermediate.sum()
        return g[['momentum', 'caldt']+['mcap', 'permno']]


class size(style):
    """    
    Size style factor. 

    Parameters
    ----------

    None. 

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db): 
        Returns :code:`DataFrame` of :code:`size` by :code:`permno` and :code:`caldt`.


    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        sizes = stk_db.copy()
        if 'mcap' not in list(sizes.columns):
            sizes['mcap'] = sizes.prc * sizes.shr * 1000.
        sizes['mcap'] = abs(sizes['mcap'])  # make sure mcap >0
        windowd = 1
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()
        sizes.loc[sizes.caldt > '{}'.format(mind), 'size'] = np.log(
            sizes.loc[sizes.caldt > '{}'.format(mind), 'mcap'])
        sizes.loc[sizes.caldt > '{}'.format(mind), 'size'] = sizes.loc[sizes.caldt > '{}'.format(mind), [
            'mcap', 'size', 'caldt']].groupby('caldt').apply(self._standardize, 'size')  # .reset_index(level=0, drop=True)
        #sizes['caldt'] = sizes.index.get_level_values('caldt')
        sizes = sizes.query("caldt >= '{}'".format(mind))
        return sizes[['size', 'caldt', 'permno']]


class residual_volatility(style):
    """    
    Residual volatility style factor. 

    Parameters
    ----------

    mktbetaresid: 
        :code:`DataFrame` containing residuals from :code:`mktbeta` class regression by :code:`permno` and :code:`caldt`.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db): 
        Returns :code:`DataFrame` of :code:`residual_volatility` by :code:`permno` and :code:`caldt`.


    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        assert isinstance(
            extra, pd.core.frame.DataFrame), "extra must be mktbetaresid dataframe for exposure generation for residual volatiltity"
        assert 'mktbetaresid' in extra.columns, "extra must be mktbetaresid dataframe for exposure generation for residual volatiltity containing a 'mktbetaresid' column"
        rvs = stk_db.merge(extra, on=['permno', 'caldt'])
        rvs['mcap'] = abs(rvs['mcap'])
        rvs.sort_values(by=['caldt', 'permno'], inplace=True)

        windowd = 252
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()

        residual_volatilities = rvs.query("caldt >= '{}'".format(mind))

        gb_dastd = residual_volatilities.groupby(
            'permno').apply(self._dastd_by_security)
        gb_cmra = residual_volatilities.groupby(
            'permno').apply(self._cmra_by_security)
        gb_hsigma = residual_volatilities.groupby(
            'permno').apply(self._hsigma_by_security)

        for i in gb_dastd.index:
            residual_volatilities.loc[residual_volatilities['permno'].isin(
                [i]), 'dastd'] = gb_dastd[i]
        del [gb_dastd]

        for i in gb_cmra.index:
            residual_volatilities.loc[residual_volatilities['permno'].isin(
                [i]), 'cmra'] = gb_cmra[i]
        del [gb_cmra]

        for i in gb_hsigma.index:
            residual_volatilities.loc[residual_volatilities['permno'].isin(
                [i]), 'hsigma'] = gb_hsigma[i]
        del [gb_hsigma]

        residual_volatilities['cmra'] = residual_volatilities.groupby('caldt').apply(
            self._standardize, 'cmra')  # .reset_index(level=0, drop=True)
        residual_volatilities['hsigma'] = residual_volatilities.groupby('caldt').apply(
            self._standardize, 'hsigma')  # .reset_index(level=0, drop=True)
        residual_volatilities['dastd'] = residual_volatilities.groupby('caldt').apply(
            self._standardize, 'dastd')  # .reset_index(level=0, drop=True)

        # residual_volatilities['residual_volatility'] = (0.15 * residual_volatilities.cmra +
        #                                               0.75 * residual_volatilities.dastd +
        #                                               0.10 * residual_volatilities.hsigma)
        residual_volatilities['residual_volatility'] = residual_volatilities.groupby(['caldt', 'permno']).apply(
            self._gb_reb_weight, [0.15, 0.75, 0.1], ['cmra', 'dastd', 'hsigma']).reset_index(drop=True).values
        residual_volatilities['residial_volatility'] = residual_volatilities.groupby('caldt').apply(
            self._standardize, 'residual_volatility')  # .reset_index(level=0, drop=True)
        return residual_volatilities[['permno', 'caldt', 'residual_volatility']]

    def _dastd_by_security(self, g):
        tau_sd = 42  # days
        tr_window = 252  # days
        T = int(len(g))
        s = np.empty(T)
        s[:] = np.nan
        g['ex_ret'] = g.ret - g.rf
        ret = g.ex_ret.values
        if T > tr_window:
            weights = self._ew_vec(tau_sd, tr_window)
            W = self._ew_diag(tau_sd, tr_window)
            for i in range(tr_window, T):
                r_bar = np.dot(weights, ret[i-tr_window:i])
                r_dif = ret[i-tr_window:i] - r_bar
                s[i] = np.sqrt(r_dif @ W @ r_dif)
        return s

    def _cmra_by_security(self, g):
        tr_window = 252  # days
        T = int(len(g))
        ra = np.empty(T)
        ra[:] = np.nan
        ret = g.ret.values / 100
        rfr = g.rf.values / 100
        ln_ret = np.log(1 + ret)
        ln_rfr = np.log(1 + rfr)
        if T > tr_window:
            for i in range(tr_window, T):
                z = 0
                Z = []
                for t in range(0, 12):
                    mon_ret = np.sum(ln_ret[i-21*(t+1):i-21*t])
                    mon_rfr = np.sum(ln_rfr[i-21*(t+1):i-21*t])
                    z = z + (mon_ret - mon_rfr)
                    Z.append(z)
                z_max = np.max(Z)
                z_min = np.min(Z)
                ra[i] = np.log(1 + z_max) - np.log(1 + z_min)
        return ra

    def _hsigma_by_security(self, g):
        tau_hs = 63  # days
        tr_window = 252  # days
        T = int(len(g))
        h = np.empty(T)
        h[:] = np.nan
        res = g.mktbetaresid.values
        if T > tr_window:
            weights = self._ew_vec(tau_hs, tr_window)
            W = self._ew_diag(tau_hs, tr_window)
            for i in range(tr_window, T):
                r_bar = np.dot(weights, res[i-tr_window:i])
                r_dif = res[i-tr_window:i] - r_bar
                h[i] = np.sqrt(r_dif @ W @ r_dif)
        return h


class liquidity(style):
    """    
    Liquidity style factor. 

    Parameters
    ----------

    None.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db): 
        Returns :code:`DataFrame` of :code:`liquidity` by :code:`permno` and :code:`caldt`.


    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):

        liqs = stk_db.sort_values(by=['caldt', 'permno'])

        windowd = 21*12
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()

        liqs = liqs.query("caldt >= '{}'".format(mind))
        liqs['mcap'] = abs(liqs['mcap'])
        gb_stom = liqs.groupby('permno').apply(self._stom_by_security)
        gb_stoq = liqs.groupby('permno').apply(self._stoq_by_security)
        gb_stoa = liqs.groupby('permno').apply(self._stoa_by_security)

        for i in gb_stom.index:
            liqs.loc[liqs['permno'].isin([i]), 'stom'] = gb_stom[i]
        del [gb_stom]

        for i in gb_stoq.index:
            liqs.loc[liqs['permno'].isin([i]), 'stoq'] = gb_stoq[i]
        del [gb_stoq]

        for i in gb_stoa.index:
            liqs.loc[liqs['permno'].isin([i]), 'stoa'] = gb_stoa[i]
        del [gb_stoa]

        liqs['stom'] = liqs.groupby('caldt').apply(
            self._standardize, 'stom')  # .reset_index(level=0, drop=True)
        liqs['stoq'] = liqs.groupby('caldt').apply(
            self._standardize, 'stoq')  # .reset_index(level=0, drop=True)
        liqs['stoa'] = liqs.groupby('caldt').apply(
            self._standardize, 'stoa')  # .reset_index(level=0, drop=True)

        #stk_db['liquidity'] = (0.35 * stk_db.stom + 0.35 * stk_db.stoq + 0.3 * stk_db.stoa)
        liqs['liquidity'] = liqs.groupby(['caldt', 'permno']).apply(self._gb_reb_weight, [
            0.35, 0.35, 0.3], ['stom', 'stoq', 'stoa']).reset_index(drop=True).values
        liqs['liquidity'] = liqs.groupby('caldt').apply(
            self._standardize, 'liquidity')  # .reset_index(level=0, drop=True)
        return liqs[['permno', 'caldt', 'liquidity']].query("permno == permno")

    def _stom_by_security(self, g):
        window_stom = 21  # days
        T = int(len(g))
        stom = np.empty(T)
        stom[:] = np.nan
        turnov = g.vol.values / g.shr.values
        if T > window_stom:
            for i in range(window_stom, T):
                stom[i] = np.log(np.sum(turnov[(i-window_stom):i]))
        return stom

    def _stoq_by_security(self, g):
        window_stom = 21  # days
        window_stoq = 3  # months
        window_qday = window_stom * window_stoq  # days
        T = int(len(g))
        stoq = np.empty(T)
        stoq[:] = np.nan
        turnov = g.vol.values / g.shr.values
        if T > window_qday:
            for i in range(window_qday, T):
                stoq[i] = np.log((1/window_stoq) *
                                 np.sum(turnov[(i-window_qday):i]))
        return stoq

    def _stoa_by_security(self, g):
        window_stom = 21  # days
        window_stoa = 12  # months
        window_aday = window_stom * window_stoa  # days
        T = int(len(g))
        stoa = np.empty(T)
        stoa[:] = np.nan
        turnov = g.vol.values / g.shr.values
        if T > window_aday:
            for i in range(window_aday, T):
                stoa[i] = np.log((1/window_stoa) *
                                 np.sum(turnov[(i-window_aday):i]))
        return stoa


class nonlinear_beta(style):
    """    
    Non-linear market beta factor. 

    Parameters
    ----------

    mktbeta: 
        :code:`mktbeta` exposures by :code:`permno` and :code:`caldt` from :code:`mktbeta` class.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db): 
        Returns :code:`DataFrame` of :code:`nonlinear_beta` by :code:`permno` and :code:`caldt`.


    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        assert isinstance(
            extra, pd.core.frame.DataFrame), "extra must be mktbeta dataframe for exposure generation for nonlinear_beta"
        assert 'mktbeta' in extra.columns, "extra must be mktbeta dataframe for exposure generation for nonlinear_beta containing a 'mktbeta' column"
        nlb = stk_db.merge(extra, on=['permno', 'caldt'])
        if 'mcap' not in list(nlb.columns):
            nlb['mcap'] = nlb.prc * nlb.shr * 1000.
        nlb['mcap'] = abs(nlb['mcap'])
        windowd = 1
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()
        nlb = nlb.query("caldt >= '{}'".format(mind))
        nonlinear_betas = nlb.loc[(nlb.mktbeta != nlb.mktbeta), [
            'caldt', 'mcap', 'permno']]
        nonlinear_betas['nonlinear_beta'] = np.nan
        nonlinear_betas = pd.concat([nonlinear_betas,
                                     nlb[nlb.mktbeta == nlb.mktbeta].groupby('caldt').apply(self._nonlinear_beta_by_date)],
                                    ignore_index=True)
        #nonlinear_betas['caldt'] = nonlinear_betas.index.get_level_values('caldt')
        nonlinear_betas['nonlinear_beta'] = nonlinear_betas.groupby('caldt').apply(
            self._standardize, 'nonlinear_beta')  # .reset_index(level=0, drop=True)
        return nonlinear_betas[['permno', 'caldt', 'nonlinear_beta']]

    def _nonlinear_beta_by_date(self, g):
        g['mktbeta3'] = np.power(g['mktbeta'], 3)
        g['nonlinear_beta'] = self._orthogonalize(
            g['mktbeta3'], g['mktbeta'], g['mcap'])
        g['nonlinear_beta'] = self._winsorize(g, 'nonlinear_beta', 3.0)
        g['caldt'] = g.name
        return g[['nonlinear_beta', 'caldt'] + ['mcap', 'permno']]


class nonlinear_size(style):
    """    
    Non-linear size factor. 

    Parameters
    ----------

    size: 
        :code:`size` exposures by :code:`permno` and :code:`caldt` from :code:`size` class.

    Methods
    --------

    generate_exposures(stk_db,fundamentals_db): 
        Returns :code:`DataFrame` of :code:`nonlinear_size` by :code:`permno` and :code:`caldt`.


    """

    def __init__(self):
        style.__init__(self)

    def _generate_exposures(self, stk_db, fundamentals_db, num_update, extra=None):
        assert isinstance(
            extra, pd.core.frame.DataFrame), "extra must be size dataframe for exposure generation for nonlinear_size"
        assert 'size' in extra.columns, "extra must be mktbeta dataframe for exposure generation for nonlinear_size containing a 'size' column"
        nls = stk_db.merge(extra, on=['permno', 'caldt'])
        if 'mcap' not in list(nls.columns):
            nls['mcap'] = nls.prc * nls.shr * 1000.
        nls['mcap'] = abs(nls['mcap'])
        windowd = 1
        try:
            mind = self.dates[-int(windowd+num_update+1)]
        except IndexError:
            mind = self.dates.min()
        nls = nls.query("caldt >= '{}'".format(mind))
        nonlinear_sizes = nls.query("size != size")[
            ['caldt', 'mcap', 'permno']]
        nonlinear_sizes['nonlinear_size'] = np.nan
        nonlinear_sizes = pd.concat([nonlinear_sizes,
                                     nls.dropna(subset=['size']).groupby('caldt').apply(self._nonlinear_sizes_by_date)],
                                    ignore_index=True)
        #nonlinear_sizes = nls.groupby('caldt').apply(self._nonlinear_sizes_by_date)
        #nonlinear_sizes['caldt'] = nonlinear_sizes.index.get_level_values('caldt')
        nonlinear_sizes['nonlinear_size'] = nonlinear_sizes.groupby('caldt').apply(
            self._standardize, 'nonlinear_size')  # .reset_index(level=0, drop=True)
        return nonlinear_sizes[['nonlinear_size', 'permno', 'caldt']]

    def _nonlinear_sizes_by_date(self, g):
        g['size3'] = np.power(g['size'], 3)
        g['nonlinear_size'] = self._orthogonalize(
            g['size3'], g['size'], g['mcap'])
        g['nonlinear_size'] = self._winsorize(g, 'nonlinear_size', 3.0)
        g['caldt'] = g.name
        return g[['nonlinear_size', 'caldt']+['mcap', 'permno']]
