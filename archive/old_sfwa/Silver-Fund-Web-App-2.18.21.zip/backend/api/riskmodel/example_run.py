import pandas as pd
from model import risk_model
import numpy as np
import pickle
from analytics import portfolio


BOX_PATH = '~/Box/FinanceNerds/DB_INIT/CSTEAM/DB/'

########################################
#               Note
########################################
# This file is meant to be an example 
# for how to run the model. This file 
# is meant to be run with the files 
# added to box in FinanceNerds/DB_INIT/CSTEAM
# on 21 Jan 2021.


########################################
#       Stock Data DB
########################################
# This should be preprocessed already 
# according to methods that should be 
# somewhat clear from the CSTEAM/DB/replication
# folder on box.
stk_db = pd.read_csv(BOX_PATH + 'stk_db.csv',parse_dates=['date'],low_memory=False)
stk_db['caldt'] = stk_db['caldt'].astype('datetime64')

########################################
#       Fundamentals DB
########################################
# This is how to read in the fundamentals_db for now. It could be cleaned up.
fdb=pd.read_csv(BOX_PATH +"fundamentals_db.csv", parse_dates=['caldt'], error_bad_lines=False).drop(['Unnamed: 0', 'Unnamed: 0.1'],axis=1)
fdb = fdb.drop_duplicates(['permno','caldt'],keep='first')
fdb['caldt'] = fdb['caldt'].astype('datetime64')

########################################
#      Positions DB
########################################
# These second two lines are necessary from going 
# from the format in the positions_db file 
# to the format the model needs.
pdb = pd.read_csv(BOX_PATH +'positions_db.csv', parse_dates = ['date'])
pdb['weights'] = pdb['position_value']/pdb['position_value'].sum()
pdb['asset_id'] = pdb['asset_id'].astype(str)


########################################
#       Initial Exposures DB
########################################
# If you are running overnight, this will have been updated 
# the night before, so the stock data should be one day ahead.
# The model will see this and update the exposures accordingly.
edb = pd.read_csv(BOX_PATH +'exposures_db.csv',parse_dates=['caldt'])
edb['caldt'] = edb['caldt'].astype('datetime64')

########################################
#       Initial Factor Returns DB
########################################
# If you are running overnight, this will have been updated 
# the night before, so the stock data should be one day ahead.
# The model will see this and update the factor returns accordingly.
frdb = pd.read_csv(BOX_PATH +'factorreturns_db.csv',parse_dates=['caldt'])
#frdb = frdb.drop(columns=['date'])
frdb['caldt'] = frdb['caldt'].astype('datetime64')

########################################
#       Benchmarks DB
########################################
bdb = pd.read_csv(BOX_PATH +'benchmark_db.csv',parse_dates=['caldt'])
bdb['caldt'] = bdb['caldt'].astype('datetime64')

########################################
#    Initialize the model object
########################################
# This will update exposures databases and factor returns databases with more recent data from the stock database.
# Note: The adhoc option is for securities that are not included in the model (not US equity 
# share code 10 or 11) but are in the benchmark. Pass in a list of PERMNO (later asset ID) 
# that are not share code 10 or 11 but are in the benchmark database if you want those to be 
# available for portfolio analytics and portfolio optimization. PERMNO 90790 is the REIT that 
# the Silver Fund held in January 2021. This commit has been tested (both portfolio optimization 
# and portfolio analytics) with this REIT. For this to work, the stock database fed to the model 
# needs to have data (even if it is not recent) for the securities in the ad hoc list.
m = risk_model(stk_db,fdb,edb,bdb,frdb,pdb,adhoc=[90790])

########################################
#    Get updated data for SQL
########################################
# Now that the model is initialized, you can access the updated factor returns database and the updated 
# exposures database to pull back down updated data to SQL
newfrdb = m.factor_returns_db
newedb = m.exposures_db

########################################
#        Run model engine
########################################
# You can also run the predict variance covariance matrix and predict specific volatility calls manually, 
# although the model will do this for you if you call a method that requires it if you haven't done it manually.
m.predict_VCV()
myVCV = m.VCV # see the object if you want
m.predict_specific_vol()
mySV = m.SV # see the object if you want

########################################
#        Portfolio Analytics
########################################
# Here you can define a series indexed by PERMNO (later by asset_id)
# with portfolio weights as the values, and feed it into the portfolio
# class which has a number of methods outlined here: 
# https://docs.google.com/document/d/1huGBBEig5w7bhe5tcsF4tv7TGThXmqzd4oJ8zHmNVhI/edit?usp=sharing
w = pd.Series([0.3,0.6,0.1],index=[10026,10032,90790])

# create the portfolio object
port = portfolio(w,m)

# I created a dictionary to hold a number of the outputs for an example
mydict = {}

# Important note on standard deviations: standard deviations are daily 
# to get annualized standard deviations, you need to multiply the daily 
# standard deviation by sqrt(252).
mydict['exante_std_daily'] = port._exante_std_daily(active=False)
mydict['exante_std_daily_active'] = port._exante_std_daily(active=True)
mydict['realized_std_daily'] = port._realized_std_daily(active=False)
mydict['realized_std_daily_active'] = port._realized_std_daily(active=True)
mydict['exante_std_daily_holdings'] = port._exante_std_dbd(active=False)
mydict['exante_std_daily_active_holdings'] = port._exante_std_dbd(active=True)
mydict['realized_std_daily_holdings'] = port._realized_std_dbd(active=False)
mydict['realized_std_daily_active_holdings'] = port._realized_std_dbd(active=True)
mydict['exante_beta'] = port._portfolio_beta(active=False,exante=True)
mydict['exante_beta_active'] = port._portfolio_beta(active=True,exante=True)

########################################
#        Portfolio Optimization
########################################
# define a series indexed by PERMNO (later by asset_id)
# with values being student predicted expected returns
er = pd.Series([0.2,0.1,0.15],index=[10026,10032,90790])
# run the optimization on this expected returns series
summary,stats = m.port_opt(er)
# there are a number of optional inputs to the 
# portfolio optimization method, but this just 
# uses the default. Talk to Ellie about the options 
# if you need them.
