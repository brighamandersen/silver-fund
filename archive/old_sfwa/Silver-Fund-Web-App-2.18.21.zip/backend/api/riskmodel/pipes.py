import pandas as pd
from sqlalchemy import create_engine
import model


# CONNECT TO SERVER (use VPN)
SERVER_HOST = 'sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com'
PORT = 3306
DB = 'sandbox_db'
DB_USER = 'sf_master_db'
DB_PASS = 'this_is_testing'
engine = create_engine('mysql+pymysql://{user}:{password}@{host}:{port}/{db}'.format(
    user=DB_USER, password=DB_PASS, host=SERVER_HOST, port=PORT, db=DB), execution_options=dict(stream_results=True))
engine.connect()

# BENCHMARK DB
benchmark = """
select * from api_benchmark as bdb
    """
print("Reading benchmark sql")
bdb = pd.read_sql(benchmark, con=engine)
bdb = bdb.rename(columns={'asset_id': 'permno'})
print(bdb)

# FACTOR RETURN DB (EMPTY) use frdb_2018 until after re-initializing
factor_return = """
select * from api_factor_return as factor_ret
    """
print("Reading sql factor returns")
frdb = pd.read_sql(factor_return, con=engine)
# factor_ret = factor_ret.drop(columns=['id'])
print(frdb)

# EXPOSURES DB
# To Test a small sample set the LIMIT after select *
exposures = """
select * from api_exposures as exposures_db
    """
print('reading sql exposures')
edb = pd.read_sql(exposures, con=engine)
edb = edb.rename(columns={'asset_id': 'permno'})
print(edb)
# capitalize industries


# STOCK DB
stock_db = """
select * from api_market_data as stk_db
    """
print('reading sql stock database')
stk = pd.read_sql(stock_db, con=engine)
stk = stk.rename(columns={'asset_id': 'permno'})
print(stk)

# FUNDAMENTALS DB: (once sam gets initalized version in the db we can pull in here)
