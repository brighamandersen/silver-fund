
import pandas as pd
from datetime import datetime
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from bs4 import BeautifulSoup as bs
import mysql.connector

DEFAULT_TIMEOUT = 2
MAX_ATTEMPT = 5

#This class helps resubmit requests that have timed out
class TimeoutHTTPAdapter(HTTPAdapter):
    def __init__(self, *args, **kwargs):
        self.timeout = DEFAULT_TIMEOUT
        if "timeout" in kwargs:
            self.timeout = kwargs["timeout"]
            del kwargs["timeout"]
        super().__init__(*args, **kwargs)

    def send(self, request, **kwargs):
        timeout = kwargs.get("timeout")
        if timeout is None:
            kwargs["timeout"] = self.timeout
        return super().send(request, **kwargs)

#This class manages requests to yahoo finance
#It's common for yahoo finance to throttle our usage so if a request takes too much time we just resubmitt
def getdata(url, sess, attempt):
    website = None
    try:
        website = sess.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=5)
        
    except requests.exceptions.RequestException as e:
        print('except')
        if attempt < MAX_ATTEMPT:
            getdata(url, sess, attempt+1)
        else:   
            print(e)
            website = None

    except ConnectionError as e:
        print('except')
        if attempt < MAX_ATTEMPT:
            getdata(url, sess, attempt+1)
        else:
            print(e)
            website = None

    return website


connection = mysql.connector.connect(host='sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com',
                        user = 'sf_master_db',
                        passwd = 'this_is_testing',
                        db = 'sandbox_db')

#Get needed assets from the database    
assets = pd.read_sql_query("select * from api_equity_security_master where bnchmrk='Russell_3000'", connection)
mktdata = pd.DataFrame()



for index, row in assets[:10].iterrows():
    trade_symbol = row['ticker']
    print(trade_symbol + " " + str(index))
    sess = requests.Session()
    retries = Retry(total=5, backoff_factor=1, status_forcelist=[ 502, 503, 504 ])
    sess.mount('https://', TimeoutHTTPAdapter(max_retries=retries))

    url = 'https://finance.yahoo.com/quote/'+ trade_symbol + '/key-statistics'
    website = getdata(url, sess, 1)
    if not website:
        continue


    soup = bs(website.text, 'lxml')
    alldata = soup.find_all('tbody')

    try:
        table = alldata[2].find_all('tr')
    except:
        print('error 1 ' + trade_symbol + '*******************************')
        print(trade_symbol)
        continue

    try:
        table_td = table[2].find_all('td')
    except:
        print('error 2 ' + trade_symbol + '*******************************')
        print(trade_symbol)
        continue

    if "Shares Outstanding" in str(table_td[0].text):
        shrs = str(table_td[1].text)
        if shrs == 'N/A':
            shrs = 'N/A'
        else:
            if 'B' in shrs:
                exp = 1000000000
            if 'T' in shrs:
                exp = 1000000000000
            if 'M' in shrs:
                exp = 1000000
            try:
                shrs = float(shrs.replace('B','').replace('M','').replace('T','')) * exp
            except:
                shrs = ''
                print('error 3 ' + trade_symbol + '*******************************')
                continue

    url = 'https://finance.yahoo.com/quote/'+ trade_symbol + '/history'
    website = getdata(url, sess, 1)
    if not website:
        continue
    soup = bs(website.text, 'lxml')
    alldata = soup.find_all('tbody')

    try:
        table = alldata[0].find_all('tr')
        
        prev = 1
        table_td = table[0].find_all('td')
        table_td_prev = table[prev].find_all('td')
        
        if(len(table_td)<5):
            table_td = table[1].find_all('td')
            prev = prev+1
        if(len(table_td_prev)<5):
            table_td_prev = table[prev+1].find_all('td')
        

        date = table_td[0].text
        date = datetime.strptime(date, '%b %d, %Y').strftime('%Y%m%d')
        prc = float(table_td[5].text)
        vol = str(table_td[6].text).replace(',','')
        vol = float(vol)
        ret = float(table_td[5].text)/float(table_td_prev[5].text)


        mktdata = mktdata.append({'asset_id': row['asset_id'], 'caldt': date, 'prc': prc, 'vol': vol, 'ret': ret, 
                                    'shr': shrs, 'siccd': row['siccd']}, ignore_index = True)

    except:
        print('error 4 ' + trade_symbol + '*******************************')
        continue



print('pushing to database')
print(mktdata)
#This engine lets us access our RDS database
engine = create_engine("mysql+pymysql://sf_master_db:this_is_testing@sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com/sandbox_db"
                       .format(user="sf_master_db",
                               pw="this_is_testing",
                               db="sandbox_db"))
#Insert the data into the database
mktdata.to_sql('api_market_data', con = engine, if_exists = 'append', chunksize = 1000, index=False)