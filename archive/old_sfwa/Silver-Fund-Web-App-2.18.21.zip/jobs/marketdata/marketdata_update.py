import pandas as pd
import requests
from datetime import datetime, timedelta, date
import mysql.connector
import time
from sqlalchemy import create_engine

API_URL = "https://www.alphavantage.co/query"
API_KEY = 'VA355PKBU1CCOU9S'
CONNECTION = mysql.connector.connect(host='sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com',
                                     user='sf_master_db',
                                     passwd='this_is_testing',
                                     db='sandbox_db')


def gen_ticker(ticker, tsymbol, shrcls):
    if shrcls:
        search_ticker = tsymbol + '-' + shrcls
    else:
        search_ticker = ticker
    return ticker


def get_time_series(ticker):
    pram = {"function": "TIME_SERIES_DAILY_ADJUSTED",
            "symbol": ticker,
            "outputsize": "full",
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    response_json = response.json()

    if 'Error Message' not in response_json:
        if 'Time Series (Daily)' in response_json:
            mkdata = pd.DataFrame.from_dict(
                response_json['Time Series (Daily)'], orient='index').sort_index(axis=1)
            return mkdata
        else:
            #print('could not find ' + str(ticker))
            return pd.DataFrame()
    else:
        #print('could not find ' + str(ticker))
        return pd.DataFrame()


def asset_lookup(searchword):
    pram = {"function": "SYMBOL_SEARCH",
            "keywords": searchword,
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    response_json = response.json()

    if response_json.get('bestMatches'):
        curr_score = 0
        curr_ticker = ''
        for item in response_json['bestMatches']:
            if (item['3. type'] == 'Equity') and (item['8. currency'] == 'USD'):
                if float(item['9. matchScore']) > curr_score:
                    curr_score = float(item['9. matchScore'])
                    curr_ticker = item['1. symbol']
    else:
        #print('asset look up could not find ' + str(searchword))
        return None
    if curr_score < 0.8:
        return None
    return curr_ticker


def format_comnam(comnam):
    comnam = comnam.lower()
    comnam = comnam.replace('inc', '')
    comnam = comnam.replace('corp', '')
    split = comnam.split()
    if len(split) == 1:
        return split[0]
    return split[0] + " " + split[1]


def get_shrs(ticker):

    pram = {"function": "OVERVIEW",
            "symbol": ticker,
            "datatype": "json",
            "apikey": API_KEY}
    response = requests.get(API_URL, pram)
    response_json = response.json()

    if response_json:
        if 'SharesOutstanding' in response_json:
            shrs = response_json['SharesOutstanding']
        else:
            #print('could not find ' + str(ticker))
            return None
    else:
        #print('could not find ' + str(ticker))
        return None
    return shrs


def validate(alpha, permno):
    crsp_subset = crsp[crsp['PERMNO'] == permno]
    crsp_subset['date'] = pd.to_datetime(
        crsp_subset['date'], format="%Y%m%d", errors='coerce')
    alpha['date'] = alpha['date'].astype(str)
    crsp_subset['date'] = crsp_subset['date'].astype(str)

    data = pd.merge(alpha, crsp_subset, on=['date', 'PERMNO'])

    close_diff = data['close'].astype(
        float) - data['PRC'].astype(float).round(2).abs()
    if close_diff.abs().sum() > 5:
        ticker = alpha.reset_index().iloc[0]['ticker']
        print(str(ticker) + ' with ' + str(permno) +
              ' seems off with big difference ' + str(close_diff.abs().sum()))

    corr = data['close'].astype(float).corr(
        data['PRC'].astype(float).round(2).abs())
    if corr < 0.98:
        ticker = alpha.reset_index().iloc[0]['ticker']
        print(str(ticker) + ' with ' + str(permno) +
              ' seems off with correlation ' + str(corr))


print('starting')

crsp = pd.read_sql_query(
    "select * from api_crsp_securities", CONNECTION)

assets = crsp.permno.unique()

print('pulled from database')

pd.set_option('mode.chained_assignment', None)
# end = date(2020, 9, 30).strftime('%Y-%m-%d')
# start = date(2020, 9, 29).strftime('%Y-%m-%d')

start = (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')
end = datetime.now().strftime('%Y-%m-%d')

start_time = time.time()
time_check = start_time
req_num = 0
count = 1

df = pd.DataFrame()
for security in assets[:25]:
    # Check for nan permnos (should not be any)
    if(str(security) == 'nan'):
        continue
    if security == None:
        continue

    info = crsp[crsp['permno'] == security]
    ticker = info['ticker'].values[0]
    if ticker == None:
        continue
    tsymbol = info['tsymbol'].values[0]
    shrcls = info['shrcls'].values[0]
    comnam = format_comnam(info['comnam'].values[0])
    gensymbol = gen_ticker(ticker, tsymbol, shrcls)

    lookup_ticker = asset_lookup(tsymbol)
    req_num = req_num+1
    if not lookup_ticker:
        lookup_ticker = asset_lookup(ticker)
        req_num = req_num+1
        if not lookup_ticker:
            lookup_ticker = asset_lookup(gen_ticker)
            req_num = req_num+1
            if not lookup_ticker:
                lookup_ticker = asset_lookup(comnam)
                req_num = req_num+1
                if not lookup_ticker:
                    print('could not find ' + str(comnam) +
                          ' with ticker ' + str(ticker))
                    continue

    mkdata = get_time_series(lookup_ticker)
    req_num = req_num+1

    if not mkdata.empty:
        mkdata['ticker'] = ticker
        mkdata['caldt'] = mkdata.index
        mask = (mkdata['caldt'] > start) & (mkdata['caldt'] <= end)
        mkdata = mkdata.loc[mask]
        mkdata = mkdata.rename(columns={'1. open': 'open', '2. high': 'high', '3. low': 'low',
                                        '4. close': 'close', '5. adjusted close': 'prc', '6. volume': 'vol'})

        mkdata = mkdata[['prc', 'vol', 'caldt']]
        mkdata['asset_id'] = info['permno'].values[0]
        mkdata['rf'] = 0.022
        mkdata['siccd'] = info['siccd'].values[0]

        mkdata['shr'] = get_shrs(lookup_ticker)

        # validate(mkdata, info['permno'])

        df = pd.concat([df, mkdata])
        # Insert the data into the database

        if (time.time()-time_check > 50) and req_num > 118:
            #             print('sleep')
            time.sleep(5)
            time_check = time.time()
            req_num = 0
        if req_num > 120:
            req_num = 0
            time_check = time.time()

end_time = time.time()
print(end_time - start_time)

print(df)

engine = create_engine("mysql+pymysql://sf_master_db:this_is_testing@sfdb.c38swr1uods4.us-west-2.rds.amazonaws.com/sandbox_db"
                       .format(user="sf_master_db",
                               pw="this_is_testing",
                               db="sandbox_db"))
df.to_sql('mkdata', con=engine,
          if_exists='append', chunksize=1000, index=False)
# df.to_csv('alpha_data.csv')
