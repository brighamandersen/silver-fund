
import pandas as pd 
  
# readinag given csv file 
# and creating dataframe 
dataframe1 = pd.read_csv("data") 
  
# storing this dataframe in a csv file 
dataframe1.to_csv('AV_data.csv',  
                  index = None) 
