import time
import os

import pandas as pd
import numpy as np

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from datetime import datetime
from selenium.common.exceptions import TimeoutException
import time
import os


df = pd.read_csv('September2020.csv')

def check_text_auth(driver):
    try:
        img = driver.find_element_by_xpath("/html/body/form/img").get_attribute('src')
        submit = driver.find_element_by_xpath("/html/body/form/input[1]")
        submit.send_keys(img.split('=')[1])
        driver.find_element_by_xpath("/html/body/form/input[88]").click()

    except NoSuchElementException:
        return None

def get_ISIN(df, driver):
    #Iterate through each row of the dataframe
    for i in df.index:
        cusip = df['CUSIP'][i]
        if cusip:
            try:
                driver.get('https://www.isindb.com/convert-cusip-to-isin/')
                search = driver.find_element_by_id('userinput')
                search.send_keys(cusip)
                convert = driver.find_element_by_id('convert')
                convert.click()

                Wait = WebDriverWait(driver, 3)       
                Wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="result"]/p/strong')))
                
                isin = driver.find_element_by_id('result')
                isin = (isin.find_elements_by_tag_name('strong')[0].text)
                df['isin'][i] = isin

            except NoSuchElementException:
                print('Error finding ' + str(df['COMNAM'][i]) + ' ISIN')
            except IndexError:
                print('Error finding ' + str(df['COMNAM'][i]) + ' ISIN')
        else:
            df['isin'][i] = None
            print('Error finding ' + str(df['COMNAM'][i]) + ' ISIN because no CUSIP')
            
    return df   

def convert_cusip(df, driver):
    for i in df.index:
        ncusip = df['NCUSIP'][i]        
        try:
            driver.get('https://www.isindb.com/fix-cusip-calculate-cusip-check-digit/')
            search = driver.find_element_by_id('userinput')
            search.send_keys(ncusip)
            convert = driver.find_element_by_id('fix')
            convert.click()
            
            Wait = WebDriverWait(driver, 3)       
            Wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="result"]/p/strong')))
        
            cusip = driver.find_element_by_id('result')
            cusip = (cusip.find_elements_by_tag_name('strong')[0].text)
            df['CUSIP'][i] = cusip
        
        except NoSuchElementException:
            print('Error finding ' + str(df['COMNAM'][i]) + ' CUSIP')
                
        except IndexError:
            print('Error finding ' + str(df['COMNAM'][i]) + ' CUSIP, index error')
#         except TimeoutException:
#             print('Timed out waiting for '+ str(df['COMNAM'][i]) + ' to load')
        except TimeoutException as ex:
            print('timeout')
 
    return df

def search_for_asset(df, attempt, driver):
    conid = None
    updated_ticker = None
    
    for i in df.index:
        ticker = df['TICKER'][i]
        name = df['COMNAM'][i]
        ISIN = df['isin'][i]
        try:
            url = 'https://misc.interactivebrokers.com/cstools/contract_info/v3.10/'       
            driver.get(url)
            window_search = driver.window_handles[0]

            check_text_auth(driver)

            element = driver.find_element_by_id('stk')
            element.click()

            if(attempt == 2):
                symbol = driver.find_element_by_id('symbol')
                symbol.send_keys(ticker)
            if(attempt == 3):
                symbol = driver.find_element_by_id('description')
                symbol.send_keys(name)

            currency = driver.find_element_by_id('currency')
            for option in currency.find_elements_by_tag_name('option'):
                if option.text == 'U.S. Dollar (USD)':
                    option.click() 
                    break

            if(attempt == 1):
                if not ISIN:
                    continue
                secIdType = driver.find_element_by_id('secIdType')
                for option in secIdType.find_elements_by_tag_name('option'):
                    if option.text == 'ISIN':
                        option.click() 
                        break

                secId = driver.find_element_by_id('secId')
                secId.send_keys(ISIN)


            search = driver.find_element_by_xpath("//input[@value='Search']").click()

            window_options = driver.window_handles[1]
            driver.switch_to.window(window_options)
            check_text_auth(driver)

            driver.find_element_by_link_text("Details").click()

            window_details = driver.window_handles[2]
            driver.switch_to.window(window_details)
            check_text_auth(driver)
            conid = driver.find_element_by_xpath("//*[@id='contractSpecs']/table[3]/tbody/tr[2]/td").text
            
            if df['isin'][i] == 0:
                isin = driver.find_element_by_xpath("//*[@id='contractSpecs']/table[3]/tbody/tr[4]/td").text
                df['isin'][i] = isin
                
            if(attempt == 3):
                updated_ticker = driver.find_element_by_xpath("//*[@id='contractSpecs']/table[2]/tbody/tr[3]/td").text
                print("Updated ticker " + ticker + " to " + updated_ticker + " " + name)


            driver.close()
            driver.switch_to.window(window_options)
            driver.close()
            driver.switch_to.window(window_search)
            
            df['conid'][i] = conid

        except NoSuchElementException:
            if (attempt == 3):
                print("attempt" + str(df['COMNAM'][i]) + "failed")
        except IndexError:
            print('Error finding ' + str(df['COMNAM'][i]) + ' ISIN')
    
#     print("Success on Attempt: " + str(attempt))
    return df


#df = pd.read_csv('December2019_data.csv')
#df = df[(df['date'] == 20191231)]

chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--window-size=1920x1080")
driver = webdriver.Chrome('./chromedriver', options=chrome_options)


df['conid'] = 0
df['isin']= 0
df['asset_id']=''
df['CUSIP'] = 0

print("START: " + str(datetime.now()))


df = convert_cusip(df,driver)
failed_cusip_convert = df[df['CUSIP']==0]
df = df[df['CUSIP']!=0]
print('second try for cusip')
if(failed_cusip_convert.shape[0] !=0):
    df = pd.concat([df, convert_cusip(failed_cusip_convert, driver)], ignore_index=True)
print('finished cusip')
print('df shape: ' + str(df.shape))

print('starting ISIN')
df = get_ISIN(df,driver)
failed_ISIN = df[df['isin']==0]
df = df[df['isin']!=0]
print('second try for ISIN')
if(failed_ISIN.shape[0] !=0):
    df = pd.concat([df, convert_ISIN(failed_ISIN, driver)], ignore_index=True)
print('finished ISIN')
print('df shape: ' + str(df.shape))
    

print('Starting conid')
df = search_for_asset(df,1,driver)
print('df shape: ' + str(df.shape))
second_try = df[df['conid']==0]
df = df[df['conid']!=0]

print('df shape: ' + str(df.shape))
print('second_try shape: ' + str(second_try.shape))

second_try = search_for_asset(second_try,2,driver)

third_try = second_try[second_try['conid']==0]
second_try = second_try[second_try['conid']!=0]
third_try = search_for_asset(third_try,3,driver)

print('df shape: ' + str(df.shape))
print('second_try shape: ' + str(second_try.shape))
print('third_try shape: ' + str(third_try.shape))

df = pd.concat([df,second_try,third_try], ignore_index=True)


print("END: " + str(datetime.now()))
df.to_csv('security_master3.csv')
