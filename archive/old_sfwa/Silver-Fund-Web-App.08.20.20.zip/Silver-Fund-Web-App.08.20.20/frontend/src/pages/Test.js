import React from "react";
import RiskVTRadio from "../components/RiskAnalytics/RiskVTRadio";

export default function Test() {
  return (
    <div className="content">
      <h1>TEST</h1>
      <RiskVTRadio />
    </div>
  );
}
