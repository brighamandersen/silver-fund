import React from "react";

import { SubpaneBar, Tab, activeStyle } from "../shared/NavComponents";

export const PositionsSubpanes = () => (
  <SubpaneBar>
    <Tab to="/positions/snapshot" activeStyle={activeStyle}>
      Snapshot (Bar Chart View)
    </Tab>
    <Tab to="/positions/history" activeStyle={activeStyle}>
      History by Stock (Time Series View)
    </Tab>
  </SubpaneBar>
);

export default PositionsSubpanes;
