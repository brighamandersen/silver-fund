import React from "react";

export default function Footer() {
  return (
    <footer>
      <p>&copy; Silver Fund | All Rights Reserved</p>
    </footer>
  );
}
