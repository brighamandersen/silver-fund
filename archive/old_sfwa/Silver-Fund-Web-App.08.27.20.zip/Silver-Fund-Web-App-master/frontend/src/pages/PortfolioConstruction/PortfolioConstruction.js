import React from "react";

import portfolioConstructionSheet from "./components/pc-sheet.png";

export default function PortfolioConstruction() {
  return (
    <div className="content">
      <img src={portfolioConstructionSheet} alt="" style={{ width: "90%" }} />
    </div>
  );
}
